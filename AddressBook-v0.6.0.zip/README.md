# AddressBook

**Version 0.6.0**

AddressBook is a menu-driven Discord bot for Elder Scrolls Online housing discovery, saved-house directories, comments, and guided housing tours. Most members only need one command:

```text
/housing
```

Version 0.6.0 supports **SQLite by default** and optional **MariaDB** selected through `.env`. It includes Global houses and tours, centralized Global Housing Moderators, movable house visibility, revocable House and Tour Share Passes, independent self-paced tour starts, contextual copying of shared Private houses and tours, destination-wide comments, problem reports, onboarding, health checks, automatic database creation, guarded two-way database transfers, readable names stored alongside important IDs, multi-role administration settings, tour-membership house filtering, and a private My AddressBook dashboard with persistent recently viewed houses. User-facing visibility choices consistently appear in Global, Server, Private order.

The `/housing` home screen identifies the running version and briefly explains that AddressBook is an ESO housing directory and tour guide.

## My AddressBook

Choose **My AddressBook** from the `/housing` home screen to open a private personal dashboard. It shows counts and shortcuts for:

- **My Houses** - Private houses you saved plus Server or Global houses you submitted
- **My Tours** - tours you created
- **Pending** - your pending house submissions and Global Moderator access request
- **Recently Viewed** - saved houses you recently opened

Recently viewed history is stored per Discord user and survives bot restarts. A recent entry is displayed only while that user can still access the house in the current server; visibility changes cannot expose another member's Private house or another server's Server house.

## House visibility

Every saved player house has one stable AddressBook record and one of three visibility levels:

- **Private** - visible only to the Discord user who owns the AddressBook entry. Private entries follow that user across guilds where AddressBook is installed.
- **Server** - visible only in the Discord guild/server where the house is registered.
- **Global** - bot-wide. It can be found from every guild using this AddressBook installation.

The official ESO catalog is shown separately as **Non-Player Homes**. Non-Player Homes are read-only and are excluded from Search Houses by default.

### Changing a house's visibility

A user who has edit access to a house can choose **Change Visibility** and move it between Global, Server, and Private.

AddressBook keeps the same saved-house ID when visibility changes, so comments, metadata, and other information remain attached to the house. Before making a change, AddressBook checks every tour that references the house. If the new visibility would make the house ineligible, it shows a confirmation listing the affected tours. Confirming removes incompatible stops and renumbers the remaining stops in the same database transaction.

Permission rules still apply to the destination visibility. Moving a house to Server or Global requires the same permission needed to register a Server/Global house in the current guild.

## Search Houses

Search Houses combines the sources available to the current user:

- the user's **Private** houses;
- the current guild's **Server** houses;
- bot-wide **Global** houses; and
- **Non-Player Homes** when explicitly included.

Server houses from other Discord guilds are never returned.

Available cumulative filters are:

- House / Nickname - one partial-match value
- Owner - one partial-match ESO account value
- Tags / Themes - multi-select
- Zone - multi-select
- Architectural Style - multi-select
- ESO Classification - multi-select
- Size / Type - multi-select
- House Visibility - multi-select in **Global, Server, Private** order
- Tour Membership - optionally show only houses absent from every Global tour and this server's Server tours
- Non-Player Homes - Included / Excluded

Opening **Search Houses** immediately populates the paginated selector with every accessible saved house. Use **Filters** to open the compact Discord modal for House / Nickname, Owner, House Visibility, Non-Player Homes, and **Not on a Server or Global Tour**. That tour filter excludes houses on any Global tour or a Server tour belonging to the current Discord server; Private tours and Server tours from other servers do not disqualify a house. Non-Player Homes are excluded while it is active. Because Discord limits modal size and each select menu to 25 choices, the modal can also open one paginated attribute selector for Tags / Themes, Zone, Architectural Style, ESO Classification, or Size / Type. Submit applies the selections; dismissing the modal keeps the previously applied filters. **Clear Filters** restores the complete accessible-house list.

Different populated filter categories are combined with **AND**. Multiple values inside the same attribute category are combined with **OR**.

Results are paged in Discord selectors without discarding the full result set. The detail card retains Previous House / Next House navigation, comments, edit/delete controls when authorized, and bulk tour actions for saved player houses.

## Register New House

Choose **Register New House** and select a visibility:

- **Global**
- **Server**
- **Private**

Private registrations belong only to the Discord user who creates them.

Server and Global registrations use the current guild's Registration Policy:

- **Open** - permitted submissions become active immediately.
- **Approval** - Housing Trusted Submitters and Housing Moderators are auto-approved; ordinary submissions remain pending for review.
- **Roles** - only configured trusted submitters and Housing Moderators may submit.

Anyone who is allowed to register a Server house in the guild is also allowed to register a Global house.

## Editing and deleting houses

- **Private:** only the owner of that Private AddressBook entry may edit/delete it.
- **Server:** the original submitter or the current guild's Housing Moderator may edit/delete it.
- **Global:** the original submitter or an approved **Global Housing Moderator** may edit/delete it.

Deleting a saved house permanently deletes its comments and removes its tour-stop references. Remaining affected tour stops are renumbered.

## House cards and ESO links

Saved house cards can show:

- owner
- zone and official ESO metadata
- nickname / description / tags
- comment count
- submitting Discord member
- house visibility
- visible associated tours by tour name
- Jump in ESO command
- Unfurnished Preview command
- Housing Link
- More Details
- Change Visibility, Edit House, and Delete House when authorized

The three values always appear in this order: **Jump in ESO**, **Unfurnished Preview**, then **Housing Link**. Each value is displayed in its own Discord code block for one-click copying. Jump in ESO visits the saved player destination, Unfurnished Preview opens the official empty template, and Housing Link provides ESO's housing-link form of the destination.

AddressBook cannot bypass ESO visitor permissions. A correct jump destination can still fail if the owner does not allow visitors.

Associated tours are listed in Global, Server, Private order. AddressBook shows Global tours to everyone, Server tours only in their Discord server, and Private tours only to their creator. This prevents a selected house from revealing another member's Private tour name. Non-Player Home cards identify the ESO Housing Catalog as their source and show no associated saved tours.

## Comments

Comments are attached to the stable saved-house record. They therefore remain with the house if it moves between Global, Server, and Private visibility.

Deleting the house deletes its comments.

Global-house comments are visible wherever the Global house itself is visible.

## Housing Tours

A saved tour has one **Visibility** setting. That setting automatically determines which houses are eligible.

### Tour Visibility

- **Global Tour** - visible bot-wide from every guild using AddressBook.
- **Server Tour** - visible in the current Discord guild.
- **Private Tour** - only the creator can find/edit/start the saved tour.

- **Global Tour:** Global houses only.
- **Server Tour:** Global houses plus Server houses from that Discord server.
- **Private Tour:** Global houses, Server houses visible in the current server, and Private houses belonging to the tour creator.

Changing Tour Visibility checks existing stops first. AddressBook asks for confirmation before removing incompatible stops and then renumbers the remaining route.

### `tours` versus `tour_stops`

The `tours` table stores the saved tour itself: name, description, creator, visibility, source rules, and guild/source-guild information.

The `tour_stops` table stores the ordered houses that make up that tour. A single saved tour can therefore have many stop rows, each pointing at one stable `saved_houses` record with a position, optional tour-specific title, and optional stop notes.

## Running tours: Self Paced vs Shared

The saved tour and the active run are separate things. An active run is represented by a short-lived `tour_sessions` row.

### Self Paced

A Self Paced run is separate for each **guild + channel + user**.

If the same user starts another Self Paced tour in the same guild/channel, AddressBook deletes that user's previous session and starts the new one.

### Shared

A Shared run is limited to one active session per **guild + channel**.

Starting another Shared tour in the same guild/channel closes the old Shared session and starts the new one.

The Discord user who starts the Shared tour is its leader. Everyone in the channel can see the current stop and copy its ESO values, but only the leader can use Previous Stop, Next Stop, or End Tour. Other users who press those controls receive a private explanation naming the leader. Shared tours have no join or leave state because the tour is displayed directly in the channel.

### Ending and stale tour controls

**End Tour physically deletes the active `tour_sessions` row.** Tour sessions are not retained as historical records.

If someone presses Previous, Next, End Tour, or another control from a message whose session has already ended or been replaced, AddressBook responds:

```text
This tour has been closed.
```

When an older SQLite database is upgraded in place, legacy `tour_sessions` are deliberately not carried forward because active-run state is transient and old files may contain stale session rows. The explicit SQLite-to-MariaDB importer follows the same rule.

## Global Housing Moderators

Global moderation is centralized. A normal guild Housing Moderator does not automatically receive bot-wide Global moderation rights.

Users can open **Administration -> Global Moderation** and submit **Request Global Moderator Access**. A reason is required.

Configured bot-wide approvers can:

- review pending requests;
- approve or deny requests; and
- revoke existing Global Housing Moderator access.

Approved Global Housing Moderators can manage bot-wide Global houses and Global tours.

Approver Discord user IDs are configured centrally in `.env`:

```env
GLOBAL_MODERATOR_APPROVER_USER_IDS=123456789012345678,234567890123456789
```

This value may contain one or more comma-separated Discord user IDs.

## Administration roles

Guild-level Administration continues to use:

- **Housing Moderator** - guild-level administration, Server-house moderation, pending review, configured-channel recovery, and guild-level tour privileges.
- **Housing Trusted Submitter** - trusted registration status only; no general administration/moderation privileges.
- **Housing Tours** - optional role for starting Shared Server Tours without granting other moderation privileges. After a run starts, only that run's initiating leader controls it.

Each administrative function accepts up to 25 Discord roles through Discord's native role picker. The picker makes the server's available roles selectable even when the server contains more than 25 roles. A member receives the corresponding permission when they possess any one of the configured roles.

Global Housing Moderator is not a guild role. It is stored centrally by Discord user ID after approval.

## Database options

AddressBook 0.6.0 requires Node.js 22 or newer plus your Discord bot token/application ID. Storage can be either SQLite or MariaDB.

### SQLite (default)

SQLite uses Node.js 22's built-in `node:sqlite` support and requires no separate database server. If `DB_TYPE` is omitted, AddressBook uses SQLite automatically. The default file is:

```text
./data/eso-housing.sqlite
```

If you point AddressBook at an older v0.3.x SQLite database, startup automatically upgrades Server/Private saved houses, comments, tours, and tour stops into the unified schema. The old active tour-session rows are not retained because sessions are transient. Back up the SQLite file before upgrading an existing production installation.

### MariaDB (optional)

Set `DB_TYPE=mariadb` to use MariaDB. AddressBook creates the configured database when missing and then creates/migrates its tables. The configured account therefore needs `CREATE DATABASE`, or an administrator can create `DB_NAME` once. Use a dedicated account with normal CRUD and schema-migration permissions.

## Configuration

Copy `.env.example` to `.env`. A simple SQLite installation needs only the Discord settings plus the default database selection:

```env
DISCORD_TOKEN=replace_with_bot_token
DISCORD_CLIENT_ID=replace_with_application_id
DISCORD_GUILD_ID=
DISCORD_CLEANUP_GUILD_IDS=

DB_TYPE=sqlite
DATABASE_PATH=./data/eso-housing.sqlite

GLOBAL_MODERATOR_APPROVER_USER_IDS=
DEPLOY_GLOBAL=false
```

To use MariaDB instead:

```env
DB_TYPE=mariadb
DB_HOST=127.0.0.1
DB_PORT=3306
DB_NAME=addressbook
DB_USER=addressbook
DB_PASSWORD=replace_with_database_password
DB_PASSWORD_FILE=
DB_CONNECTION_LIMIT=5
```

`DB_PASSWORD_FILE` is optional and takes precedence over `DB_PASSWORD`; it is useful with Docker/Podman secrets. Never commit `.env` to source control.

## Direct Node installation

```bash
npm install
npm run db:init
npm run db:seed
npm run deploy:commands
npm start
```

Normal startup applies pending schema migrations and updates the official house catalog before logging into Discord.

## Docker

```bash
docker compose up -d --build
```

The supplied Compose file mounts `./data` at `/app/data`, so SQLite persists outside the container. If you select MariaDB, the same Compose file connects to the MariaDB server configured in `.env`; MariaDB itself is intentionally not bundled.

## Moving data between SQLite and MariaDB

Back up both databases first. Configure both `DATABASE_PATH`/`SQLITE_MIGRATION_PATH` and the MariaDB `DB_*` values. Then set:

```env
MIGRATE=true
MIGRATE_CONFIRM=ERASE_TARGET_DATABASE
```

The direction follows `DB_TYPE`: `mariadb` copies SQLite to MariaDB, while `sqlite` copies MariaDB to SQLite. AddressBook validates the source and target, **erases AddressBook data in the destination**, copies durable rows in a transaction, verifies table counts, excludes active tour sessions, writes a completion marker, and exits. Set `MIGRATE=false` and restart. A completed migration cannot run again until AddressBook has been started once with `MIGRATE=false`.

After a successful import, set `DB_TYPE=mariadb` before starting AddressBook. Changing `DB_TYPE` by itself does not merge or synchronize two databases.

## Database tables

Both backends expose the same logical AddressBook tables:

- `schema_migrations` - applied AddressBook schema versions
- `houses` - official ESO house catalog
- `guild_settings` - server-specific policy, roles, and channel configuration
- `saved_houses` - stable Global/Server/Private saved player-house records
- `house_comments` - comments attached to `saved_houses`
- `tours` - saved Global/Server/Private tours
- `tour_stops` - ordered saved-house references for each tour
- `tour_sessions` - active Self Paced/Shared runs only
- `global_moderators` - centrally approved Global Housing Moderators
- `global_moderator_requests` - centralized access requests and review status
- `audit_log` - moderation, scope-change, and other audit events
- `discord_guilds` - last-known Discord server names
- `discord_users` - last-known global Discord display names and usernames
- `discord_guild_members` - last-known server-specific member display names
- `discord_channels` - last-known channel names
- `discord_roles` - last-known role names

### Readable names alongside IDs

Important ID references also have readable companion fields. Examples include `guild_name` beside `guild_id`, `origin_guild_name` beside `origin_guild_id`, actor global/server display names beside `actor_id`, and tour or saved-house names beside their internal IDs. Message IDs and request IDs remain ID-only because they do not have stable human-readable names.

Numeric IDs remain authoritative for permissions, relationships, and uniqueness. Names are informational and are never used to decide access. AddressBook records both a user's global Discord display name and their server-specific display name when guild context is available. Whenever a later Discord interaction exposes a changed server, user, channel, or role name, AddressBook refreshes its identity cache and propagates that newest name to associated operational and audit rows. It retains the last-known value when Discord cannot currently resolve a name.

Official ESO house names and saved-house/tour names are also refreshed into dependent records. Schema upgrades and guarded SQLite/MariaDB transfers preserve these cache and companion fields. Existing rows can initially contain blank companion values; they are filled as AddressBook encounters the relevant Discord identities.

## Command deployment

`/housing` remains the only member-facing slash command.

For development/guild-scoped deployment:

```env
DISCORD_GUILD_ID=your_test_guild_id
DEPLOY_GLOBAL=false
```

Then:

```bash
npm run deploy:commands
```

For global deployment:

```env
DEPLOY_GLOBAL=true
```

The deploy script clears configured legacy guild-scoped commands before registering global commands. `DISCORD_CLEANUP_GUILD_IDS` can contain additional comma-separated guild IDs to clean during the transition.

## Data and privacy model

- Private houses are visible only to their Discord owner.
- Server houses and Server tours are isolated by Discord guild.
- Global houses and Global tours are bot-wide.
- Global Tours contain Global houses only.
- Comments inherit visibility from the saved house they belong to.
- Server-house source information in tours remains tied to a specific source guild.
- ESO owner names are housing destination data, not Discord identity links.
- AddressBook does not bypass ESO visitor permissions.
- Active tour sessions are transient and are deleted when ended or replaced.

## Troubleshooting

### AddressBook will not start

Check `DB_TYPE`. For SQLite, confirm `DATABASE_PATH` points to a writable location. For MariaDB, confirm `DB_HOST`, `DB_NAME`, and `DB_USER` are present and the server/database can be reached. If `DB_PASSWORD_FILE` is set, confirm the file exists and is readable.

### A Server house is visible in the wrong server

This should not occur. Server saved-house queries are guild-scoped. Confirm the record's visibility is actually Server rather than Global and review `guild_id` in `saved_houses`.

### A Global house is not visible

Only active Global saved houses are returned. If the originating guild uses Approval registration, make sure the Global submission was approved.

### A tour says it has been closed

The active `tour_sessions` row no longer exists. The run may have been ended or replaced by a newer Self Paced/Shared run in the same session scope. Start the tour again.

### A scope change removed a tour stop

AddressBook shows the affected tours before confirmation. Once confirmed, incompatible stops are removed and the remaining route is renumbered. The underlying saved house and its comments remain intact.

### A jump command or Housing Link does not allow entry

Verify the ESO owner spelling and the owner's visitor permissions. AddressBook cannot override ESO housing access settings.

## Tests and release verification

The repository includes regression tests for backend selection, real SQLite migrations/queries, automatic v0.3.x SQLite upgrades, house scopes, Global tours, Global moderation, scope-change impact, transient tour sessions, and the SQLite-to-MariaDB importer. A real MariaDB server is still recommended for final validation when deploying with `DB_TYPE=mariadb`.
