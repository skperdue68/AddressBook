# AddressBook 0.6.0

AddressBook is a menu-driven Discord bot for ESO housing discovery, saved addresses, comments, tours, and controlled sharing.

## Visibility and permissions

The UI always presents visibility in this order: **Global**, **Server**, **Private**.

- Global houses and tours are available across servers using the bot.
- Server houses and tours are limited to their Discord server.
- Private entries belong to one Discord user.
- Global tours contain Global houses only. Server tours contain Server or Global houses. Private tours may contain Private, Server, and Global houses when the creator has access.
- A user can edit their own entries. Housing Moderators can manage server entries; Global Housing Moderators can manage Global entries.

## Share Passes

Share Pass cards store only a hash of their opaque token. Owners can revoke or repost them; reposting rotates the token and makes old cards stale.

- A shared Private house remains out of normal search. A recipient may report it and, when authorized by pass-only context, copy it into Global, Server, or Private visibility.
- Copying pre-fills nickname, description, and tags but leaves them editable. The ESO owner and official house remain fixed. Tour associations are never copied.
- A Tour Pass starts an independent ephemeral self-paced session for each visitor. Revoking the pass closes only sessions derived from that pass.
- A copied tour is a new Private tour. Existing accessible destinations are reused; inaccessible stops are copied as Private entries in one transaction. A failed copy leaves no partial tour or house records.

## Comments and reports

Comments attach to the stable ESO destination, so matching Global, Server, and Private saved entries share the same comment history. Reports support six problem types: broken jump, owner blocks visitors, incorrect destination, misleading information, duplicate entry, and other. Reports are rate-limited, deduplicated while open, and filtered for moderator authority. Private metadata is redacted from unauthorized moderator views.

## Database and migration

SQLite is the default. Set `DB_TYPE=mariadb` for MariaDB. AddressBook creates the configured MariaDB database when the account has permission and applies the schema automatically.

For a one-time transfer, set `MIGRATE=true` and `MIGRATE_CONFIRM=ERASE_TARGET_DATABASE`. With `DB_TYPE=mariadb`, SQLite is copied to MariaDB; with `DB_TYPE=sqlite`, MariaDB is copied to SQLite. The target is erased only after the explicit confirmation. Persistent v4 data is transferred in dependency order; active tour sessions and Share Pass session links are intentionally not transferred. Set `MIGRATE=false` and restart after completion.

## First use and administration

The first `/housing` interaction offers a short three-screen introduction or direct actions. Help can replay the introduction. My AddressBook provides Continue cards for an active self-paced tour, a recent accessible house, and the most recently edited owned tour.

Housing Administration includes role configuration, health, reports, and Share Pass activity. Health displays backend connectivity, schema migration version, channel availability, policies, role counts, queue counts, pass counts, and a backup reminder; it never displays passwords, tokens, or connection credentials.

## Configuration

Copy `.env.example` to `.env`, set `DISCORD_TOKEN` and `DISCORD_CLIENT_ID`, choose `DEPLOY_GLOBAL`, and configure either SQLite or MariaDB. Keep `GLOBAL_MODERATOR_APPROVER_USER_IDS` as a comma-separated list of Discord user IDs when centralized Global Moderator approval is desired.
