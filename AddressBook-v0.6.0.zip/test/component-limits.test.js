import test from 'node:test';
import assert from 'node:assert/strict';
import { homePayload, adminHealthPayload, onboardingPayload, registrationTypePayload, searchFiltersModal } from '../src/ui/housing-ui.js';
import { reportProblemTypePayload } from '../src/ui/report-ui.js';
import { houseCopyVisibilityPayload } from '../src/ui/share-pass-ui.js';

function inspect(payload){
  const json={...payload,embeds:payload.embeds?.map(e=>e.toJSON?.()||e),components:payload.components?.map(row=>row.toJSON?.()||row)};
  for(const row of json.components||[]){assert.ok((row.components||[]).length<=5,'Discord action rows may contain at most five components');for(const component of row.components||[]){if(component.options)assert.ok(component.options.length<=25,'Discord select menus may contain at most 25 options');if(component.custom_id)assert.ok(component.custom_id.length<=100,'Discord custom IDs may contain at most 100 characters');}}
  return json;
}

test('core AddressBook payloads stay within Discord component limits',()=>{
  const preview={destination:{houseName:'Villa',esoOwner:'Owner'},choices:[{visibility:'global',label:'Global',enabled:true},{visibility:'public',label:'Server',enabled:true},{visibility:'private',label:'Private',enabled:true}]};
  for(const payload of [homePayload(),onboardingPayload({page:0}),registrationTypePayload(),searchFiltersModal('a'.repeat(20),{},false),reportProblemTypePayload({kind:'housepass',token:'x'.repeat(60)}),houseCopyVisibilityPayload(preview,{token:'x'.repeat(60)}),adminHealthPayload({backend:'SQLite',connection:'Connected',version:'0.6.0',channel:{},registrationPolicy:'open',roleCounts:{moderator:0,trusted:0,tours:0},pendingSubmissions:0,globalModeratorRequests:0,openReports:0,passes:{house:{active:0,revoked:0},tour:{active:0,revoked:0}},lastMigration:{version:4},backupReminder:'Use backups.'})])inspect(payload);
});
