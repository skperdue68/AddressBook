import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { closeDatabase, migrate, one, openDatabase } from '../src/db/database.js';
import { SavedHouseService } from '../src/services/saved-house-service.js';
import { SharePassService } from '../src/services/share-pass-service.js';

async function fixture(){
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'addressbook-house-pass-'));
  const db=openDatabase({DB_TYPE:'sqlite',DATABASE_PATH:path.join(dir,'pass.sqlite')});
  await migrate(db);
  await db.query("INSERT INTO houses(house_id,name,normalized_name) VALUES(62,'Grand Psijic Villa','grand psijic villa')");
  return {db,houses:new SavedHouseService(db),passes:new SharePassService(db)};
}

test('house pass creates hashed token posts resolves usage and revokes',async()=>{
  const {db,houses,passes}=await fixture();
  try{
    const house=await houses.createPrivate({userId:'owner',houseId:62,esoOwner:'HouseOwner',createdBy:'owner'});
    const created=await passes.createHousePass({savedHouseId:house.id,createdBy:'owner',originGuildId:'g1',channelId:'c1'});
    assert.ok(created.token);
    const stored=await one(db,'SELECT * FROM house_share_passes WHERE id=?',[created.pass.id]);
    assert.notEqual(stored.token_hash,created.token);
    assert.equal(stored.token_hash.length,64);
    await passes.markHousePassPosted(created.pass.id,{guildId:'g1',channelId:'c1',messageId:'m1',channelName:'housing'});
    const resolved=await passes.resolveHousePass(created.token,{userId:'viewer',guildId:'g1'});
    assert.equal(resolved.house.id,house.id);
    assert.equal(resolved.access.passOnly,true);
    assert.equal(Number((await one(db,'SELECT usage_count c FROM house_share_passes WHERE id=?',[created.pass.id])).c),1);
    await passes.revokeHousePass(created.pass.id,{actorId:'owner',reason:'Done sharing'});
    await assert.rejects(()=>passes.resolveHousePass(created.token,{userId:'viewer',guildId:'g1'}),/revoked by its owner/i);
  }finally{await closeDatabase(db);}
});

test('Private house pass creation and management remain owner-only',async()=>{
  const {db,houses,passes}=await fixture();
  try{
    const house=await houses.createPrivate({userId:'owner',houseId:62,esoOwner:'HouseOwner',createdBy:'owner'});
    await assert.rejects(()=>passes.createHousePass({savedHouseId:house.id,createdBy:'viewer',originGuildId:'g1',channelId:'c1'}),/normal access|owner/i);
    const created=await passes.createHousePass({savedHouseId:house.id,createdBy:'owner',originGuildId:'g1',channelId:'c1'});
    await assert.rejects(()=>passes.revokeHousePass(created.pass.id,{actorId:'viewer'}),/creator|owner/i);
    assert.equal((await one(db,'SELECT status FROM house_share_passes WHERE id=?',[created.pass.id])).status,'active');
  }finally{await closeDatabase(db);}
});

test('reposting rotates token and makes surviving old cards stale',async()=>{
  const {db,houses,passes}=await fixture();
  try{
    const house=await houses.createGlobal({originGuildId:'g1',houseId:62,esoOwner:'HouseOwner',createdBy:'owner'});
    const created=await passes.createHousePass({savedHouseId:house.id,createdBy:'viewer',originGuildId:'g1',channelId:'c1'});
    const reposted=await passes.repostHousePass(created.pass.id,{actorId:'viewer',guildId:'g1',channelId:'c2',messageId:'m2'});
    assert.notEqual(reposted.token,created.token);
    await assert.rejects(()=>passes.resolveHousePass(created.token,{userId:'recipient',guildId:'g1'}),/no longer connected|stale/i);
    assert.equal((await passes.resolveHousePass(reposted.token,{userId:'recipient',guildId:'g1'})).house.id,house.id);
  }finally{await closeDatabase(db);}
});

test('deleted shared house leaves pass audit but cannot be opened',async()=>{
  const {db,houses,passes}=await fixture();
  try{
    const house=await houses.createGlobal({originGuildId:'g1',houseId:62,esoOwner:'HouseOwner',createdBy:'owner'});
    const created=await passes.createHousePass({savedHouseId:house.id,createdBy:'owner',originGuildId:'g1',channelId:'c1'});
    await houses.delete(house.id,'owner');
    assert.equal((await one(db,'SELECT saved_house_id FROM house_share_passes WHERE id=?',[created.pass.id])).saved_house_id,null);
    await assert.rejects(()=>passes.resolveHousePass(created.token,{userId:'recipient',guildId:'g1'}),/no longer available/i);
  }finally{await closeDatabase(db);}
});
