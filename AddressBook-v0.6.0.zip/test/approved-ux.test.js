import test from 'node:test';
import assert from 'node:assert/strict';
import { cleanDestinationEmbed, homePayload } from '../src/ui/housing-ui.js';
import { tourEmbed } from '../src/utils/render.js';
import { canControlTourSession } from '../src/ui/housing-menu.js';

const fieldsOf = embed => embed.toJSON().fields || [];

test('home explains AddressBook and displays the running version', () => {
  const embed = homePayload({ version: '0.4.5' }).embeds[0].toJSON();
  assert.match(embed.title, /AddressBook/);
  assert.match(embed.description, /ESO housing/i);
  assert.match(embed.footer.text, /Version 0\.4\.5/);
});

test('house actions display Jump, Preview, then Housing Link in separate fields', () => {
  const fields = fieldsOf(cleanDestinationEmbed({
    id: 7, scope: 'global', house_id: 74, eso_owner: '@DecorByLuna',
    house_name: 'Moon-Sugar Meadow', comment_count: 0
  }));
  const actionNames = fields.map(field => field.name).filter(name => /Jump|Preview|Housing Link/.test(name));
  assert.deepEqual(actionNames, ['🔗 Jump in ESO', '🏚️ Unfurnished Preview', '🔗 Housing Link']);
  for (const name of actionNames) assert.match(fields.find(field => field.name === name).value, /^```text\n[\s\S]+\n```$/);
});

test('tour stops display Jump, Preview, then Housing Link in separate fields', () => {
  const fields = fieldsOf(tourEmbed({ name: 'Tour' }, [{
    position: 1, house_id: 74, eso_owner: '@DecorByLuna', house_name: 'Moon-Sugar Meadow'
  }], 1));
  const actionNames = fields.map(field => field.name).filter(name => /Jump|Preview|Housing Link/.test(name));
  assert.deepEqual(actionNames, ['🔗 Jump in ESO', '🏚️ Unfurnished Preview', '🔗 Housing Link']);
});

test('only the shared-tour initiator can navigate or end it', () => {
  const shared = { mode: 'shared', started_by: 'leader-id' };
  assert.equal(canControlTourSession(shared, 'leader-id'), true);
  assert.equal(canControlTourSession(shared, 'moderator-id'), false);
});

test('self-paced tour controls belong only to their initiating user', () => {
  const selfPaced = { mode: 'self_paced', started_by: 'user-a' };
  assert.equal(canControlTourSession(selfPaced, 'user-a'), true);
  assert.equal(canControlTourSession(selfPaced, 'user-b'), false);
});
