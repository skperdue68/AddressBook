import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { closeDatabase, migrate, openDatabase, one } from '../src/db/database.js';

const columnNames=async(db,table)=>new Set((await db.query(`PRAGMA table_info(${table})`)).map(row=>row.name));

test('latest schema retains Discord identity caches and readable companion fields',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'addressbook-identities-'));
  const db=openDatabase({DB_TYPE:'sqlite',DATABASE_PATH:path.join(dir,'identities.sqlite')});
  try{
    await migrate(db);
    assert.equal(Number((await one(db,'SELECT MAX(version) version FROM schema_migrations')).version),4);
    for(const table of ['discord_guilds','discord_users','discord_guild_members','discord_channels','discord_roles']){
      assert.equal(Number((await one(db,"SELECT COUNT(*) count FROM sqlite_master WHERE type='table' AND name=?",[table])).count),1,table);
    }
    const expected={
      guild_settings:['guild_name','bot_channel_name','staff_role_names','registration_role_names','tour_role_names'],
      saved_houses:['guild_name','origin_guild_name','owner_global_name','owner_display_name','house_name','created_by_global_name','created_by_display_name','updated_by_global_name','updated_by_display_name'],
      house_comments:['saved_house_name','discord_global_name','discord_display_name'],
      tours:['guild_name','source_guild_name','creator_global_name','creator_display_name'],
      tour_stops:['tour_name','saved_house_name'],
      tour_sessions:['tour_name','guild_name','channel_name','started_by_global_name','started_by_display_name'],
      global_moderators:['discord_global_name','approved_by_global_name'],
      global_moderator_requests:['discord_global_name','discord_display_name','origin_guild_name','reviewed_by_global_name','reviewed_by_display_name'],
      audit_log:['guild_name','actor_global_name','actor_display_name','entity_name']
    };
    for(const [table,names] of Object.entries(expected)){
      const actual=await columnNames(db,table);
      for(const name of names)assert.ok(actual.has(name),`${table}.${name}`);
    }
  }finally{await closeDatabase(db);}
});
