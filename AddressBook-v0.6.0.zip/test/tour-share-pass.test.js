import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { closeDatabase, migrate, one, openDatabase } from '../src/db/database.js';
import { SavedHouseService } from '../src/services/saved-house-service.js';
import { SharePassService } from '../src/services/share-pass-service.js';
import { TourReadinessService } from '../src/services/tour-readiness-service.js';
import { TourService } from '../src/services/tour-service.js';
import { tourShareCardPayload } from '../src/ui/share-pass-ui.js';

async function fixture(){
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'addressbook-tour-pass-'));
  const db=openDatabase({DB_TYPE:'sqlite',DATABASE_PATH:path.join(dir,'pass.sqlite')});
  await migrate(db);
  await db.query("INSERT INTO houses(house_id,name,normalized_name) VALUES(62,'Grand Psijic Villa','grand psijic villa')");
  return {db,houses:new SavedHouseService(db),tours:new TourService(db),passes:new SharePassService(db)};
}

test('only Private tour creator can issue or reissue its Tour Pass',async()=>{
  const {db,houses,tours,passes}=await fixture();
  try{
    const tour=await tours.create({creatorId:'owner',visibility:'private',sourceGuildId:'g1',name:'Secret Route'});
    const house=await houses.createPrivate({userId:'owner',houseId:62,esoOwner:'Owner',createdBy:'owner'});
    await tours.addStop(tour.id,house.id);
    await assert.rejects(()=>passes.createTourPass({tourId:tour.id,createdBy:'viewer',originGuildId:'g1',channelId:'c1'}),/normal access|creator/i);
    const created=await passes.createTourPass({tourId:tour.id,createdBy:'owner',originGuildId:'g1',channelId:'c1'});
    const resolved=await passes.resolveTourPass(created.token,{userId:'viewer',guildId:'g1'});
    assert.equal(resolved.tour.id,tour.id);
    assert.equal(resolved.access.passOnly,true);
    await assert.rejects(()=>passes.createTourPass({tourId:tour.id,createdBy:'viewer',originGuildId:'g1',channelId:'c1',sourcePassId:created.pass.id}),/normal access|creator/i);
    await assert.rejects(()=>passes.repostTourPass(created.pass.id,{actorId:'viewer',guildId:'g1',channelId:'c2'}),/creator/i);
  }finally{await closeDatabase(db);}
});

test('Tour Pass uses live route rotates on repost and reports deleted tours',async()=>{
  const {db,houses,tours,passes}=await fixture();
  try{
    const house=await houses.createPrivate({userId:'owner',houseId:62,esoOwner:'Owner',createdBy:'owner'});
    const tour=await tours.create({creatorId:'owner',visibility:'private',sourceGuildId:'g1',name:'Live Route'});
    await tours.addStop(tour.id,house.id,'Original');
    const created=await passes.createTourPass({tourId:tour.id,createdBy:'owner',originGuildId:'g1',channelId:'c1'});
    assert.equal((await passes.resolveTourPass(created.token,{userId:'viewer',guildId:'g1'})).stops.length,1);
    await tours.updateStop((await tours.getStops(tour.id))[0].id,{notes:'Updated live note'});
    assert.equal((await passes.resolveTourPass(created.token,{userId:'viewer',guildId:'g1'})).stops[0].notes,'Updated live note');
    const reposted=await passes.repostTourPass(created.pass.id,{actorId:'owner',guildId:'g1',channelId:'c2',messageId:'m2'});
    await assert.rejects(()=>passes.resolveTourPass(created.token,{userId:'viewer',guildId:'g1'}),/no longer connected|stale/i);
    assert.equal((await passes.resolveTourPass(reposted.token,{userId:'viewer',guildId:'g1'})).tour.id,tour.id);
    await tours.remove(tour.id);
    await assert.rejects(()=>passes.resolveTourPass(reposted.token,{userId:'viewer',guildId:'g1'}),/tour is no longer available/i);
    assert.equal((await one(db,'SELECT tour_id FROM tour_share_passes WHERE id=?',[created.pass.id])).tour_id,null);
  }finally{await closeDatabase(db);}
});

test('readiness blocks empty and duplicate-destination tours',async()=>{
  const {db,houses,tours}=await fixture();
  try{
    const empty=await tours.create({creatorId:'owner',visibility:'private',sourceGuildId:'g1',name:'Empty'});
    const readiness=new TourReadinessService(db);
    assert.ok((await readiness.check(empty.id,{viewerId:'owner',guildId:'g1'})).blocking.some(issue=>issue.code==='no_stops'));
    const first=await houses.createPrivate({userId:'owner',houseId:62,esoOwner:'Owner',displayName:'One',createdBy:'owner'});
    const second=await houses.createGlobal({originGuildId:'g1',houseId:62,esoOwner:'owner',displayName:'Two',createdBy:'owner'});
    await tours.addStop(empty.id,first.id);
    await tours.addStop(empty.id,second.id);
    const result=await readiness.check(empty.id,{viewerId:'owner',guildId:'g1'});
    assert.ok(result.blocking.some(issue=>issue.code==='duplicate_destination'));
  }finally{await closeDatabase(db);}
});

test('Tour Pass card exposes only independent self-paced start information copy and report actions',()=>{
  const payload=tourShareCardPayload({id:4,name:'Secret Route',description:'Hidden gems',visibility:'private'},{token:'opaque-token',sharerName:'Stephanie',stopCount:3});
  const embed=payload.embeds[0].toJSON();
  assert.match(embed.description,/Private destinations/i);
  const labels=payload.components.flatMap(row=>row.toJSON().components.map(component=>component.label));
  assert.deepEqual(labels,['Start Self-Paced Tour','Tour Information','Copy Tour to My AddressBook','Report a Problem']);
});
