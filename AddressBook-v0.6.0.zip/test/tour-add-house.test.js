import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { openDatabase, migrate, closeDatabase } from '../src/db/database.js';
import { createHandlers } from '../src/handlers.js';
import { TourService } from '../src/services/tour-service.js';

test('Add House resolves the eligible-house payload before updating Discord', async () => {
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'ab-tour-add-'));
  const db=openDatabase({DB_TYPE:'sqlite',DATABASE_PATH:path.join(dir,'tour-add.sqlite')});
  try{
    await migrate(db);
    await db.query("INSERT INTO houses(house_id,name,normalized_name) VALUES(1,'Test House','test house')");
    await db.query("INSERT INTO saved_houses(scope,guild_id,origin_guild_id,owner_user_id,house_id,eso_owner,normalized_owner,status,created_by,updated_by) VALUES('private',NULL,NULL,'user-1',1,'Owner','owner','active','user-1','user-1')");
    const tour=await new TourService(db).create({creatorId:'user-1',guildId:'guild-1',visibility:'private',sourceGuildId:'guild-1',name:'Test Tour'});
    const handlers=createHandlers(db);
    let updated;
    const interaction={
      customId:`hu:tour:add:${tour.id}`,
      guildId:'guild-1',channelId:'channel-1',user:{id:'user-1'},
      member:{roles:{cache:{has:()=>false}}},
      update(payload){
        assert.equal(typeof payload?.then,'undefined','interaction.update received an unresolved Promise');
        updated=payload;
        return Promise.resolve(payload);
      },
      reply(){throw new Error('The Add House interaction unexpectedly replied instead of updating.');}
    };
    await handlers.button(interaction);
    assert.match(updated.embeds[0].data.title,/Add House/);
    assert.equal(updated.components[0].toJSON().components[0].options[0].label,'Test House — @Owner');
  }finally{await closeDatabase(db);}
});

test('new tour creation resolves the initial Add House payload before updating Discord', async () => {
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'ab-tour-create-add-'));
  const db=openDatabase({DB_TYPE:'sqlite',DATABASE_PATH:path.join(dir,'tour-create-add.sqlite')});
  try{
    await migrate(db);
    await db.query("INSERT INTO houses(house_id,name,normalized_name) VALUES(1,'Test House','test house')");
    await db.query("INSERT INTO saved_houses(scope,guild_id,origin_guild_id,owner_user_id,house_id,eso_owner,normalized_owner,status,created_by,updated_by) VALUES('private',NULL,NULL,'user-1',1,'Owner','owner','active','user-1','user-1')");
    const handlers=createHandlers(db);
    let visibilityPayload;
    const base={guildId:'guild-1',channelId:'channel-1',user:{id:'user-1'},member:{roles:{cache:{has:()=>false}}}};
    await handlers.modal({
      ...base,customId:'hu:modal:tour:create',isFromMessage:()=>true,
      fields:{getTextInputValue:id=>id==='name'?'New Tour':''},
      update(payload){visibilityPayload=payload;return Promise.resolve(payload);},
      reply(){throw new Error('Tour creation unexpectedly replied instead of updating.');}
    });
    const visibilityButtons=visibilityPayload.components.flatMap(row=>row.toJSON().components);
    const privateButton=visibilityButtons.find(component=>component.label==='Private Tour');
    assert.ok(privateButton,'Private Tour visibility button was not rendered.');
    let updated;
    await handlers.button({
      ...base,customId:privateButton.custom_id,
      update(payload){
        assert.equal(typeof payload?.then,'undefined','interaction.update received an unresolved Promise');
        updated=payload;
        return Promise.resolve(payload);
      },
      reply(){throw new Error('The initial Add House interaction unexpectedly replied.');}
    });
    assert.match(updated.embeds[0].data.title,/Add House/);
  }finally{await closeDatabase(db);}
});
