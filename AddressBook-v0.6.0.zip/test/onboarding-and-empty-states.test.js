import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { closeDatabase, migrate, openDatabase } from '../src/db/database.js';
import { MyAddressBookService } from '../src/services/my-addressbook-service.js';
import { OnboardingService } from '../src/services/onboarding-service.js';
import { commentsPayload, myAddressBookPayload, myPendingPayload, onboardingPayload, toursPayload } from '../src/ui/housing-ui.js';

const labels=payload=>payload.components.flatMap(row=>row.toJSON().components.map(component=>component.label)).filter(Boolean);

async function fixture(){
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'addressbook-onboarding-'));
  const db=openDatabase({DB_TYPE:'sqlite',DATABASE_PATH:path.join(dir,'onboarding.sqlite')});
  await migrate(db);return {db,onboarding:new OnboardingService(db),addressBook:new MyAddressBookService(db)};
}

test('first-use introduction has five choices and exactly three guided screens',()=>{
  assert.deepEqual(labels(onboardingPayload({page:0})),['Find a House','Register a House','Start a Tour','Show Me Around','Skip']);
  for(const page of [1,2,3])assert.match(onboardingPayload({page}).embeds[0].toJSON().title,new RegExp(`${page} of 3`));
  assert.ok(labels(onboardingPayload({page:1})).includes('Next'));
  assert.ok(labels(onboardingPayload({page:2})).includes('Next'));
  assert.ok(labels(onboardingPayload({page:3})).includes('Finish'));
});

test('completion and skip persist idempotently while replay does not clear status',async()=>{
  const {db,onboarding}=await fixture();
  try{
    assert.equal(await onboarding.get('u1'),null);
    assert.equal((await onboarding.complete('u1',{globalName:'User One',displayName:'One'})).status,'completed');
    assert.equal((await onboarding.complete('u1')).status,'completed');
    assert.equal((await onboarding.get('u1')).discord_global_name,'User One');
    assert.equal((await onboarding.skip('u2')).status,'skipped');
    assert.equal((await onboarding.get('u2')).status,'skipped');
  }finally{await closeDatabase(db);}
});

test('MariaDB onboarding completion binds a native date instead of an ISO timestamp string',async()=>{
  const writes=[];
  const db={type:'mariadb',query:async(sql,params=[])=>{
    if(/^SELECT /i.test(sql.trim()))return [{discord_user_id:'u1',status:'completed'}];
    writes.push({sql,params});
    return [];
  }};

  await new OnboardingService(db).complete('u1',{globalName:'User One',displayName:'One'});

  assert.equal(writes.length,1);
  assert.ok(writes[0].params[4] instanceof Date,'completed_at must be bound as a Date for MariaDB');
  assert.equal(writes[0].params[5],null);
});

test('continue items include only accessible active work',async()=>{
  const {db,addressBook}=await fixture();
  try{
    await db.query("INSERT INTO houses(house_id,name,normalized_name) VALUES(1,'House','house')");
    await db.query("INSERT INTO saved_houses(id,scope,guild_id,house_id,eso_owner,normalized_owner,status,created_by,updated_by) VALUES(1,'public','g1',1,'Owner','owner','active','u2','u2')");
    await db.query("INSERT INTO saved_houses(id,scope,guild_id,house_id,eso_owner,normalized_owner,status,created_by,updated_by) VALUES(2,'public','g2',1,'Hidden','hidden','active','u2','u2')");
    await db.query("INSERT INTO tours(id,visibility,creator_id,name,house_source) VALUES(1,'private','u1','My Tour','all')");
    await db.query("INSERT INTO tours(id,visibility,creator_id,name,house_source) VALUES(2,'private','u2','Not Mine','all')");
    await db.query("INSERT INTO tour_sessions(tour_id,guild_id,channel_id,mode,started_by,current_position) VALUES(1,'g1','c1','self_paced','u1',1)");
    await addressBook.recordView('u1',2);await addressBook.recordView('u1',1);
    const result=await addressBook.continueItems('u1','g1');
    assert.equal(result.activeTour.tour_name,'My Tour');
    assert.equal(result.recentHouse.id,1);
    assert.equal(result.editedTour.id,1);
    const payload=myAddressBookPayload({houses:0,tours:1,pending:0,recent:1,continueItems:result});
    assert.ok(labels(payload).includes('Resume Tour'));
    assert.ok(labels(payload).includes('Open Recent House'));
  }finally{await closeDatabase(db);}
});

test('empty states explain what to do and always provide a useful action plus Back',()=>{
  const payloads=[
    myPendingPayload(),
    toursPayload(0),
    commentsPayload({label:'House',owner:'Owner',rows:[],scope:'private',id:1,backId:'hu:home'}),
    myAddressBookPayload()
  ];
  for(const payload of payloads){
    const actionLabels=labels(payload);
    assert.ok(actionLabels.some(label=>!/^Back/.test(label)),actionLabels.join(','));
    assert.ok(actionLabels.some(label=>/^Back/.test(label)),actionLabels.join(','));
    assert.ok((payload.content||payload.embeds?.[0]?.toJSON().description||'').length>10);
  }
});
