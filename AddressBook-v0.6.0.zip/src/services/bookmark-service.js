import { SavedHouseService } from './saved-house-service.js';
export class BookmarkService{
  constructor(db){this.db=db;this.saved=new SavedHouseService(db);}
  adapt(r){return r?{...r,discord_user_id:r.owner_user_id,nickname:r.display_name,notes:r.description,scope:'personal'}:null;}
  async create({userId,houseId,esoOwner,nickname=null,notes=null,tags=[]}){return this.adapt(await this.saved.createPrivate({userId,houseId,esoOwner,displayName:nickname,description:notes,tags,createdBy:userId}));}
  async get(id,userId){const r=await this.saved.get(id);return r&&r.scope==='private'&&r.owner_user_id===userId&&r.status==='active'?this.adapt(r):null;}
  async list(userId){return (await this.saved.listPrivate(userId)).map(r=>this.adapt(r));}
  async update(id,userId,{houseId,esoOwner,nickname=null,notes=null,tags=[]}){const current=await this.get(id,userId);if(!current)return null;return this.adapt(await this.saved.update(id,{houseId,esoOwner,displayName:nickname,description:notes,tags},userId));}
  async remove(id,userId){const current=await this.get(id,userId);if(!current)return false;return this.saved.delete(id,userId);}
}
