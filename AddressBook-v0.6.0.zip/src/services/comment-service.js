import { one } from '../db/database.js';
export class CommentService{
  constructor(db){this.db=db;}
  async add({destinationId=null,savedHouseId=null,commenterUserId,text}){const target=savedHouseId==null?null:await one(this.db,"SELECT id,destination_id FROM saved_houses WHERE id=? AND status='active'",[Number(savedHouseId)]);const resolved=destinationId??target?.destination_id;if(!resolved)throw new Error('Saved house not found.');const value=String(text||'').trim();if(!value)throw new Error('Comment cannot be empty.');const info=await this.db.query('INSERT INTO house_comments(destination_id,saved_house_id,legacy_saved_house_id,discord_user_id,comment_text) VALUES(?,?,?,?,?)',[Number(resolved),target?.id??null,target?.id??null,String(commenterUserId),value]);return one(this.db,'SELECT * FROM house_comments WHERE id=?',[info.insertId]);}
  addPersonal({bookmarkId,commenterUserId,text}){return this.add({savedHouseId:bookmarkId,commenterUserId,text});}
  addServer({registrationId,commenterUserId,text}){return this.add({savedHouseId:registrationId,commenterUserId,text});}
  addGlobal({savedHouseId,commenterUserId,text}){return this.add({savedHouseId,commenterUserId,text});}
  async list(_scope,targetId,limit=5){const target=await one(this.db,'SELECT destination_id FROM saved_houses WHERE id=?',[Number(targetId)]);return target?this.listByDestination(target.destination_id,limit):[];}
  async count(_scope,targetId){const target=await one(this.db,'SELECT destination_id FROM saved_houses WHERE id=?',[Number(targetId)]);return target?this.countByDestination(target.destination_id):0;}
  listByDestination(destinationId,limit=5){return this.db.query("SELECT * FROM house_comments WHERE destination_id=? AND status='active' ORDER BY created_at DESC,id DESC LIMIT ?",[Number(destinationId),Number(limit)]);}
  async countByDestination(destinationId){const r=await one(this.db,"SELECT count(*) c FROM house_comments WHERE destination_id=? AND status='active'",[Number(destinationId)]);return Number(r?.c||0);}
}
