import { one } from '../db/database.js';
import { normalizeAccount, normalizeEsoOwner, stripLeadingAt } from '../utils/eso.js';

function isUniqueViolation(error){
  return Number(error?.errcode)===2067||error?.code==='ER_DUP_ENTRY'||error?.code==='SQLITE_CONSTRAINT_UNIQUE';
}

export class DestinationService{
  constructor(db){this.db=db;}

  async resolve({esoOwner,houseId},conn=this.db){
    const owner=stripLeadingAt(normalizeEsoOwner(esoOwner));
    const normalizedOwner=normalizeAccount(owner);
    const numericHouseId=Number(houseId);
    if(!Number.isInteger(numericHouseId)||numericHouseId<=0)throw new Error('A valid ESO owner and official house ID are required.');
    const existing=await one(conn,'SELECT * FROM housing_destinations WHERE normalized_owner=? AND house_id=?',[normalizedOwner,numericHouseId]);
    if(existing)return existing;
    try{
      await conn.query('INSERT INTO housing_destinations(eso_owner,normalized_owner,house_id) VALUES(?,?,?)',[owner,normalizedOwner,numericHouseId]);
    }catch(error){
      if(!isUniqueViolation(error))throw error;
    }
    return one(conn,'SELECT * FROM housing_destinations WHERE normalized_owner=? AND house_id=?',[normalizedOwner,numericHouseId]);
  }

  get(id,conn=this.db){
    return one(conn,'SELECT * FROM housing_destinations WHERE id=?',[Number(id)]);
  }
}
