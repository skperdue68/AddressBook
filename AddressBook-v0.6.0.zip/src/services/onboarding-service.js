import { one } from '../db/database.js';

export class OnboardingService{
  constructor(db){this.db=db;}
  get(userId){return one(this.db,'SELECT * FROM user_onboarding WHERE discord_user_id=?',[String(userId)]);}
  async #set(userId,status,{globalName=null,displayName=null}={}){
    const now=new Date(),timestamp=this.db.type==='sqlite'?now.toISOString():now;
    const id=String(userId),completed=status==='completed'?timestamp:null,skipped=status==='skipped'?timestamp:null;
    if(this.db.type==='sqlite')await this.db.query(`INSERT INTO user_onboarding(discord_user_id,discord_global_name,discord_display_name,status,completed_at,skipped_at)
      VALUES(?,?,?,?,?,?) ON CONFLICT(discord_user_id) DO UPDATE SET
      discord_global_name=coalesce(excluded.discord_global_name,user_onboarding.discord_global_name),discord_display_name=coalesce(excluded.discord_display_name,user_onboarding.discord_display_name),
      status=excluded.status,completed_at=coalesce(excluded.completed_at,user_onboarding.completed_at),skipped_at=coalesce(excluded.skipped_at,user_onboarding.skipped_at),updated_at=CURRENT_TIMESTAMP`,[id,globalName,displayName,status,completed,skipped]);
    else await this.db.query(`INSERT INTO user_onboarding(discord_user_id,discord_global_name,discord_display_name,status,completed_at,skipped_at)
      VALUES(?,?,?,?,?,?) ON DUPLICATE KEY UPDATE discord_global_name=coalesce(VALUES(discord_global_name),discord_global_name),discord_display_name=coalesce(VALUES(discord_display_name),discord_display_name),status=VALUES(status),completed_at=coalesce(VALUES(completed_at),completed_at),skipped_at=coalesce(VALUES(skipped_at),skipped_at),updated_at=CURRENT_TIMESTAMP`,[id,globalName,displayName,status,completed,skipped]);
    return this.get(id);
  }
  complete(userId,names){return this.#set(userId,'completed',names);}
  skip(userId,names){return this.#set(userId,'skipped',names);}
}
