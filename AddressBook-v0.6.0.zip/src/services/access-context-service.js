import { one } from '../db/database.js';

const same=(a,b)=>a!=null&&b!=null&&String(a)===String(b);

function houseNormalAccess(house,{userId,guildId}){
  if(!house||house.status!=='active')return false;
  if(house.scope==='global')return true;
  if(house.scope==='public')return same(house.guild_id,guildId);
  return house.scope==='private'&&same(house.owner_user_id,userId);
}

function tourNormalAccess(tour,{userId,guildId}){
  if(!tour)return false;
  if(tour.visibility==='global')return true;
  if(tour.visibility==='public')return same(tour.guild_id,guildId);
  return tour.visibility==='private'&&same(tour.creator_id,userId);
}

export class AccessContextService{
  constructor(db){this.db=db;}

  async forHouse({userId,guildId,savedHouseId,passId=null,conn=this.db}){
    const house=await one(conn,'SELECT * FROM saved_houses WHERE id=?',[Number(savedHouseId)]);
    const normalAccess=houseNormalAccess(house,{userId,guildId});
    const pass=passId==null?null:await one(conn,"SELECT * FROM house_share_passes WHERE id=? AND status='active'",[Number(passId)]);
    const passAccess=!!house&&!!pass&&same(pass.saved_house_id,house.id);
    const passOnly=passAccess&&!normalAccess;
    const owner=house?.scope==='private'&&same(house.owner_user_id,userId);
    return {
      record:house,pass,normalAccess,passOnly,canView:normalAccess||passAccess,
      canShare:normalAccess&&(house?.scope!=='private'||owner),
      canEdit:normalAccess&&(owner||same(house?.created_by,userId)),
      canCopy:passOnly&&house?.scope==='private'&&!owner,
      canComment:normalAccess||passAccess,canReport:normalAccess||passAccess
    };
  }

  async forTour({userId,guildId,tourId,passId=null,conn=this.db}){
    const tour=await one(conn,'SELECT * FROM tours WHERE id=?',[Number(tourId)]);
    const normalAccess=tourNormalAccess(tour,{userId,guildId});
    const pass=passId==null?null:await one(conn,"SELECT * FROM tour_share_passes WHERE id=? AND status='active'",[Number(passId)]);
    const passAccess=!!tour&&!!pass&&same(pass.tour_id,tour.id);
    const passOnly=passAccess&&!normalAccess;
    const owner=same(tour?.creator_id,userId);
    return {
      record:tour,pass,normalAccess,passOnly,canView:normalAccess||passAccess,
      canShare:normalAccess&&(tour?.visibility!=='private'||owner),
      canEdit:normalAccess&&owner,
      canCopy:passAccess,canReport:normalAccess||passAccess,canStart:normalAccess||passAccess
    };
  }
}
