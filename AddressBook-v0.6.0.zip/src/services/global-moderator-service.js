import { one, withTransaction } from '../db/database.js';

export function globalModeratorApproverIds(env=process.env){
  return new Set(String(env.GLOBAL_MODERATOR_APPROVER_USER_IDS||'').split(',').map(v=>v.trim()).filter(Boolean));
}

export class GlobalModeratorService{
  constructor(db,env=process.env){this.db=db;this.approvers=globalModeratorApproverIds(env);this.cache=new Map();}
  isApprover(userId){return this.approvers.has(String(userId||''));}
  async ensureUser(userId){const id=String(userId||'');if(this.cache.has(id))return this.cache.get(id);const value=!!await one(this.db,'SELECT discord_user_id FROM global_moderators WHERE discord_user_id=?',[id]);this.cache.set(id,value);return value;}
  isGlobalModeratorCached(userId){return this.cache.get(String(userId||''))===true;}
  isGlobalModerator(userId){return this.ensureUser(userId);}
  async requestAccess({userId,guildId,reason}){
    const text=String(reason||'').trim();if(!text)throw new Error('A reason is required when requesting Global Housing Moderator access.');
    if(await this.isGlobalModerator(userId))throw new Error('You already have Global Housing Moderator access.');
    const pending=await one(this.db,"SELECT id FROM global_moderator_requests WHERE discord_user_id=? AND status='pending'",[String(userId)]);if(pending)throw new Error('You already have a pending Global Housing Moderator request.');
    const r=await this.db.query('INSERT INTO global_moderator_requests(discord_user_id,origin_guild_id,reason) VALUES(?,?,?)',[String(userId),String(guildId),text]);return one(this.db,'SELECT * FROM global_moderator_requests WHERE id=?',[r.insertId]);
  }
  listPending(){return this.db.query("SELECT * FROM global_moderator_requests WHERE status='pending' ORDER BY requested_at,id");}
  listModerators(){return this.db.query('SELECT * FROM global_moderators ORDER BY approved_at,discord_user_id');}
  async approve(requestId,approverId){if(!this.isApprover(approverId))throw new Error('Only a configured Global Moderator approver can approve this request.');return withTransaction(this.db,async conn=>{const req=await one(conn,"SELECT * FROM global_moderator_requests WHERE id=? AND status='pending' FOR UPDATE",[Number(requestId)]);if(!req)throw new Error('Pending Global Moderator request not found.');await conn.query(`INSERT INTO global_moderators(discord_user_id,approved_by,request_id) VALUES(?,?,?) ON DUPLICATE KEY UPDATE approved_by=VALUES(approved_by),request_id=VALUES(request_id),approved_at=CURRENT_TIMESTAMP`,[req.discord_user_id,String(approverId),req.id]);this.cache.set(String(req.discord_user_id),true);await conn.query("UPDATE global_moderator_requests SET status='approved',reviewed_by=?,reviewed_at=CURRENT_TIMESTAMP WHERE id=?",[String(approverId),req.id]);await conn.query('INSERT INTO audit_log(guild_id,actor_id,action,entity_type,entity_id,details) VALUES(?,?,?,?,?,?)',[req.origin_guild_id||null,String(approverId),'approve_global_moderator','discord_user',String(req.discord_user_id),JSON.stringify({requestId:req.id})]);return req;});}
  async deny(requestId,approverId){if(!this.isApprover(approverId))throw new Error('Only a configured Global Moderator approver can deny this request.');const req=await one(this.db,"SELECT * FROM global_moderator_requests WHERE id=? AND status='pending'",[Number(requestId)]);if(!req)throw new Error('Pending Global Moderator request not found.');await withTransaction(this.db,async conn=>{await conn.query("UPDATE global_moderator_requests SET status='denied',reviewed_by=?,reviewed_at=CURRENT_TIMESTAMP WHERE id=?",[String(approverId),Number(requestId)]);await conn.query('INSERT INTO audit_log(guild_id,actor_id,action,entity_type,entity_id,details) VALUES(?,?,?,?,?,?)',[req.origin_guild_id||null,String(approverId),'deny_global_moderator','discord_user',String(req.discord_user_id),JSON.stringify({requestId:req.id})]);});return req;}
  async revoke(userId,approverId){if(!this.isApprover(approverId))throw new Error('Only a configured Global Moderator approver can revoke Global Moderator access.');const removed=await withTransaction(this.db,async conn=>{const r=await conn.query('DELETE FROM global_moderators WHERE discord_user_id=?',[String(userId)]);if(Number(r.affectedRows||0)>0)await conn.query('INSERT INTO audit_log(guild_id,actor_id,action,entity_type,entity_id,details) VALUES(NULL,?,?,?,?,?)',[String(approverId),'revoke_global_moderator','discord_user',String(userId),JSON.stringify({})]);return Number(r.affectedRows||0)>0;});this.cache.set(String(userId),false);return removed;}
}
