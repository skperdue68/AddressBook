import { one, withTransaction } from '../db/database.js';
import { AccessContextService } from './access-context-service.js';
import { RateLimitService, rateLimitSettings } from './rate-limit-service.js';
import { ShareTokenService } from './share-token-service.js';
import { TourReadinessService } from './tour-readiness-service.js';

export class SharePassService{
  constructor(db,{tokens=new ShareTokenService(),rateLimiter=new RateLimitService(),settings=rateLimitSettings()}={}){
    this.db=db;this.tokens=tokens;this.rateLimiter=rateLimiter;this.settings=settings;this.access=new AccessContextService(db);this.readiness=new TourReadinessService(db);
  }

  #consume(userId){
    const result=this.rateLimiter.consume({bucket:'share-pass',userId,...this.settings.share});
    if(!result.allowed)throw new Error(`Please wait ${Math.ceil(result.retryAfterMs/1000)} seconds before using another Share Pass.`);
  }

  async createHousePass({savedHouseId,createdBy,originGuildId=null,channelId=null,names={}}){
    this.#consume(createdBy);
    const access=await this.access.forHouse({userId:createdBy,guildId:originGuildId,savedHouseId});
    if(!access.canShare)throw new Error('You need normal access, and Private houses can only be shared by their owner.');
    const issued=this.tokens.issue();
    const result=await this.db.query(`INSERT INTO house_share_passes(
      token_hash,saved_house_id,created_by,created_by_global_name,created_by_display_name,
      origin_guild_id,origin_guild_name,channel_id,channel_name,status
    ) VALUES(?,?,?,?,?,?,?,?,?,'active')`,[
      issued.hash,Number(savedHouseId),String(createdBy),names.createdByGlobalName||null,names.createdByDisplayName||null,
      originGuildId,names.originGuildName||null,channelId,names.channelName||null
    ]);
    const pass=await one(this.db,'SELECT * FROM house_share_passes WHERE id=?',[result.insertId]);
    await this.#audit({guildId:originGuildId,actorId:createdBy,action:'house_pass_created',entityId:pass.id,details:{savedHouseId}});
    return {pass,token:issued.token};
  }

  async markHousePassPosted(id,{guildId=null,channelId,messageId,channelName=null}){
    await this.db.query('UPDATE house_share_passes SET origin_guild_id=coalesce(?,origin_guild_id),channel_id=?,channel_name=?,message_id=? WHERE id=?',[guildId,channelId,channelName,messageId,Number(id)]);
    return one(this.db,'SELECT * FROM house_share_passes WHERE id=?',[Number(id)]);
  }

  async resolveHousePass(token,{userId,guildId}){
    this.#consume(userId);
    const hash=this.tokens.hash(token),pass=await one(this.db,'SELECT * FROM house_share_passes WHERE token_hash=?',[hash]);
    if(!pass)throw new Error('This share card is no longer connected to an active pass.');
    if(pass.status!=='active')throw new Error('This Share Pass was revoked by its owner.');
    if(pass.saved_house_id==null)throw new Error('This house is no longer available.');
    const access=await this.access.forHouse({userId,guildId,savedHouseId:pass.saved_house_id,passId:pass.id});
    if(!access.canView)throw new Error('This share card is no longer connected to an active pass.');
    await this.db.query('UPDATE house_share_passes SET usage_count=usage_count+1,last_used_at=CURRENT_TIMESTAMP WHERE id=?',[pass.id]);
    await this.#audit({guildId,actorId:userId,action:'house_pass_used',entityId:pass.id,details:{savedHouseId:pass.saved_house_id}});
    return {pass:await one(this.db,'SELECT * FROM house_share_passes WHERE id=?',[pass.id]),house:access.record,access};
  }

  async repostHousePass(id,{actorId,guildId=null,channelId=null,messageId=null,channelName=null}){
    return withTransaction(this.db,async conn=>{
      const pass=await one(conn,'SELECT * FROM house_share_passes WHERE id=?',[Number(id)]);
      if(!pass||pass.status!=='active')throw new Error('That House Share Pass is not active.');
      if(String(pass.created_by)!==String(actorId))throw new Error('Only the Share Pass creator can repost this card.');
      const issued=this.tokens.issue();
      await conn.query('UPDATE house_share_passes SET token_hash=?,origin_guild_id=coalesce(?,origin_guild_id),channel_id=?,channel_name=?,message_id=? WHERE id=?',[issued.hash,guildId,channelId,channelName,messageId,pass.id]);
      await this.#audit({conn,guildId:guildId||pass.origin_guild_id,actorId,action:'house_pass_reposted',entityId:pass.id,details:{channelId,messageId}});
      return {pass:await one(conn,'SELECT * FROM house_share_passes WHERE id=?',[pass.id]),token:issued.token};
    });
  }

  async revokeHousePass(id,{actorId,reason=null,isServerModerator=false,isGlobalModerator=false}={}){
    return withTransaction(this.db,async conn=>{
      const pass=await one(conn,'SELECT * FROM house_share_passes WHERE id=?',[Number(id)]);
      if(!pass)throw new Error('House Share Pass not found.');
      const house=pass.saved_house_id==null?null:await one(conn,'SELECT * FROM saved_houses WHERE id=?',[pass.saved_house_id]);
      const creator=String(pass.created_by)===String(actorId);
      const moderatorAllowed=house?.scope==='public'&&isServerModerator||house?.scope==='global'&&isGlobalModerator;
      if(!creator&&!moderatorAllowed)throw new Error('Only the Share Pass creator or an authorized moderator can revoke it.');
      if(pass.status==='revoked')return pass;
      await conn.query("UPDATE house_share_passes SET status='revoked',revoked_at=CURRENT_TIMESTAMP,revoked_by=?,revocation_reason=? WHERE id=?",[String(actorId),reason||null,pass.id]);
      await this.#audit({conn,guildId:pass.origin_guild_id,actorId,action:'house_pass_revoked',entityId:pass.id,details:{reason}});
      return one(conn,'SELECT * FROM house_share_passes WHERE id=?',[pass.id]);
    });
  }

  listHousePasses(createdBy,{limit=25,offset=0}={}){
    return this.db.query('SELECT * FROM house_share_passes WHERE created_by=? ORDER BY created_at DESC,id DESC LIMIT ? OFFSET ?',[String(createdBy),Number(limit),Number(offset)]);
  }

  async createTourPass({tourId,createdBy,originGuildId=null,channelId=null,names={}}){
    this.#consume(createdBy);
    const access=await this.access.forTour({userId:createdBy,guildId:originGuildId,tourId});
    if(!access.canShare)throw new Error('You need normal access, and Private tours can only be shared by their creator.');
    const readiness=await this.readiness.check(tourId,{viewerId:createdBy,guildId:originGuildId});
    if(readiness.blocking.length)throw new Error(readiness.blocking[0].message);
    const issued=this.tokens.issue();
    const result=await this.db.query(`INSERT INTO tour_share_passes(
      token_hash,tour_id,created_by,created_by_global_name,created_by_display_name,
      origin_guild_id,origin_guild_name,channel_id,channel_name,status
    ) VALUES(?,?,?,?,?,?,?,?,?,'active')`,[
      issued.hash,Number(tourId),String(createdBy),names.createdByGlobalName||null,names.createdByDisplayName||null,
      originGuildId,names.originGuildName||null,channelId,names.channelName||null
    ]);
    const pass=await one(this.db,'SELECT * FROM tour_share_passes WHERE id=?',[result.insertId]);
    await this.#tourAudit({guildId:originGuildId,actorId:createdBy,action:'tour_pass_created',entityId:pass.id,details:{tourId}});
    return {pass,token:issued.token,readiness};
  }

  async markTourPassPosted(id,{guildId=null,channelId,messageId,channelName=null}){
    await this.db.query('UPDATE tour_share_passes SET origin_guild_id=coalesce(?,origin_guild_id),channel_id=?,channel_name=?,message_id=? WHERE id=?',[guildId,channelId,channelName,messageId,Number(id)]);
    return one(this.db,'SELECT * FROM tour_share_passes WHERE id=?',[Number(id)]);
  }

  async resolveTourPass(token,{userId,guildId}){
    this.#consume(userId);
    const hash=this.tokens.hash(token),pass=await one(this.db,'SELECT * FROM tour_share_passes WHERE token_hash=?',[hash]);
    if(!pass)throw new Error('This share card is no longer connected to an active pass.');
    if(pass.status!=='active')throw new Error('This Share Pass was revoked by its owner.');
    if(pass.tour_id==null)throw new Error('This tour is no longer available.');
    const access=await this.access.forTour({userId,guildId,tourId:pass.tour_id,passId:pass.id});
    if(!access.canView)throw new Error('This share card is no longer connected to an active pass.');
    const readiness=await this.readiness.check(pass.tour_id,{viewerId:userId,guildId,passId:pass.id});
    if(readiness.blocking.length)throw new Error(readiness.blocking[0].message);
    const stops=await this.db.query(`SELECT ts.*,sh.destination_id,sh.scope,sh.eso_owner,sh.house_id,sh.display_name,h.name house_name
      FROM tour_stops ts JOIN saved_houses sh ON sh.id=ts.saved_house_id JOIN houses h ON h.house_id=sh.house_id
      WHERE ts.tour_id=? ORDER BY ts.position`,[pass.tour_id]);
    await this.db.query('UPDATE tour_share_passes SET usage_count=usage_count+1,last_used_at=CURRENT_TIMESTAMP WHERE id=?',[pass.id]);
    await this.#tourAudit({guildId,actorId:userId,action:'tour_pass_used',entityId:pass.id,details:{tourId:pass.tour_id}});
    return {pass:await one(this.db,'SELECT * FROM tour_share_passes WHERE id=?',[pass.id]),tour:access.record,stops,access,readiness};
  }

  async repostTourPass(id,{actorId,guildId=null,channelId=null,messageId=null,channelName=null}){
    return withTransaction(this.db,async conn=>{
      const pass=await one(conn,'SELECT * FROM tour_share_passes WHERE id=?',[Number(id)]);
      if(!pass||pass.status!=='active')throw new Error('That Tour Pass is not active.');
      if(String(pass.created_by)!==String(actorId))throw new Error('Only the Tour Pass creator can repost this card.');
      const issued=this.tokens.issue();
      await conn.query('UPDATE tour_share_passes SET token_hash=?,origin_guild_id=coalesce(?,origin_guild_id),channel_id=?,channel_name=?,message_id=? WHERE id=?',[issued.hash,guildId,channelId,channelName,messageId,pass.id]);
      await this.#tourAudit({conn,guildId:guildId||pass.origin_guild_id,actorId,action:'tour_pass_reposted',entityId:pass.id,details:{channelId,messageId}});
      return {pass:await one(conn,'SELECT * FROM tour_share_passes WHERE id=?',[pass.id]),token:issued.token};
    });
  }

  async revokeTourPass(id,{actorId,reason=null,isServerModerator=false,isGlobalModerator=false}={}){
    return withTransaction(this.db,async conn=>{
      const pass=await one(conn,'SELECT * FROM tour_share_passes WHERE id=?',[Number(id)]);
      if(!pass)throw new Error('Tour Pass not found.');
      const tour=pass.tour_id==null?null:await one(conn,'SELECT * FROM tours WHERE id=?',[pass.tour_id]);
      const creator=String(pass.created_by)===String(actorId);
      const moderatorAllowed=tour?.visibility==='public'&&isServerModerator||tour?.visibility==='global'&&isGlobalModerator;
      if(!creator&&!moderatorAllowed)throw new Error('Only the Tour Pass creator or an authorized moderator can revoke it.');
      if(pass.status==='revoked')return pass;
      const sessions=await conn.query('SELECT id,tour_session_id FROM share_pass_sessions WHERE tour_share_pass_id=? AND closed_at IS NULL',[pass.id]);
      for(const session of sessions)if(session.tour_session_id!=null)await conn.query('DELETE FROM tour_sessions WHERE id=?',[session.tour_session_id]);
      await conn.query('UPDATE share_pass_sessions SET closed_at=CURRENT_TIMESTAMP,close_reason=? WHERE tour_share_pass_id=? AND closed_at IS NULL',['pass_revoked',pass.id]);
      await conn.query("UPDATE tour_share_passes SET status='revoked',revoked_at=CURRENT_TIMESTAMP,revoked_by=?,revocation_reason=? WHERE id=?",[String(actorId),reason||null,pass.id]);
      await this.#tourAudit({conn,guildId:pass.origin_guild_id,actorId,action:'tour_pass_revoked',entityId:pass.id,details:{reason,closedSessions:sessions.length}});
      return one(conn,'SELECT * FROM tour_share_passes WHERE id=?',[pass.id]);
    });
  }

  listTourPasses(createdBy,{limit=25,offset=0}={}){
    return this.db.query('SELECT * FROM tour_share_passes WHERE created_by=? ORDER BY created_at DESC,id DESC LIMIT ? OFFSET ?',[String(createdBy),Number(limit),Number(offset)]);
  }

  async #audit({conn=this.db,guildId,actorId,action,entityId,details}){
    await conn.query('INSERT INTO audit_log(guild_id,actor_id,action,entity_type,entity_id,details) VALUES(?,?,?,?,?,?)',[guildId||null,String(actorId),action,'house_share_pass',String(entityId),JSON.stringify(details||{})]);
  }

  async #tourAudit({conn=this.db,guildId,actorId,action,entityId,details}){
    await conn.query('INSERT INTO audit_log(guild_id,actor_id,action,entity_type,entity_id,details) VALUES(?,?,?,?,?,?)',[guildId||null,String(actorId),action,'tour_share_pass',String(entityId),JSON.stringify(details||{})]);
  }
}
