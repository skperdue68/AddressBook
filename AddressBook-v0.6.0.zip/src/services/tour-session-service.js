import { one, withTransaction } from '../db/database.js';

export class TourSessionService{
  constructor(db){this.db=db;}
  get(id){return one(this.db,'SELECT * FROM tour_sessions WHERE id=?',[Number(id)]);}
  async startSelfPaced({tourId,guildId,channelId,userId,messageId=null}){
    return withTransaction(this.db,async conn=>{
      await conn.query("DELETE FROM tour_sessions WHERE guild_id=? AND channel_id=? AND mode='self_paced' AND started_by=?",[guildId,channelId,userId]);
      const r=await conn.query("INSERT INTO tour_sessions(tour_id,guild_id,channel_id,mode,started_by,message_id,current_position) VALUES(?,?,?,'self_paced',?,?,1)",[Number(tourId),guildId,channelId,userId,messageId]);
      return one(conn,'SELECT * FROM tour_sessions WHERE id=?',[r.insertId]);
    });
  }
  async startShared({tourId,guildId,channelId,userId,messageId=null}){
    return withTransaction(this.db,async conn=>{
      await conn.query("DELETE FROM tour_sessions WHERE guild_id=? AND channel_id=? AND mode='shared'",[guildId,channelId]);
      const r=await conn.query("INSERT INTO tour_sessions(tour_id,guild_id,channel_id,mode,started_by,message_id,current_position) VALUES(?,?,?,'shared',?,?,1)",[Number(tourId),guildId,channelId,userId,messageId]);
      return one(conn,'SELECT * FROM tour_sessions WHERE id=?',[r.insertId]);
    });
  }
  async startFromPass({passId,tourId,guildId,channelId,userId,messageId=null}){
    return withTransaction(this.db,async conn=>{
      const pass=await one(conn,"SELECT id FROM tour_share_passes WHERE id=? AND tour_id=? AND status='active'",[Number(passId),Number(tourId)]);
      if(!pass)throw new Error('This Share Pass was revoked by its owner.');
      await conn.query("DELETE FROM tour_sessions WHERE guild_id=? AND channel_id=? AND mode='self_paced' AND started_by=?",[guildId,channelId,userId]);
      const result=await conn.query("INSERT INTO tour_sessions(tour_id,guild_id,channel_id,mode,started_by,message_id,current_position) VALUES(?,?,?,'self_paced',?,?,1)",[Number(tourId),guildId,channelId,userId,messageId]);
      await conn.query('INSERT INTO share_pass_sessions(tour_share_pass_id,tour_session_id) VALUES(?,?)',[Number(passId),result.insertId]);
      return one(conn,'SELECT * FROM tour_sessions WHERE id=?',[result.insertId]);
    });
  }
  async closeByPass(passId,reason='pass_revoked'){
    return withTransaction(this.db,async conn=>{
      const rows=await conn.query('SELECT id,tour_session_id FROM share_pass_sessions WHERE tour_share_pass_id=? AND closed_at IS NULL',[Number(passId)]);
      for(const row of rows)if(row.tour_session_id!=null)await conn.query('DELETE FROM tour_sessions WHERE id=?',[row.tour_session_id]);
      await conn.query('UPDATE share_pass_sessions SET closed_at=CURRENT_TIMESTAMP,close_reason=? WHERE tour_share_pass_id=? AND closed_at IS NULL',[reason,Number(passId)]);
      return rows.length;
    });
  }
  async advance(id,delta,maxPosition){const current=await this.get(id);if(!current)return null;const next=Math.max(1,Math.min(Number(maxPosition)||1,Number(current.current_position)+(Number(delta)||0)));await this.db.query('UPDATE tour_sessions SET current_position=? WHERE id=?',[next,Number(id)]);return this.get(id);}
  async end(id){const r=await this.db.query('DELETE FROM tour_sessions WHERE id=?',[Number(id)]);return Number(r.affectedRows||0)>0;}
}
