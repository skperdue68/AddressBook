import { one } from '../db/database.js';

const parseIds=value=>{try{return Array.isArray(value)?value:JSON.parse(value||'[]');}catch{return[];}};

export class AdminHealthService{
  constructor(db,{version='0.6.0'}={}){this.db=db;this.version=version;}
  async snapshot({guildId,availableChannelIds=[]}={}){
    let connected='Disconnected';
    try{await this.db.query('SELECT 1 ok');connected='Connected';}catch{}
    const backend=this.db.type==='mariadb'?'MariaDB':'SQLite';
    const migration=await one(this.db,'SELECT version,applied_at FROM schema_migrations ORDER BY version DESC LIMIT 1').catch(()=>null);
    const settings=await one(this.db,'SELECT * FROM guild_settings WHERE guild_id=?',[guildId]).catch(()=>null);
    const pending=await one(this.db,"SELECT count(*) c FROM saved_houses WHERE status='pending' AND (guild_id=? OR origin_guild_id=?)",[guildId,guildId]).catch(()=>({c:0}));
    const requests=await one(this.db,"SELECT count(*) c FROM global_moderator_requests WHERE status='pending'",[]).catch(()=>({c:0}));
    const reports=await one(this.db,"SELECT count(*) c FROM housing_reports WHERE status IN ('open','reviewing') AND (guild_id=? OR guild_id IS NULL)",[guildId]).catch(()=>({c:0}));
    const passRows=await this.db.query(`SELECT 'house' kind,status,count(*) c FROM house_share_passes GROUP BY status UNION ALL SELECT 'tour' kind,status,count(*) c FROM tour_share_passes GROUP BY status`).catch(()=>[]);
    const passes={house:{active:0,revoked:0},tour:{active:0,revoked:0}};
    for(const row of passRows)if(passes[row.kind])passes[row.kind][row.status]=Number(row.c||0);
    const roles={moderator:parseIds(settings?.staff_role_ids).length,trusted:parseIds(settings?.registration_role_ids).length,tours:parseIds(settings?.tour_role_ids).length};
    const channelId=settings?.bot_channel_id||null;
    return {backend,connection:connected,version:this.version,channel:{id:channelId,name:settings?.bot_channel_name||null,missing:!!channelId&&availableChannelIds.length>0&&!availableChannelIds.map(String).includes(String(channelId))},registrationPolicy:settings?.registration_policy||'open',roleCounts:roles,pendingSubmissions:Number(pending?.c||0),globalModeratorRequests:Number(requests?.c||0),openReports:Number(reports?.c||0),passes,lastMigration:{version:Number(migration?.version||0),appliedAt:migration?.applied_at||null},backupReminder:'Database connectivity does not confirm a backup. Configure and verify an external backup schedule.'};
  }
}
