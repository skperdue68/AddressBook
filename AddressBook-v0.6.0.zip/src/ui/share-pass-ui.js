import { ActionRowBuilder, ChannelSelectMenuBuilder, ChannelType, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } from 'discord.js';
import { cleanDestinationEmbed, buttonRows } from './housing-ui.js';

export function sharedPrivateHousePayload(house,{token,passId,canCopy=false,backToTourId=null,showDetails=false}={}){
  const componentToken=token??passId;
  const embed=cleanDestinationEmbed(house,{showDetails});
  const current=embed.toJSON().description||'';
  embed.setDescription(`🔒 **Shared Private access** — this house remains excluded from normal search and browsing.\n\n${current}`.slice(0,4096));
  const actions=[];
  if(canCopy)actions.push({customId:`hu:pass:house:copy:${componentToken}`,label:'Copy to My AddressBook',style:'success'});
  actions.push(
    {customId:`hu:pass:house:comments:${componentToken}`,label:'Comments',style:'primary'},
    {customId:`hu:pass:house:details:${componentToken}`,label:showDetails?'Hide Details':'More Details',style:'primary'},
    {customId:`hu:pass:house:report:${componentToken}`,label:'Report a Problem',style:'secondary'}
  );
  if(backToTourId!=null)actions.push({customId:`hu:pass:tour:back:${backToTourId}`,label:'Back to Tour',style:'secondary'});
  return {embeds:[embed],components:buttonRows(actions)};
}

export function houseShareChannelPayload(savedHouseId){
  const select=new ChannelSelectMenuBuilder().setCustomId(`hu:pass:house:channel:${Number(savedHouseId)}`).setPlaceholder('Choose a channel for the Share Pass').setChannelTypes(ChannelType.GuildText,ChannelType.GuildAnnouncement).setMinValues(1).setMaxValues(1);
  return {content:'Choose the channel where AddressBook should post this revocable House Share Pass.',embeds:[],components:[new ActionRowBuilder().addComponents(select),...buttonRows([{customId:'hu:home',label:'Cancel',style:'secondary'}])]};
}

export function tourShareChannelPayload(tourId){
  const select=new ChannelSelectMenuBuilder().setCustomId(`hu:pass:tour:channel:${Number(tourId)}`).setPlaceholder('Choose a channel for the Tour Pass').setChannelTypes(ChannelType.GuildText,ChannelType.GuildAnnouncement).setMinValues(1).setMaxValues(1);
  return {content:'Choose the channel where AddressBook should post this reusable, revocable Tour Pass.',embeds:[],components:[new ActionRowBuilder().addComponents(select),...buttonRows([{customId:'hu:tours',label:'Cancel',style:'secondary'}])]};
}

export function houseShareCardPayload(house,{token,sharerName='A housing visitor'}={}){
  const embed=cleanDestinationEmbed(house).setDescription(`${house.scope==='private'?'🔒 This Private entry remains excluded from normal search and browsing.\n\n':''}Shared by **${sharerName}** through a revocable AddressBook Share Pass.`);
  return {embeds:[embed],components:buttonRows([{customId:`hu:pass:house:view:${token}`,label:'View Shared House',style:'success'},{customId:`hu:pass:house:report:${token}`,label:'Report a Problem',style:'secondary'}])};
}

export function housePassManagementPayload(rows,{page=0,pages=1}={}){
  const lines=rows.length?rows.map(row=>`**#${row.id}** • ${row.status==='active'?'Active':'Revoked'} • ${row.channel_name||row.channel_id||'Channel unavailable'} • Used ${row.usage_count||0} time(s)`).join('\n'):'No House Share Passes have been created.';
  const actions=[];
  if(page>0)actions.push({customId:`hu:pass:house:manage:${page-1}`,label:'Previous',style:'secondary'});
  if(page<pages-1)actions.push({customId:`hu:pass:house:manage:${page+1}`,label:'Next',style:'secondary'});
  actions.push({customId:'hu:home',label:'Back',style:'secondary'});
  return {content:`**Manage House Share Passes**\n${lines}`,embeds:[],components:buttonRows(actions)};
}

export function houseCopyVisibilityPayload(preview,{token}={}){
  const explanation=preview.choices.filter(choice=>!choice.enabled).map(choice=>`**${choice.label}:** ${choice.reason}`).join('\n');
  const embed=new EmbedBuilder().setColor(0x2b7ddd).setTitle('Copy House to My AddressBook').setDescription([
    `**Official house:** ${preview.destination.houseName}`,
    `**ESO owner:** @${String(preview.destination.esoOwner).replace(/^@/,'')}`,
    '', 'Choose the visibility for your independent saved entry. The ESO destination stays the same; nickname, description, and tags can be edited next.',
    explanation?'':null,explanation||null
  ].filter(value=>value!==null).join('\n'));
  return {embeds:[embed],components:buttonRows([
    ...preview.choices.map(choice=>({customId:`hu:pass:house:copyvisibility:${choice.visibility}:${token}`,label:choice.label,style:choice.visibility==='private'?'success':'primary',disabled:!choice.enabled})),
    {customId:`hu:pass:house:view:${token}`,label:'Cancel',style:'secondary'}
  ])};
}

function copyField(id,label,value,{paragraph=false}={}){
  const field=new TextInputBuilder().setCustomId(id).setLabel(label).setStyle(paragraph?TextInputStyle.Paragraph:TextInputStyle.Short).setRequired(false);
  if(String(value??''))field.setValue(String(value).slice(0,paragraph?4000:4000));
  return new ActionRowBuilder().addComponents(field);
}

export function houseCopyMetadataModal(preview,{token,visibility}={}){
  return new ModalBuilder().setCustomId(`hu:modal:pass:house:copy:${visibility}:${token}`).setTitle('Copy House Details').addComponents(
    copyField('nickname','Nickname',preview.metadata.nickname),
    copyField('description','Description',preview.metadata.description,{paragraph:true}),
    copyField('tags','Tags (comma separated)',preview.metadata.tags.join(', '))
  );
}

export function tourShareCardPayload(tour,{token,sharerName='A housing visitor',stopCount=0}={}){
  const visibility=tour.visibility==='global'?'Global':tour.visibility==='public'?'Server':'Private';
  const embed=new EmbedBuilder().setColor(0x2b7ddd).setTitle(`🗺️ ${tour.name}`).setDescription([
    tour.description||'A shared AddressBook housing tour.',
    '',`**Tour visibility:** ${visibility}`,`**Stops:** ${stopCount}`,`**Shared by:** ${sharerName}`,
    '',tour.visibility==='private'?'Private destinations are available only while using this Tour Pass and remain excluded from normal search.':'Private destinations, if any, are available only during the tour.'
  ].join('\n'));
  return {embeds:[embed],components:buttonRows([
    {customId:`hu:pass:tour:start:${token}`,label:'Start Self-Paced Tour',style:'success'},
    {customId:`hu:pass:tour:info:${token}`,label:'Tour Information',style:'primary'},
    {customId:`hu:pass:tour:copy:${token}`,label:'Copy Tour to My AddressBook',style:'secondary'},
    {customId:`hu:pass:tour:report:${token}`,label:'Report a Problem',style:'secondary'}
  ])};
}

export function tourCopyPreviewPayload(preview,{token}={}){
  const advisories=preview.advisories?.length?`\n\n⚠️ ${preview.advisories.map(item=>item.message).join(' ')}`:'';
  const embed=new EmbedBuilder().setColor(0x2b7ddd).setTitle('Copy Tour to My AddressBook').setDescription([
    `**${preview.name}** will become an independent Private tour owned by you.`,
    '',`**Total stops:** ${preview.totalStops}`,`**Existing saved entries reused:** ${preview.reusedStops}`,`**Private copies created:** ${preview.copiedStops}`,
    '', 'Later changes or revocation of the Share Pass will not alter your copied tour.',advisories
  ].join('\n'));
  return {embeds:[embed],components:buttonRows([
    {customId:`hu:pass:tour:copyconfirm:${token}`,label:'Copy Private Tour',style:'success'},
    {customId:`hu:pass:tour:info:${token}`,label:'Cancel',style:'secondary'}
  ])};
}
