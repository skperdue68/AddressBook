import crypto from 'node:crypto';
import { MessageFlags, PermissionFlagsBits } from 'discord.js';
import { HouseService } from '../services/house-service.js';
import { RegistrationService } from '../services/registration-service.js';
import { BookmarkService } from '../services/bookmark-service.js';
import { VisitService } from '../services/visit-service.js';
import { TourService, tourSourceForRows } from '../services/tour-service.js';
import { GuildService } from '../services/guild-service.js';
import { CommentService } from '../services/comment-service.js';
import { SavedHouseService } from '../services/saved-house-service.js';
import { TourSessionService } from '../services/tour-session-service.js';
import { GlobalModeratorService } from '../services/global-moderator-service.js';
import { MyAddressBookService } from '../services/my-addressbook-service.js';
import { RegistrationDraftService } from '../services/registration-draft-service.js';
import { SharePassService } from '../services/share-pass-service.js';
import { HouseCopyService } from '../services/house-copy-service.js';
import { TourCopyService } from '../services/tour-copy-service.js';
import { HousingReportService } from '../services/housing-report-service.js';
import { OnboardingService } from '../services/onboarding-service.js';
import { AdminHealthService } from '../services/admin-health-service.js';
import { destinationLabel } from '../utils/labels.js';
import { registrationScopeFromType } from '../utils/registration-routing.js';
import { resolveDestinationInput } from '../utils/destination-input.js';
import { normalizeAccount, parseTags as parseTagInput } from '../utils/eso.js';
import { tourEmbed, tourButtons } from '../utils/render.js';
import {
  homePayload, myAddressBookPayload, myPendingPayload, onboardingPayload, registrationTypePayload, toursPayload, helpPayload,
  pickerPayload, destinationMenuPayload, officialHousePayload, buttonRows,
  advancedSearchPayload, advancedAttributePayload, advancedManagePayload, advancedRemovePayload, advancedTextModal, searchFiltersModal, houseEditModal, registerHouseFormModal, confirmPayload,
  destinationInputModal, registrationDestinationReviewPayload, registrationMetadataModal, registrationFinalReviewPayload,
  commentsPayload, commentModal, tourDetailPayload, tourManagePayload, tourStartChoicePayload,
  tourCreateModal, tourVisibilityPayload, tourEditDetailsPayload,
  tourEditVisibilityPayload, tourEditModal, stopEditModal, reorderPayload, adminPayload, adminOtherRolesPayload, pendingReviewPayload,
  bulkTourChoicePayload, bulkTourSelectionPayload, bulkTourCreateModal, bulkTourVisibilityPayload,
  houseScopePayload, globalModeratorRequestModal, globalModeratorPayload,
  globalModeratorRequestsPayload, globalModeratorRequestReviewPayload, globalModeratorListPayload, globalModeratorRevokePayload, adminHealthPayload, adminSharePassesPayload
} from './housing-ui.js';
import { houseCopyMetadataModal, houseCopyVisibilityPayload, houseShareCardPayload, houseShareChannelPayload, sharedPrivateHousePayload, tourCopyPreviewPayload, tourShareCardPayload, tourShareChannelPayload } from './share-pass-ui.js';
import { reportExplanationModal, reportProblemTypePayload, reportQueuePayload, reportReviewPayload } from './report-ui.js';

const PAGE=25;
const parseTags=v=>{try{return Array.isArray(v)?v:JSON.parse(v||'[]')}catch{return []}};
const token=()=>crypto.randomBytes(7).toString('hex');
const text=v=>String(v??'').trim();

export function canControlTourSession(session,userId){
  return !!session&&String(session.started_by)===String(userId);
}

export function searchCriteria(searchType,filters={}){
  const labels={query:'Query',name:'House / Nickname',nickname:'Nickname',owner:'Owner',tag:'Tag / Theme',tags:'Tags / Themes',zone:'Zone',zones:'Zone',houseType:'Size / Type',houseTypes:'Size / Type',classification:'ESO Classification',classifications:'ESO Classification',style:'Architectural Style',styles:'Architectural Style',visibilities:'House Visibility',notOnPublicTours:'Tour Membership'};
  const visibilityLabels={global:'Global',public:'Server',private:'Private'};
  const lines=[];
  for(const [key,label] of Object.entries(labels)){
    const raw=filters[key];
    const vals=Array.isArray(raw)?raw.map(text).filter(Boolean):null;
    const value=key==='notOnPublicTours'?(raw?'Not on a Server or Global Tour':''):vals?(key==='visibilities'?['global','public','private'].filter(v=>vals.includes(v)).map(v=>visibilityLabels[v]).join(', '):key==='owners'?vals.map(v=>`@${v.replace(/^@/,'')}`).join(', '):vals.join(', ')):text(raw);
    if(value)lines.push(`• **${label}:** ${key==='owner'&&!value.startsWith('@')?'@':''}${value}`);
  }
  return `**Search Type:** ${searchType}
**Parameters:**
${lines.length?lines.join('\n'):'• No parameters supplied'}`;
}

export function createHousingMenu(db){
  const houses=new HouseService(db),regs=new RegistrationService(db),bookmarks=new BookmarkService(db),visits=new VisitService(db),tours=new TourService(db),guilds=new GuildService(db),comments=new CommentService(db),saved=new SavedHouseService(db),sessions=new TourSessionService(db),globalMods=new GlobalModeratorService(db),myAddressBook=new MyAddressBookService(db);
  const registrationDrafts=new RegistrationDraftService();
  const sharePasses=new SharePassService(db);
  const tourCopies=new TourCopyService(db);
  const reports=new HousingReportService(db);
  const onboarding=new OnboardingService(db);
  const adminHealth=new AdminHealthService(db,{version:'0.6.0'});
  const states=new Map();
  const drafts=new Map();
  const advancedStates=new Map();
  const bulkTourStates=new Map();

  const isAdmin=i=>!!i.guildId&&guilds.canAdmin(i);
  const isModerator=i=>!!i.guildId&&guilds.isModerator(i);
  const canRunSharedPublicTour=i=>!!i.guildId&&guilds.canRunSharedPublicTour(i);
  const houseCopies=i=>new HouseCopyService(db,{policy:{registrationOutcome:async({visibility})=>{
    if(visibility==='private')return {allowed:true,status:'active'};
    const permission=guilds.canRegister(i);
    return permission.allowed?{allowed:true,status:permission.status}:{allowed:false,status:null,reason:'You do not have a role allowed to register Server or Global houses in this server.'};
  }}});
  const canManageReg=(i,r)=>guilds.canManagePublicHouse(i,r);
  const canManageTour=(i,t)=>t.creator_id===i.user.id||(t.scope==='global'?globalMods.isGlobalModeratorCached(i.user.id):(t.scope==='server'&&isModerator(i)));
  const canRunSharedTour=(i,t)=>t.scope==='personal'?t.creator_id===i.user.id:t.scope==='global'?true:canRunSharedPublicTour(i);
  const canEditSaved=(i,r)=>r?.scope==='global'?(r.created_by===i.user.id||globalMods.isGlobalModeratorCached(i.user.id)):['personal','private'].includes(r?.scope)?(r.owner_user_id===i.user.id||r.created_by===i.user.id):canManageReg(i,r);
  const reportContext=i=>({viewerId:i.user.id,guildId:i.guildId,isServerModerator:isAdmin(i),isGlobalModerator:globalMods.isGlobalModeratorCached(i.user.id)});
  const reportNames=i=>({reporterGlobalName:i.user.globalName||i.user.username,reporterDisplayName:i.member?.displayName,guildName:i.guild?.name});
  async function reportTarget(i,kind,value){
    if(kind==='housepass'){
      const resolved=await sharePasses.resolveHousePass(value,{userId:i.user.id,guildId:i.guildId});
      return {destinationId:resolved.house.destination_id,savedHouseId:resolved.house.id,passId:resolved.pass.id,passType:'house'};
    }
    if(kind==='tourpass'){
      const resolved=await sharePasses.resolveTourPass(value,{userId:i.user.id,guildId:i.guildId}),first=resolved.stops[0];
      if(!first)throw new Error('This tour has no reportable destinations.');
      return {destinationId:first.destination_id,savedHouseId:first.saved_house_id,tourId:resolved.tour.id,stopId:first.id,passId:resolved.pass.id,passType:'tour'};
    }
    if(kind==='houseid'){
      const house=await saved.getVisible(Number(value),{userId:i.user.id,guildId:i.guildId});
      if(!house)throw new Error('That house is no longer available.');
      return {destinationId:house.destination_id,savedHouseId:house.id};
    }
    if(kind==='tourid'){
      const tour=await tourById(i,Number(value)),first=tour&&(await tours.getStops(tour.id))[0];
      if(!tour||!first)throw new Error('That tour is no longer available.');
      return {destinationId:first.destination_id,savedHouseId:first.source_id,tourId:tour.id,stopId:first.id};
    }
    throw new Error('That report target is not valid.');
  }
  async function prepareInteraction(i){
    await guilds.ensureSettings(i.guildId);
    await globalMods.ensureUser(i.user.id);
    if(!guilds.isHousingChannelAllowed(i)&&!guilds.canBypassHousingChannel(i)){
      const settings=guilds.getSettings(i.guildId);
      await i.reply({content:`AddressBook interactions can only be used in <#${settings.bot_channel_id}>.`,flags:MessageFlags.Ephemeral});
      return false;
    }
    return true;
  }
  const visibleTours=i=>tours.list({creatorId:i.user.id,guildId:i.guildId});
  const personalRow=r=>({...r,scope:'personal',display_name:r.nickname||r.house_name,description:r.notes});
  const guildRow=r=>({...r,scope:'server'});
  const withCount=async r=>({...r,comment_count:await comments.count(r.scope,r.id)});
  const withHouseCardContext=async(i,r)=>{ await myAddressBook.recordView(i.user.id,r.id); return {...await withCount(r),associated_tours:await tours.visibleForHouse(r.id,{creatorId:i.user.id,guildId:i.guildId})}; };
  const dashboard=async i=>myAddressBookPayload({...await myAddressBook.summary(i.user.id,i.guildId),continueItems:await myAddressBook.continueItems(i.user.id,i.guildId)});
  const onboardingNames=i=>({globalName:i.user.globalName||i.user.username,displayName:i.member?.displayName});

  function pickerLabel(kind,r){
    if(kind==='tour-add-house')return `${text(r.nickname)||text(r.house_name)||'Unknown House'} — @${String(r.eso_owner||'').replace(/^@/,'')}`;
    if(kind.startsWith('tour'))return kind.includes('stop')?`${r.position}. ${destinationLabel(r)}`:`${r.name} (${r.scope==='global'?'Global Tour':r.scope==='server'?'Server Tour':'Private Tour'})`; 
    if(kind==='house-form')return `${r.name} (#${r.house_id})`;
    if(kind==='pending')return `${destinationLabel(r)} — @${r.eso_owner}`;
    if(kind==='advanced-owner')return `@${String(r.eso_owner||'').replace(/^@/,'')}`;
    if(kind==='advanced-name'){
      const official=text(r.house_name||r.display_name)||'Unknown House';
      const nickname=text(r.nickname);
      const name=nickname&&nickname.toLowerCase()!==official.toLowerCase()?`${nickname} (${official})`:official;
      const owner=r.eso_owner?`@${String(r.eso_owner).replace(/^@/,'')}`:'Non-Player Home';
      return `${name} — ${owner}`;
    }
    if(kind==='visit')return `${destinationLabel(r)}`;
    return `${destinationLabel(r)}${r.eso_owner?` — @${String(r.eso_owner).replace(/^@/,'')}`:''}`;
  }
  function pickerDescription(kind,r){
    if(kind.startsWith('tour-stop'))return [r.house_name,r.zone].filter(Boolean).join(' • ');
    if(kind==='tour-add-house')return [r.house_name,r.zone,r.source==='personal'?'Private':r.source==='global'?'Global':'Server'].filter(Boolean).join(' • ');
    if(kind.startsWith('tour'))return r.description||undefined;
    if(kind==='house-form')return [r.zone,r.house_type,r.classification].filter(Boolean).join(' • ');
    if(kind==='advanced-owner')return 'ESO owner';
    if(kind==='advanced-name'){
      const source=r.scope==='personal'?'Private Directory':r.scope==='server'?'Server Directory':r.scope==='global'?'Global Directory':'Non-Player Home';
      return [source,r.zone].filter(Boolean).join(' • ');
    }
    if(kind==='visit')return [r.house_name,r.zone,r.scope==='server'?'Server':r.scope==='personal'?'Private':r.scope==='global'?'Global':'Non Player'].filter(Boolean).join(' • ');
    return [r.house_name,r.zone].filter(Boolean).join(' • ');
  }
  function createPicker(i,{kind,rows,title='Choose an option',description='Select the item you want to use.',extra={},backId='hu:home',multiple=false}){
    const id=token(); states.set(id,{userId:i.user.id,kind,rows,extra,backId,page:0,multiple,created:Date.now()}); return renderPicker(id);
  }
  const navigableHousePicker=s=>s.kind==='visit';
  function navigationFromBackId(backId){
    const m=/^hu:results:back:([^:]+):(\d+)$/.exec(String(backId||''));
    if(!m)return null;
    const stateId=m[1],index=Number(m[2]),s=states.get(stateId);
    if(!s||!Number.isInteger(index))return null;
    return {stateId,index,total:s.rows.length};
  }
  function searchContextFromBackId(backId){
    const navigation=navigationFromBackId(backId);
    if(!navigation)return null;
    const state=states.get(navigation.stateId);
    if(!state||!navigableHousePicker(state))return null;
    return {...navigation,state};
  }
  function stateRowMatches(ctx,row,scope,id){ return !!row&&Number(row.id)===Number(id)&&row.scope===scope; }
  function refreshSearchStateRow(backId,row){
    const ctx=searchContextFromBackId(backId);
    if(!ctx)return null;
    const current=ctx.state.rows[ctx.index];
    if(stateRowMatches(ctx,current,row.scope,row.id))ctx.state.rows[ctx.index]=row;
    return ctx;
  }
  function removeFromSearchState(backId,scope,id){
    const ctx=searchContextFromBackId(backId);
    if(!ctx)return null;
    ctx.state.rows=ctx.state.rows.filter(r=>!stateRowMatches(ctx,r,scope,id));
    const index=Math.max(0,Math.min(ctx.index,ctx.state.rows.length-1));
    ctx.state.page=Math.floor(index/PAGE);
    return {...ctx,index,total:ctx.state.rows.length};
  }
  async function housePickerDetail(i,stateId,index,showDetails=false){
    const s=states.get(stateId);
    if(!s||s.userId!==i.user.id||!navigableHousePicker(s))return i.reply({content:'That house list expired. Run the browse or search again.',flags:MessageFlags.Ephemeral});
    const safeIndex=Math.max(0,Math.min(Number(index)||0,s.rows.length-1)),raw=s.rows[safeIndex];
    if(!raw)return i.reply({content:'That house is no longer available in this list.',flags:MessageFlags.Ephemeral});
    const navigation={stateId,index:safeIndex,total:s.rows.length},backId=`hu:results:back:${stateId}:${safeIndex}`;
    s.page=Math.floor(safeIndex/PAGE);
    if(s.kind==='visit'){
      if(raw.scope==='official')return i.update(officialHousePayload(await houses.get(raw.house_id),backId,showDetails,navigation));
      return i.update(destinationMenuPayload(await withHouseCardContext(i,raw),{canEdit:canEditSaved(i,raw),backId,showDetails,navigation}));
    }
    if(s.kind==='bookmark'){ const r=personalRow(raw); return i.update(destinationMenuPayload(await withHouseCardContext(i,r),{canEdit:true,backId,showDetails,navigation})); }
    const r=guildRow(raw); return i.update(destinationMenuPayload(await withHouseCardContext(i,r),{canEdit:canManageReg(i,r),backId,showDetails,navigation}));
  }
  function renderPicker(id){
    const s=states.get(id); if(!s)return homePayload();
    const pages=Math.max(1,Math.ceil(s.rows.length/PAGE)); s.page=Math.max(0,Math.min(s.page,pages-1));
    const start=s.page*PAGE,slice=s.rows.slice(start,start+PAGE);
    const options=slice.map((r,n)=>({label:pickerLabel(s.kind,r),description:pickerDescription(s.kind,r),value:String(start+n)}));
    const savedCount=s.kind==='visit'?s.rows.filter(r=>r.scope==='personal'||r.scope==='server'||r.scope==='global').length:0;
    const searchActions=s.kind==='visit'&&s.extra.advancedToken?[
      {customId:`hu:advanced:filters:${s.extra.advancedToken}`,label:'Filters',style:'primary',emoji:'🔍'},
      {customId:`hu:advanced:clear:${s.extra.advancedToken}`,label:'Clear Filters',style:'secondary'}
    ]:[];
    const tourActions=savedCount?[{customId:`hu:results:create:${id}`,label:'Create New Tour From Results',style:'success',emoji:'🗺️'},{customId:`hu:results:add:${id}`,label:'Add Results to Existing Tour',style:'primary',emoji:'➕'}]:[];
    const actions=[...searchActions,...tourActions];
    const pageText=`Showing ${start+1}-${start+slice.length} of ${s.rows.length}${pages>1?` • Page ${s.page+1} of ${pages}`:''}.`;
    const description=s.extra.description?`${s.extra.description}\n\n${pageText}`:pageText;
    return pickerPayload({title:s.extra.title||'Choose an option',description,customId:`hu:picker:${id}`,options,page:s.page,pages,backId:s.backId,multiple:s.multiple,actions,paginationArrows:s.kind==='visit'});
  }
  function modalResponse(i,payload){ if(typeof i.isFromMessage==='function'&&i.isFromMessage())return i.update(payload); return i.reply({...payload,flags:MessageFlags.Ephemeral}); }
  function respond(i,payload,mode='update'){ if(mode==='reply')return i.reply({...payload,flags:MessageFlags.Ephemeral}); if(mode==='modal')return modalResponse(i,payload); return i.update(payload); }
  async function resolveComments(i,scope,id,limit=25){
    return Promise.all((await comments.list(scope,id,limit)).map(async c=>{ let name='Unknown user'; try{const m=await i.guild?.members.fetch(c.discord_user_id); if(m)name=m.displayName;}catch{try{const u=await i.client.users.fetch(c.discord_user_id);name=u.globalName||u.username;}catch{}} return {...c,author_name:name}; }));
  }
  async function getSaved(scope,id,i){ if(scope==='personal'){const r=await bookmarks.get(id,i.user.id);return r?personalRow(r):null;} const r=await saved.get(id); if(!r||r.status!=='active')return null; if(scope==='global'||r.scope==='global')return r.scope==='global'?{...r,scope:'global'}:null; return r.scope==='public'&&r.guild_id===i.guildId?{...r,scope:'server'}:null; }
  async function commentsScreen(i,scope,id,mode='update',backId='hu:find'){
    const r=await getSaved(scope,id,i); if(!r)return respond(i,{content:'That saved house is no longer available.',embeds:[],components:[]},mode);
    const rows=await resolveComments(i,scope,id,25);
    return respond(i,commentsPayload({label:destinationLabel(r),owner:r.eso_owner,rows,scope,id,backId:backId||'hu:find'}),mode);
  }
  async function tourAddHousePayload(i,t){
    const rows=await tours.houseCandidates({creatorId:t.creator_id,sourceGuildId:t.source_guild_id||t.guild_id||i.guildId,visibility:t.visibility});
    if(!rows.length){
      const sourceLabel=t.visibility==='global'?'Global Houses':t.visibility==='public'?'Global or Server Houses':'Global, Server, or your Private Houses';
      return {content:`There are no ${sourceLabel.toLowerCase()} available to add yet.`,embeds:[],components:tourManagePayload(t,await tours.getStops(t.id)).components};
    }
    return createPicker(i,{kind:'tour-add-house',rows,extra:{title:`Add House — ${t.name}`,description:`Choose from ${rows.length} eligible house${rows.length===1?'':'s'}.`,tourId:t.id},backId:`hu:tour:manage:${t.id}`});
  }
  async function tourById(i,id){ const t=await tours.get(id); if(!t)return null; if(t.scope==='personal'&&t.creator_id!==i.user.id)return null; if(t.scope==='server'&&t.guild_id!==i.guildId)return null; return t; }
  async function tourDetail(i,id,mode='update'){
    const t=await tourById(i,id); if(!t)return respond(i,{content:'Tour not found.',embeds:[],components:[]},mode);
    return respond(i,tourDetailPayload(t,await tours.getStops(t.id),canManageTour(i,t)),mode);
  }
  async function tourManage(i,id,mode='update'){
    const t=await tourById(i,id); if(!t)return respond(i,{content:'Tour not found.',embeds:[],components:[]},mode);
    if(!canManageTour(i,t))return respond(i,{content:'Only the tour creator or housing moderator can manage this tour.',embeds:[],components:[]},mode);
    return respond(i,tourManagePayload(t,await tours.getStops(t.id)),mode);
  }
  async function tourStopCommentCount(stop,userId){
    if(stop?.personal_bookmark_id){ const b=await bookmarks.get(stop.personal_bookmark_id,userId); return b?await comments.count('personal',stop.personal_bookmark_id):0; }
    return stop?.registered_house_id?await comments.count('server',stop.registered_house_id):stop?.global_house_id?await comments.count('global',stop.global_house_id):0;
  }
  async function startTourSession(i,t,visibility){
    const stops=await tours.getStops(t.id); if(!stops.length)return i.update({content:'This tour has no stops yet.',embeds:[],components:[]});
    if(visibility==='public'&&!canRunSharedTour(i,t))return i.update({content:'You do not have permission to start this tour in Shared mode. Choose Self Paced instead.',embeds:[],components:[]});
    if(visibility==='public'&&t.source_guild_id&&t.source_guild_id!==i.guildId)return i.update({content:'This tour uses Server Houses from a different Discord server and cannot be shared here. Start it Self Paced or return to its source server.',embeds:[],components:[]});
    const session=visibility==='public'?await sessions.startShared({tourId:t.id,guildId:i.guildId,channelId:i.channelId,userId:i.user.id}):await sessions.startSelfPaced({tourId:t.id,guildId:i.guildId,channelId:i.channelId,userId:i.user.id});
    const count=await tourStopCommentCount(stops[0],visibility==='private'?i.user.id:null);
    const runtime={shared:session.mode==='shared',leaderId:session.started_by};
    const payload={embeds:[tourEmbed(t,stops,1,count,false,runtime)],components:tourButtons(session.id,count)};
    if(visibility==='public')return i.update({content:`Started **${t.name}** as a Shared tour.`,embeds:[],components:[]}).then(()=>i.channel.send(payload));
    return i.update(payload);
  }
  function houseFormData(i){ return {house:text(i.fields.getTextInputValue('house')),owner:text(i.fields.getTextInputValue('owner')),nickname:text(i.fields.getTextInputValue('nickname'))||null,description:text(i.fields.getTextInputValue('description'))||null,tags:text(i.fields.getTextInputValue('tags'))}; }
  async function finishHouseForm(i,scope,action,id,data,house,mode='reply',backId=''){
    try{
      if(scope==='personal'){
        let r;
        if(action==='add') r=await bookmarks.create({userId:i.user.id,houseId:house.house_id,esoOwner:data.owner,nickname:data.nickname,notes:data.description,tags:data.tags});
        else { const current=await bookmarks.get(id,i.user.id); if(!current)return respond(i,{content:'Private house not found.',components:[],embeds:[]},mode); r=await bookmarks.update(id,i.user.id,{houseId:house.house_id,esoOwner:data.owner,nickname:data.nickname,notes:data.description,tags:data.tags}); }
        const row=personalRow(r),returnTo=backId||'hu:find'; refreshSearchStateRow(returnTo,row);
        return respond(i,destinationMenuPayload(await withHouseCardContext(i,row),{canEdit:true,backId:returnTo,navigation:navigationFromBackId(returnTo)}),mode);
      }
      const permission=guilds.canRegister(i);
      if(action==='add'&&!permission.allowed)return respond(i,{content:'You do not have a role allowed to register Server or Global houses.',components:[],embeds:[]},mode);
      let r;
      if(action==='add'){
        if(scope==='global') r=await saved.createGlobal({originGuildId:i.guildId,houseId:house.house_id,esoOwner:data.owner,displayName:data.nickname,description:data.description,tags:data.tags,createdBy:i.user.id,status:permission.status});
        else {
          const existing=await regs.findCanonical(i.guildId,data.owner,house.house_id); if(existing)return respond(i,{content:`That owner + house is already in the Server Directory as #${existing.id}.`,components:[],embeds:[]},mode);
          r=await regs.create({guildId:i.guildId,houseId:house.house_id,esoOwner:data.owner,displayName:data.nickname,description:data.description,tags:data.tags,createdBy:i.user.id,status:permission.status});
        }
        if(r.status==='pending')return respond(i,{content:`✅ **${destinationLabel(r)}** was submitted and is awaiting Housing Moderator approval.`,embeds:[],components:buttonRows([{customId:'hu:home',label:'Back',style:'secondary',emoji:'↩️'}])},mode);
      } else {
        const current=await saved.get(id); if(!current)return respond(i,{content:'Saved house not found.',components:[],embeds:[]},mode);
        const canEdit=current.scope==='global'?(current.created_by===i.user.id||await globalMods.isGlobalModerator(i.user.id)):current.scope==='public'?canManageReg(i,{...current,scope:'server'}):current.owner_user_id===i.user.id;
        if(!canEdit)return respond(i,{content:'You do not manage that house.',components:[],embeds:[]},mode);
        r=await saved.update(id,{houseId:house.house_id,esoOwner:data.owner,displayName:data.nickname,description:data.description,tags:data.tags},i.user.id);
      }
      const row={...r,scope:r.scope==='public'?'server':r.scope==='private'?'personal':'global',nickname:r.display_name,notes:r.description},returnTo=backId||'hu:find'; refreshSearchStateRow(returnTo,row);
      const canEdit=row.scope==='global'?(row.created_by===i.user.id||await globalMods.isGlobalModerator(i.user.id)):row.scope==='personal'||canManageReg(i,row);
      return respond(i,destinationMenuPayload(await withHouseCardContext(i,row),{canEdit,backId:returnTo,navigation:navigationFromBackId(returnTo)}),mode);
    }catch(e){ return respond(i,{content:`Could not save that house: ${e.message}`,components:[],embeds:[]},mode); }
  }
  async function submitHouseForm(i,scope,action,id=null,backId=''){
    const data=houseFormData(i),resolved=await houses.resolve(data.house);
    if(resolved.exact)return await finishHouseForm(i,scope,action,id,data,resolved.exact,'modal',backId);
    if(resolved.matches.length===1)return await finishHouseForm(i,scope,action,id,data,resolved.matches[0],'modal',backId);
    if(!resolved.matches.length)return i.reply({content:'I could not find that official ESO house. Try all or part of its official name, or its numeric House ID.',flags:MessageFlags.Ephemeral});
    return modalResponse(i,createPicker(i,{kind:'house-form',rows:resolved.matches,extra:{title:'Which ESO house did you mean?',description:'Several official houses matched your entry.',scope,action,id,data,backId},backId:backId||'hu:find'}));
  }
  async function registrationExistingEntries(i,house,esoOwner){
    return db.query(`SELECT id,scope,display_name,status FROM saved_houses
      WHERE normalized_owner=? AND house_id=? AND status<>'archived'
      AND (scope='global' OR (scope='public' AND guild_id=?) OR (scope='private' AND owner_user_id=?))
      ORDER BY CASE scope WHEN 'global' THEN 1 WHEN 'public' THEN 2 ELSE 3 END,id`,[normalizeAccount(esoOwner),Number(house.house_id),i.guildId,i.user.id]);
  }
  function registrationExpectedStatus(i,visibility){
    if(visibility==='private')return 'active';
    const permission=guilds.canRegister(i);
    if(!permission.allowed)throw new Error('You do not have a role allowed to register Server or Global houses.');
    return permission.status;
  }
  async function reviewRegistrationDraft(i,draft,mode='modal'){
    if(!draft.house)return respond(i,{content:'Choose an official ESO house before continuing.',embeds:[],components:[]},mode);
    const owner=draft.esoOwner||draft.ownerConflict?.parsed||draft.ownerConflict?.entered;
    draft.existingEntries=owner?await registrationExistingEntries(i,draft.house,owner):[];
    return respond(i,registrationDestinationReviewPayload(draft),mode);
  }
  function savedRowsFromSearchState(s){ return (s?.rows||[]).filter(r=>r.scope==='personal'||r.scope==='server'||r.scope==='global'); }
  function bulkState(i,id){ const b=bulkTourStates.get(id); return b&&b.userId===i.user.id?b:null; }
  function beginBulkTour(i,searchStateId,action){
    const searchState=states.get(searchStateId);
    if(!searchState||searchState.userId!==i.user.id||searchState.kind!=='visit')return i.reply({content:'That house list expired. Run the browse or search again.',flags:MessageFlags.Ephemeral});
    const rows=savedRowsFromSearchState(searchState);
    if(!rows.length)return i.reply({content:'Those results contain no saved Global, Server, or Private houses that can become tour stops.',flags:MessageFlags.Ephemeral});
    const id=token(); bulkTourStates.set(id,{userId:i.user.id,action,rows,searchStateId,selected:new Set(),page:0,mode:'choice',created:Date.now()});
    return i.update(bulkTourChoicePayload({token:id,action,count:rows.length,backId:`hu:results:back:${searchStateId}`}));
  }
  function bulkSelectedRows(b){ return b.mode==='all'?b.rows:b.rows.filter((_,index)=>b.selected.has(index)); }
  function renderBulkSelection(i,id){
    const b=bulkState(i,id); if(!b)return homePayload({isAdmin:isAdmin(i)});
    const pageSize=25,pages=Math.max(1,Math.ceil(b.rows.length/pageSize)); b.page=Math.max(0,Math.min(b.page,pages-1));
    const start=b.page*pageSize,slice=b.rows.slice(start,start+pageSize);
    const options=slice.map((r,n)=>({label:pickerLabel('visit',r),description:pickerDescription('visit',r),value:String(start+n),default:b.selected.has(start+n)}));
    return bulkTourSelectionPayload({token:id,action:b.action,options,page:b.page,pages,selectedCount:b.selected.size,backId:`hu:bulk:return:${id}`});
  }
  function houseSourceAllows(source,scope){
    if(scope==='personal'||scope==='private')return ['private','both','private_public','private_global','all'].includes(source);
    if(scope==='server'||scope==='public')return ['public','both','private_public','public_global','all'].includes(source);
    if(scope==='global')return ['global','private_global','public_global','all'].includes(source);
    return false;
  }
  function bulkCompatibleTour(i,t,rows){
    if(!canManageTour(i,t))return false;
    if(t.scope==='global'&&rows.some(r=>r.scope!=='global'))return false;
    return rows.every(r=>houseSourceAllows(t.house_source,r.scope));
  }
  async function openBulkExistingTourPicker(i,id){
    const b=bulkState(i,id); if(!b)return i.reply({content:'That bulk-tour selection expired.',flags:MessageFlags.Ephemeral});
    const rows=bulkSelectedRows(b); if(!rows.length)return i.update({...renderBulkSelection(i,id),content:'Select at least one house first.'});
    const eligible=(await visibleTours(i)).filter(t=>bulkCompatibleTour(i,t,rows));
    if(!eligible.length)return i.update({content:'No editable tours can accept this result set. Create a new tour instead, or choose results compatible with an existing tour’s visibility.',embeds:[],components:buttonRows([{customId:`hu:bulk:return:${id}`,label:'Back',style:'secondary',emoji:'↩️'}])});
    return i.update(createPicker(i,{kind:'tour-bulk-add',rows:eligible,extra:{title:'Add Results to Existing Tour',description:`Choose a tour for ${rows.length} selected house${rows.length===1?'':'s'}.`,bulkToken:id},backId:`hu:bulk:return:${id}`}));
  }
  async function createBulkTour(i,id,scope){
    const b=bulkState(i,id); if(!b)return i.reply({content:'That bulk-tour selection expired.',flags:MessageFlags.Ephemeral});
    const rows=bulkSelectedRows(b),houseSource=tourSourceForRows(rows); if(!houseSource)return i.update({content:'No saved houses were selected.',embeds:[],components:[]});
    if(scope==='server'&&!i.guildId)return i.update({content:'Server Tours require a Discord server.',embeds:[],components:[]});
    if(scope==='global'&&houseSource!=='global')return i.update({content:'Global Tours can contain Global houses only. Select only Global houses or choose Server/Private visibility.',embeds:[],components:[]});
    const sourceGuildId=['public','both','private_public','public_global','all'].includes(houseSource)?i.guildId:null;
    const t=await tours.create({creatorId:i.user.id,guildId:i.guildId,scope,houseSource,sourceGuildId,name:b.name,description:b.description});
    const result=await tours.addStops(t.id,rows); bulkTourStates.delete(id);
    const summary=`Created **${t.name}** from **${result.added}** search result${result.added===1?'':'s'}.${result.skipped?` **${result.skipped}** duplicate destination${result.skipped===1?' was':'s were'} already in the result set and skipped.`:''}`;
    return i.update({...tourManagePayload(t,await tours.getStops(t.id)),content:summary});
  }

  function advancedState(i,tokenId){
    const s=advancedStates.get(tokenId);
    if(!s||s.userId!==i.user.id)return null;
    return s;
  }
  async function advancedSourceRows(i,scope='all',includeNonPlayerHomes=includeNonPlayer(i)){
    return visits.search({userId:i.user.id,guildId:i.guildId,scope,includeNonPlayer:includeNonPlayerHomes,limit:5000});
  }
  async function advancedValues(i,s,field){
    const rows=await advancedSourceRows(i,s.scope,s.includeNonPlayer);
    if(field==='tags')return [...new Set(rows.flatMap(r=>parseTags(r.tags)).map(text).filter(Boolean))].sort((a,b)=>a.localeCompare(b));
    const key={zone:'zone',style:'style',classification:'classification',houseType:'house_type'}[field];
    return [...new Set(rows.map(r=>text(r[key])).filter(Boolean))].sort((a,b)=>a.localeCompare(b));
  }
  function renderAdvanced(i,tokenId){
    const s=advancedState(i,tokenId); if(!s)return null;
    const scope=s.scope||'all';
    const title=scope==='personal'?'Search Private Houses':scope==='server'?'Search Server Houses':'Search Houses';
    const backId='hu:home';
    return advancedSearchPayload({token:tokenId,filters:s.filters,title,backId,includeNonPlayer:s.includeNonPlayer});
  }
  async function renderAdvancedAttribute(i,tokenId,field){
    const s=advancedState(i,tokenId); if(!s)return null;
    const key={tags:'tags',zone:'zones',style:'styles',classification:'classifications',houseType:'houseTypes'}[field];
    const pageKey={tags:'tag',zone:'zone',style:'style',classification:'classification',houseType:'houseType'}[field];
    return advancedAttributePayload({token:tokenId,field,values:await advancedValues(i,s,field),selected:s.filters[key]||[],page:s.pages[pageKey]||0});
  }
  function emptyAdvancedFilters(){ return {name:'',owner:'',visibilities:['global','public','private'],tags:[],zones:[],styles:[],classifications:[],houseTypes:[],notOnPublicTours:false}; }
  async function startAdvanced(i,scope='all'){
    const aid=token(); advancedStates.set(aid,{userId:i.user.id,scope,includeNonPlayer:false,filters:emptyAdvancedFilters(),pages:{tag:0,zone:0,style:0,classification:0,houseType:0},created:Date.now()});
    return searchResults(i,advancedStates.get(aid).filters,{searchType:'Search Houses',mode:'update',scope,includeNonPlayerHomes:false,backId:'hu:home',alwaysPicker:true,advancedToken:aid});
  }
  function noSearchResults(i,searchType,filters,message='No matching houses were found. Try a broader search.'){
    return i.reply({content:`${message}\n\n${searchCriteria(searchType,filters)}`,flags:MessageFlags.Ephemeral});
  }
  function successfulSearchResponse(i,payload){
    if(typeof i.isFromMessage==='function'&&i.isFromMessage())return i.update(payload);
    return i.reply({...payload,flags:MessageFlags.Ephemeral});
  }
  async function searchResults(i,filters,{searchType='House Search',mode='update',scope='all',includeNonPlayerHomes=false,backId=null,alwaysPicker=false,advancedToken=null}={}){
    const useNonPlayer=scope==='all'?includeNonPlayerHomes:false;
    const rows=await visits.search({userId:i.user.id,guildId:i.guildId,scope,includeNonPlayer:useNonPlayer,...filters,limit:null});
    if(!rows.length)return noSearchResults(i,searchType,filters);
    let payload;
    const returnId=backId||'hu:find';
    const resultTitle=scope==='personal'?'Private House Search Results':scope==='server'?'Server House Search Results':'House Search Results';
    const resultDescription=scope==='personal'?`Found ${rows.length} matches in your Private Directory.`:scope==='server'?`Found ${rows.length} matches in the Server Directory.`:`Found ${rows.length} matching home${rows.length===1?'':'s'}. Bot-wide Global entries appear first, then this server’s Server entries, then your Private entries, followed by Non-Player Homes when included.\n\n${searchCriteria(searchType,filters)}`;
    if(rows.length===1&&!alwaysPicker){ const r=rows[0]; payload=r.scope==='official'?officialHousePayload(await houses.get(r.house_id),returnId):destinationMenuPayload(await withHouseCardContext(i,r),{canEdit:canEditSaved(i,r),backId:returnId}); }
    else payload=createPicker(i,{kind:'visit',rows,extra:{title:resultTitle,description:resultDescription,advancedToken},backId:returnId});
    return mode==='modal'?successfulSearchResponse(i,payload):respond(i,payload,mode);
  }

  async function chat(i){
    if(!await prepareInteraction(i))return;
    const seen=await onboarding.get(i.user.id);
    return i.reply({...seen?homePayload({isAdmin:isAdmin(i)}):onboardingPayload({page:0}),flags:MessageFlags.Ephemeral});
  }

  async function globalModeratorScreen(i,mode='update'){
    const isApprover=globalMods.isApprover(i.user.id),isGlobal=globalMods.isGlobalModeratorCached(i.user.id);
    const pending=isApprover?await globalMods.listPending():[];
    return respond(i,globalModeratorPayload({isApprover,isModerator:isGlobal,pendingCount:pending.length}),mode);
  }
  function legacySavedRow(r){ return {...r,scope:r.scope==='private'?'personal':r.scope==='public'?'server':'global',nickname:r.display_name,notes:r.description}; }
  async function scopeChangeContext(i,id,targetScope){
    const current=await saved.get(id); if(!current||current.status==='archived')throw new Error('Saved house not found.');
    const currentLegacy=legacySavedRow(current); if(!canEditSaved(i,currentLegacy))throw new Error('You do not have edit access to that house.');
    let status='active';
    if(targetScope==='public'||targetScope==='global'){
      const permission=guilds.canRegister(i); if(!permission.allowed)throw new Error('You do not have permission to register a Server or Global house in this server.'); status=permission.status;
    }
    const targetOwnerUserId=targetScope==='private'?(current.owner_user_id||current.created_by||i.user.id):null;
    const targetGuildId=(targetScope==='public'||targetScope==='global')?i.guildId:null;
    const preview=await saved.previewScopeChange(id,targetScope,{targetStatus:status});
    return {current,currentLegacy,status,targetOwnerUserId,targetGuildId,preview};
  }
  async function applyScopeChange(i,id,targetScope,backId){
    const ctx=await scopeChangeContext(i,id,targetScope);
    const result=await saved.changeScope(id,targetScope,{actorId:i.user.id,targetGuildId:ctx.targetGuildId,targetOwnerUserId:ctx.targetOwnerUserId,status:ctx.status});
    const row=legacySavedRow(result.house);
    removeFromSearchState(backId,ctx.currentLegacy.scope,id);
    const note=result.removedStops?` Visibility changed and ${result.removedStops} incompatible tour stop${result.removedStops===1?' was':'s were'} removed.`:'';
    const pending=result.house.status==='pending'?' This house is now pending approval and will not appear in normal searches until approved.':'';
    return i.update({...destinationMenuPayload(await withHouseCardContext(i,row),{canEdit:canEditSaved(i,row),backId:'hu:find'}),content:`House visibility changed to **${targetScope==='private'?'Private':targetScope==='public'?'Server':'Global'}**.${note}${pending}`});
  }
  async function handleTourRuntimeButton(i,id){
    const parts=id.split(':'),action=parts[1],sessionId=Number(parts[2]);
    const session=await sessions.get(sessionId);
    if(!session||session.guild_id!==i.guildId||session.channel_id!==i.channelId)return i.reply({content:'This tour has been closed.',flags:MessageFlags.Ephemeral});
    const t=await tours.get(session.tour_id); if(!t)return i.reply({content:'This tour has been closed.',flags:MessageFlags.Ephemeral});
    const stops=await tours.getStops(t.id); if(!stops.length){await sessions.end(session.id);return i.reply({content:'This tour has been closed.',flags:MessageFlags.Ephemeral});}
    const canControl=canControlTourSession(session,i.user.id);
    if(['next','prev','end'].includes(action)&&!canControl)return i.reply({content:`Only <@${session.started_by}>, the tour leader, can control this ${session.mode==='shared'?'Shared':'Self Paced'} tour.`,flags:MessageFlags.Ephemeral});
    const currentIndex=Math.max(0,Math.min(stops.length-1,Number(session.current_position||1)-1));
    const currentStop=stops[currentIndex];
    if(action==='end'){
      await sessions.end(session.id);
      const count=await tourStopCommentCount(currentStop,session.mode==='self_paced'?i.user.id:null);
      return i.update({embeds:[tourEmbed(t,stops,currentIndex+1,count,false,{shared:session.mode==='shared',leaderId:session.started_by})],components:[]});
    }
    if(action==='list')return i.reply({embeds:[tourEmbed(t,stops)],flags:MessageFlags.Ephemeral});
    if(action==='comments'){
      const scope=currentStop.source_scope||'server',targetId=currentStop.source_id;
      if(scope==='personal'&&!await getSaved('personal',targetId,i))return i.reply({content:'Comments on a Private house tour stop are available only to that private-house owner.',flags:MessageFlags.Ephemeral});
      return commentsScreen(i,scope,targetId,'reply','hu:home');
    }
    if(action==='details'||action==='hide'){
      const count=await tourStopCommentCount(currentStop,session.mode==='self_paced'?i.user.id:null),showDetails=action==='details';
      return i.update({embeds:[tourEmbed(t,stops,currentIndex+1,count,showDetails,{shared:session.mode==='shared',leaderId:session.started_by})],components:tourButtons(session.id,count,showDetails)});
    }
    if(action==='next'||action==='prev'){
      const updated=await sessions.advance(session.id,action==='next'?1:-1,stops.length);
      if(!updated)return i.reply({content:'This tour has been closed.',flags:MessageFlags.Ephemeral});
      const stop=stops[Number(updated.current_position)-1],count=await tourStopCommentCount(stop,session.mode==='self_paced'?i.user.id:null);
      return i.update({embeds:[tourEmbed(t,stops,Number(updated.current_position),count,false,{shared:session.mode==='shared',leaderId:session.started_by})],components:tourButtons(session.id,count)});
    }
  }

  async function button(i){
    if(!await prepareInteraction(i))return;
    const id=i.customId;
    if(id.startsWith('tour:'))return handleTourRuntimeButton(i,id);
    if(id==='hu:home')return i.update(homePayload({isAdmin:isAdmin(i)}));
    if(id.startsWith('hu:onboarding:')){
      const action=id.split(':')[2];
      if(action==='skip'){await onboarding.skip(i.user.id,onboardingNames(i));return i.update(homePayload({isAdmin:isAdmin(i)}));}
      if(action==='finish'){await onboarding.complete(i.user.id,onboardingNames(i));return i.update(homePayload({isAdmin:isAdmin(i)}));}
      return i.update(onboardingPayload({page:Number(action)||1}));
    }
    if(['hu:find','hu:register','hu:tours:start'].includes(id)&&!await onboarding.get(i.user.id))await onboarding.complete(i.user.id,onboardingNames(i));
    if(id==='hu:my')return i.update(await dashboard(i));
    if(id==='hu:my:houses'){
      const rows=(await myAddressBook.houses(i.user.id)).map(legacySavedRow);
      if(!rows.length)return i.update({...await dashboard(i),content:'You have not registered or saved any houses yet.'});
      return i.update(createPicker(i,{kind:'visit',rows,extra:{title:'🏠 My Houses',description:`You have ${rows.length} saved or submitted house${rows.length===1?'':'s'}. Global houses appear first, then Server, then Private.`},backId:'hu:my'}));
    }
    if(id==='hu:my:tours'){
      const rows=await myAddressBook.tours(i.user.id);
      if(!rows.length)return i.update({...await dashboard(i),content:'You have not created any tours yet.'});
      return i.update(createPicker(i,{kind:'tour-view',rows,extra:{title:'🗺️ My Tours',description:`You have created ${rows.length} tour${rows.length===1?'':'s'}.`},backId:'hu:my'}));
    }
    if(id==='hu:my:pending')return i.update(myPendingPayload(await myAddressBook.pending(i.user.id)));
    if(id==='hu:my:recent'){
      const rows=(await myAddressBook.recent(i.user.id,i.guildId)).map(legacySavedRow);
      if(!rows.length)return i.update({...await dashboard(i),content:'Houses you open will appear here for quick access.'});
      return i.update(createPicker(i,{kind:'visit',rows,extra:{title:'🕘 Recently Viewed',description:'Your most recently opened saved houses, newest first.'},backId:'hu:my'}));
    }
    if(id.startsWith('hu:my:resume:')||id.startsWith('hu:my:restart:')||id.startsWith('hu:my:end:')){
      const parts=id.split(':'),action=parts[2],session=await sessions.get(Number(parts[3]));
      if(!session||!canControlTourSession(session,i.user.id))return i.reply({content:'This tour has been closed.',flags:MessageFlags.Ephemeral});
      if(action==='end'){await sessions.end(session.id);return i.update({...await dashboard(i),content:'Tour ended.'});}
      const tour=await tours.get(session.tour_id),stops=tour?await tours.getStops(tour.id):[];
      if(!tour||!stops.length){await sessions.end(session.id);return i.update({...await dashboard(i),content:'That tour is no longer available.'});}
      if(action==='restart'){await db.query('UPDATE tour_sessions SET current_position=1 WHERE id=?',[session.id]);session.current_position=1;}
      const position=Math.max(1,Math.min(stops.length,Number(session.current_position))),count=await tourStopCommentCount(stops[position-1],i.user.id);
      return i.update({embeds:[tourEmbed(tour,stops,position,count,false,{shared:false,leaderId:i.user.id})],components:tourButtons(session.id,count)});
    }
    if(id==='hu:globalmod')return globalModeratorScreen(i);
    if(id==='hu:globalmod:request')return i.showModal(globalModeratorRequestModal());
    if(id==='hu:globalmod:requests'){
      if(!globalMods.isApprover(i.user.id))return i.reply({content:'Only a configured Global Moderator approver can review requests.',flags:MessageFlags.Ephemeral});
      return i.update(globalModeratorRequestsPayload(await globalMods.listPending()));
    }
    if(id==='hu:globalmod:list'){
      if(!globalMods.isApprover(i.user.id))return i.reply({content:'Only a configured Global Moderator approver can manage Global Moderators.',flags:MessageFlags.Ephemeral});
      return i.update(globalModeratorListPayload(await globalMods.listModerators()));
    }
    if(id.startsWith('hu:globalmod:approve:')||id.startsWith('hu:globalmod:deny:')){
      if(!globalMods.isApprover(i.user.id))return i.reply({content:'Only a configured Global Moderator approver can review requests.',flags:MessageFlags.Ephemeral});
      const parts=id.split(':'),requestId=Number(parts[3]);
      if(parts[2]==='approve')await globalMods.approve(requestId,i.user.id); else await globalMods.deny(requestId,i.user.id);
      return i.update(globalModeratorRequestsPayload(await globalMods.listPending()));
    }
    if(id.startsWith('hu:globalmod:revoke:')){
      if(!globalMods.isApprover(i.user.id))return i.reply({content:'Only a configured Global Moderator approver can revoke access.',flags:MessageFlags.Ephemeral});
      await globalMods.revoke(id.split(':')[3],i.user.id);
      return i.update(globalModeratorListPayload(await globalMods.listModerators()));
    }
    if(id.startsWith('hu:scope:change:')){
      const p=id.split(':'),rid=Number(p[3]),backId=decodeURIComponent(p.slice(4).join(':')||'hu:find'),r=await saved.get(rid);
      if(!r||!canEditSaved(i,legacySavedRow(r)))return i.reply({content:'You do not have edit access to that house.',flags:MessageFlags.Ephemeral});
      return i.update(houseScopePayload(legacySavedRow(r),backId));
    }
    if(id.startsWith('hu:scope:set:')){
      const p=id.split(':'),targetScope=p[3],rid=Number(p[4]),backId=decodeURIComponent(p.slice(5).join(':')||'hu:find');
      try{
        const ctx=await scopeChangeContext(i,rid,targetScope);
        if(ctx.current.scope===targetScope)return i.update(destinationMenuPayload(await withHouseCardContext(i,ctx.currentLegacy),{canEdit:true,backId}));
        if(ctx.preview.affectedTours.length){
          const list=ctx.preview.affectedTours.slice(0,12).map(t=>`• ${t.name}`).join('\n');
          const more=ctx.preview.affectedTours.length>12?`\n…plus ${ctx.preview.affectedTours.length-12} more.`:'';
          return i.update(confirmPayload({title:'Change House Visibility?',description:`Changing this house to **${targetScope==='private'?'Private':targetScope==='public'?'Server':'Global'}** will remove it from **${ctx.preview.affectedTours.length} tour${ctx.preview.affectedTours.length===1?'':'s'}** where it will no longer be eligible:\n\n${list}${more}\n\nComments and the saved-house record will be retained.`,confirmId:`hu:scope:confirm:${targetScope}:${rid}:${encodeURIComponent(backId)}`,cancelId:`hu:context:view:${ctx.currentLegacy.scope}:${rid}:${encodeURIComponent(backId)}`}));
        }
        return applyScopeChange(i,rid,targetScope,backId);
      }catch(e){return i.reply({content:e.message,flags:MessageFlags.Ephemeral});}
    }
    if(id.startsWith('hu:scope:confirm:')){
      const p=id.split(':'),targetScope=p[3],rid=Number(p[4]),backId=decodeURIComponent(p.slice(5).join(':')||'hu:find');
      try{return await applyScopeChange(i,rid,targetScope,backId);}catch(e){return i.reply({content:e.message,flags:MessageFlags.Ephemeral});}
    }
    if(id==='hu:find')return startAdvanced(i,'all');
    if(id==='hu:register')return i.update(registrationTypePayload());
    if(id.startsWith('hu:pass:house:share:'))return i.update(houseShareChannelPayload(Number(id.split(':')[4])));
    if(id.startsWith('hu:pass:house:view:')){
      const passToken=id.split(':').slice(4).join(':');
      try{
        const resolved=await sharePasses.resolveHousePass(passToken,{userId:i.user.id,guildId:i.guildId});
        return i.reply({...sharedPrivateHousePayload({...resolved.house,scope:resolved.house.scope==='private'?'private':resolved.house.scope},{token:passToken,canCopy:resolved.access.canCopy}),flags:MessageFlags.Ephemeral});
      }catch(error){return i.reply({content:error.message,flags:MessageFlags.Ephemeral});}
    }
    if(id.startsWith('hu:pass:house:copyvisibility:')){
      const parts=id.split(':'),visibility=parts[4],passToken=parts.slice(5).join(':');
      try{
        const resolved=await sharePasses.resolveHousePass(passToken,{userId:i.user.id,guildId:i.guildId});
        const preview=await houseCopies(i).preview({sourceSavedHouseId:resolved.house.id,userId:i.user.id,guildId:i.guildId,passId:resolved.pass.id});
        const choice=preview.choices.find(item=>item.visibility===visibility);
        if(!choice?.enabled)throw new Error(choice?.reason||'That visibility is not available.');
        return i.showModal(houseCopyMetadataModal(preview,{token:passToken,visibility}));
      }catch(error){return i.reply({content:error.message,flags:MessageFlags.Ephemeral});}
    }
    if(id.startsWith('hu:pass:house:copy:')){
      const passToken=id.split(':').slice(4).join(':');
      try{
        const resolved=await sharePasses.resolveHousePass(passToken,{userId:i.user.id,guildId:i.guildId});
        const preview=await houseCopies(i).preview({sourceSavedHouseId:resolved.house.id,userId:i.user.id,guildId:i.guildId,passId:resolved.pass.id});
        return i.update(houseCopyVisibilityPayload(preview,{token:passToken}));
      }catch(error){return i.reply({content:error.message,flags:MessageFlags.Ephemeral});}
    }
    if(id.startsWith('hu:pass:tour:share:'))return i.update(tourShareChannelPayload(Number(id.split(':')[4])));
    if(id.startsWith('hu:pass:tour:start:')){
      const passToken=id.split(':').slice(4).join(':');
      try{
        const resolved=await sharePasses.resolveTourPass(passToken,{userId:i.user.id,guildId:i.guildId});
        const session=await sessions.startFromPass({passId:resolved.pass.id,tourId:resolved.tour.id,guildId:i.guildId,channelId:i.channelId,userId:i.user.id});
        const count=resolved.stops.length?await tourStopCommentCount(resolved.stops[0],i.user.id):0;
        return i.reply({embeds:[tourEmbed(resolved.tour,resolved.stops,1,count,false,{shared:false,leaderId:i.user.id})],components:tourButtons(session.id,count),flags:MessageFlags.Ephemeral});
      }catch(error){return i.reply({content:error.message,flags:MessageFlags.Ephemeral});}
    }
    if(id.startsWith('hu:pass:tour:copyconfirm:')){
      const passToken=id.split(':').slice(4).join(':');
      try{
        await i.deferUpdate();
        const resolved=await sharePasses.resolveTourPass(passToken,{userId:i.user.id,guildId:i.guildId});
        const copied=await tourCopies.copy({tourId:resolved.tour.id,passId:resolved.pass.id,userId:i.user.id,guildId:i.guildId});
        const stops=await tours.getStops(copied.id);
        return i.editReply({...tourDetailPayload(copied,stops,true),content:'Tour copied successfully. This Private tour is now independent of the Share Pass.'});
      }catch(error){
        const payload={content:`Nothing was copied. ${error.message}`,embeds:[],components:[]};
        return i.deferred?i.editReply(payload):i.reply({...payload,flags:MessageFlags.Ephemeral});
      }
    }
    if(id.startsWith('hu:pass:tour:copy:')){
      const passToken=id.split(':').slice(4).join(':');
      try{
        const resolved=await sharePasses.resolveTourPass(passToken,{userId:i.user.id,guildId:i.guildId});
        const preview=await tourCopies.preview({tourId:resolved.tour.id,passId:resolved.pass.id,userId:i.user.id,guildId:i.guildId});
        return i.reply({...tourCopyPreviewPayload(preview,{token:passToken}),flags:MessageFlags.Ephemeral});
      }catch(error){return i.reply({content:error.message,flags:MessageFlags.Ephemeral});}
    }
    if(id.startsWith('hu:register-cancel:')){ registrationDrafts.remove(id.split(':')[2],i.user.id); return i.update(homePayload({isAdmin:isAdmin(i)})); }
    if(id.startsWith('hu:register-owner:')){
      const p=id.split(':'),choice=p[2],draft=registrationDrafts.get(p[3],i.user.id);
      if(!draft)return i.reply({content:'That registration draft expired. Start Register New House again.',flags:MessageFlags.Ephemeral});
      const owner=choice==='parsed'?draft.ownerConflict?.parsed:draft.ownerConflict?.entered;
      registrationDrafts.update(draft.id,i.user.id,{esoOwner:owner,ownerConflict:null});
      return reviewRegistrationDraft(i,draft,'update');
    }
    if(id.startsWith('hu:register-metadata:')){
      const draft=registrationDrafts.get(id.split(':')[2],i.user.id);
      if(!draft)return i.reply({content:'That registration draft expired. Start Register New House again.',flags:MessageFlags.Ephemeral});
      return i.showModal(registrationMetadataModal(draft.id,draft));
    }
    if(id.startsWith('hu:register-privatecopy:')){
      const draft=registrationDrafts.get(id.split(':')[2],i.user.id);
      if(!draft)return i.reply({content:'That registration draft expired. Start Register New House again.',flags:MessageFlags.Ephemeral});
      registrationDrafts.update(draft.id,i.user.id,{visibility:'private',expectedStatus:'active'});
      return i.showModal(registrationMetadataModal(draft.id,draft));
    }
    if(id.startsWith('hu:register-report:')){
      const parts=id.split(':'),draft=registrationDrafts.get(parts[2],i.user.id),savedHouseId=Number(parts[3]);
      if(!draft)return i.reply({content:'That registration draft expired. Start Register New House again.',flags:MessageFlags.Ephemeral});
      return i.showModal(reportExplanationModal({kind:'houseid',token:String(savedHouseId),problemType:'misleading_information'}));
    }
    if(id.startsWith('hu:register-save:')){
      const draft=registrationDrafts.get(id.split(':')[2],i.user.id);
      if(!draft)return i.reply({content:'That registration draft expired. Start Register New House again.',flags:MessageFlags.Ephemeral});
      registrationDrafts.remove(draft.id,i.user.id);
      const scope=registrationScopeFromType(draft.visibility);
      return finishHouseForm(i,scope,'add',null,{owner:draft.esoOwner,nickname:draft.nickname||null,description:draft.description||null,tags:draft.tags||[]},draft.house,'update','hu:home');
    }
    if(id==='hu:tours'){ const rows=await visibleTours(i); return i.update(toursPayload(rows.length)); }
    if(id==='hu:help')return i.update(helpPayload());
    if(id==='hu:admin'){ if(!isAdmin(i))return i.reply({content:'You do not have access to Housing administration.',flags:MessageFlags.Ephemeral}); return i.update(adminPayload(guilds.getSettings(i.guildId))); }
    if(id==='hu:admin:otherroles'){ if(!isAdmin(i))return i.reply({content:'You do not have access to Housing administration.',flags:MessageFlags.Ephemeral}); return i.update(adminOtherRolesPayload(guilds.getSettings(i.guildId))); }
    if(id==='hu:guild:pending'){
      if(!guilds.canReviewPending(i))return i.reply({content:'You do not have Housing administration access to review pending houses.',flags:MessageFlags.Ephemeral});
      const rows=await regs.searchPending(i.guildId);
      if(!rows.length)return i.update({...adminPayload(guilds.getSettings(i.guildId)),content:'There are no pending Server or Global house submissions from this server.'});
      return i.update(createPicker(i,{kind:'pending',rows,extra:{title:'📝 Pending House Review',description:'Choose a pending Server or Global house submission to review.'},backId:'hu:admin'}));
    }
    if(id==='hu:admin:health'){
      if(!isAdmin(i))return i.reply({content:'You do not have access to Housing administration.',flags:MessageFlags.Ephemeral});
      const channels=i.guild?.channels?.cache?[...i.guild.channels.cache.keys()]:[];
      return i.update(adminHealthPayload(await adminHealth.snapshot({guildId:i.guildId,availableChannelIds:channels})));
    }
    if(id==='hu:admin:passes'){
      if(!isAdmin(i))return i.reply({content:'You do not have access to Housing administration.',flags:MessageFlags.Ephemeral});
      return i.update(adminSharePassesPayload((await adminHealth.snapshot({guildId:i.guildId})).passes));
    }
    if(id==='hu:admin:reports'){
      if(!isAdmin(i)&&!globalMods.isGlobalModeratorCached(i.user.id))return i.reply({content:'You do not have access to housing problem reports.',flags:MessageFlags.Ephemeral});
      return i.update(reportQueuePayload(await reports.listForModerator(reportContext(i))));
    }
    if(id.startsWith('hu:report:review:')){
      try{return i.update(reportReviewPayload(await reports.getForModerator(Number(id.split(':')[3]),reportContext(i))));}
      catch(error){return i.reply({content:error.message,flags:MessageFlags.Ephemeral});}
    }
    if(id.startsWith('hu:report:markreviewing:')||id.startsWith('hu:report:resolve:')||id.startsWith('hu:report:dismiss:')){
      const parts=id.split(':'),action=parts[2],reportId=Number(parts[3]),context=reportContext(i),names={reviewerGlobalName:i.user.globalName||i.user.username,reviewerDisplayName:i.member?.displayName};
      try{
        if(action==='markreviewing')await reports.review(reportId,{reviewerId:i.user.id,guildId:i.guildId,isServerModerator:context.isServerModerator,isGlobalModerator:context.isGlobalModerator,names});
        else await reports.resolve(reportId,{reviewerId:i.user.id,guildId:i.guildId,isServerModerator:context.isServerModerator,isGlobalModerator:context.isGlobalModerator,resolution:action==='dismiss'?'dismissed':'resolved',names});
        return i.update(reportQueuePayload(await reports.listForModerator(context)));
      }catch(error){return i.reply({content:error.message,flags:MessageFlags.Ephemeral});}
    }
    if(id.startsWith('hu:pass:house:report:'))return i.reply({...reportProblemTypePayload({kind:'housepass',token:id.split(':').slice(4).join(':')}),flags:MessageFlags.Ephemeral});
    if(id.startsWith('hu:pass:tour:report:'))return i.reply({...reportProblemTypePayload({kind:'tourpass',token:id.split(':').slice(4).join(':')}),flags:MessageFlags.Ephemeral});
    if(id.startsWith('hu:report:houseid:')||id.startsWith('hu:report:tourid:')){
      const parts=id.split(':');
      return i.reply({...reportProblemTypePayload({kind:parts[2],token:parts.slice(3).join(':')}),flags:MessageFlags.Ephemeral});
    }

    if(id.startsWith('hu:advanced:x:')){
      const p=id.split(':'),aid=p[3],field=p[4],index=Number(p[5]),s=advancedState(i,aid);
      if(!s)return i.reply({content:'That Search Houses session expired. Open Search Houses again.',flags:MessageFlags.Ephemeral});
      const values=Array.isArray(s.filters[field])?s.filters[field]:null;
      if(values&&Number.isInteger(index)&&index>=0&&index<values.length)values.splice(index,1);
      return i.update(renderAdvanced(i,aid));
    }
    if(id.startsWith('hu:advanced:')){
      const p=id.split(':'),action=p[2],aid=p[3],s=advancedState(i,aid);
      if(!s)return i.reply({content:'That Search Houses session expired. Open Search Houses again.',flags:MessageFlags.Ephemeral});
      if(action==='name'||action==='owner')return i.showModal(advancedTextModal(aid,action,s.filters[action]||''));
      const openField={tagsopen:'tags',zoneopen:'zone',styleopen:'style',classificationopen:'classification',houseTypeopen:'houseType'}[action];
      if(openField)return i.update(await renderAdvancedAttribute(i,aid,openField));
      if(action==='filters')return i.showModal(searchFiltersModal(aid,s.filters,s.includeNonPlayer));
      if(action==='clear'){ s.filters=emptyAdvancedFilters(); s.includeNonPlayer=false; s.pages={tag:0,zone:0,style:0,classification:0,houseType:0}; return searchResults(i,s.filters,{searchType:'Search Houses',mode:'update',scope:s.scope||'all',includeNonPlayerHomes:false,backId:'hu:home',alwaysPicker:true,advancedToken:aid}); }
      if(action==='manage')return i.update(advancedManagePayload(aid,s.filters));
      if(action==='remove'){ const field=p[4],page=Number(p[5]||0),values=Array.isArray(s.filters[field])?s.filters[field]:[]; return i.update(advancedRemovePayload({token:aid,field,values,page})); }
      if(action==='nonplayer'){ if((s.scope||'all')==='all'&&!s.filters.notOnPublicTours)s.includeNonPlayer=!s.includeNonPlayer; return i.update(renderAdvanced(i,aid)); }
      if(action==='search'||action==='results'){ const scope=s.scope||'all',searchType=scope==='personal'?'Private House Search':scope==='server'?'Server House Search':'Search Houses'; return searchResults(i,s.filters,{searchType,mode:'update',scope,includeNonPlayerHomes:s.includeNonPlayer,backId:'hu:home',alwaysPicker:true,advancedToken:aid}); }
      if(action==='open')return i.update(renderAdvanced(i,aid));
    }

    if(id.startsWith('hu:personal:edit:')){ const p=id.split(':'),rid=Number(p[3]),backId=decodeURIComponent(p.slice(4).join(':')||''); const r=await bookmarks.get(rid,i.user.id); if(!r)return i.reply({content:'Private house not found.',flags:MessageFlags.Ephemeral}); return i.showModal(houseEditModal('personal',r,backId)); }
    if(id.startsWith('hu:personal:remove:')){ const p=id.split(':'),rid=Number(p[3]),backId=decodeURIComponent(p.slice(4).join(':')||''); const r=await bookmarks.get(rid,i.user.id); if(!r)return i.update({content:'Private house not found.',embeds:[],components:[]}); const ctx=encodeURIComponent(backId); return i.update(confirmPayload({title:'Remove Private House?',description:`Permanently delete **${destinationLabel(r)}** from your Private houses? Its comments and tour references will also be deleted.`,confirmId:`hu:personal:removeconfirm:${rid}:${ctx}`,cancelId:`hu:context:view:personal:${rid}:${ctx}`})); }
    if(id.startsWith('hu:personal:removeconfirm:')){ const p=id.split(':'),rid=Number(p[3]),backId=decodeURIComponent(p.slice(4).join(':')||''); const r=await bookmarks.get(rid,i.user.id); if(!r)return i.update({content:'Private house not found.',embeds:[],components:[]}); await bookmarks.remove(rid,i.user.id); const ctx=removeFromSearchState(backId,'personal',rid); if(ctx){ if(ctx.total>0)return housePickerDetail(i,ctx.stateId,ctx.index); const m=/^hu:advanced:open:([^:]+)$/.exec(ctx.state.backId||''); if(m&&advancedState(i,m[1]))return i.update({...renderAdvanced(i,m[1]),content:'Private house deleted. No houses remain in that result list.'}); return i.update({...homePayload({isAdmin:isAdmin(i)}),content:'Private house deleted. No houses remain in that result list.'}); } return i.update(homePayload({isAdmin:isAdmin(i)})); }

    if(id.startsWith('hu:guild:edit:')){ const p=id.split(':'),rid=Number(p[3]),backId=decodeURIComponent(p.slice(4).join(':')||''); const r=await regs.get(rid); if(!r||r.guild_id!==i.guildId||!canManageReg(i,r))return i.reply({content:'You do not manage that public house.',flags:MessageFlags.Ephemeral}); return i.showModal(houseEditModal('guild',r,backId)); }
    if(id.startsWith('hu:guild:remove:')){ const p=id.split(':'),rid=Number(p[3]),backId=decodeURIComponent(p.slice(4).join(':')||''); const r=await regs.get(rid); if(!r||r.guild_id!==i.guildId||!canManageReg(i,r))return i.update({content:'You do not manage that Server house.',embeds:[],components:[]}); const ctx=encodeURIComponent(backId); return i.update(confirmPayload({title:'Remove Server House?',description:`Permanently delete **${destinationLabel(r)}** from this server’s Server houses? Its comments and tour references will also be deleted.`,confirmId:`hu:guild:removeconfirm:${rid}:${ctx}`,cancelId:`hu:context:view:guild:${rid}:${ctx}`})); }
    if(id.startsWith('hu:global:edit:')){ const p=id.split(':'),rid=Number(p[3]),backId=decodeURIComponent(p.slice(4).join(':')||''); const r=await saved.get(rid); if(!r||r.scope!=='global'||!canEditSaved(i,{...r,scope:'global'}))return i.reply({content:'You do not manage that Global house.',flags:MessageFlags.Ephemeral}); return i.showModal(houseEditModal('global',{...r,nickname:r.display_name,notes:r.description},backId)); }
    if(id.startsWith('hu:global:remove:')){ const p=id.split(':'),rid=Number(p[3]),backId=decodeURIComponent(p.slice(4).join(':')||''); const r=await saved.get(rid); if(!r||r.scope!=='global'||!canEditSaved(i,{...r,scope:'global'}))return i.update({content:'You do not manage that Global house.',embeds:[],components:[]}); const ctx=encodeURIComponent(backId); return i.update(confirmPayload({title:'Delete Global House?',description:`Permanently delete **${destinationLabel(r)}** from the bot-wide Global directory? Its comments and tour references will also be removed.`,confirmId:`hu:global:removeconfirm:${rid}:${ctx}`,cancelId:`hu:context:view:global:${rid}:${ctx}`})); }
    if(id.startsWith('hu:global:removeconfirm:')){ const p=id.split(':'),rid=Number(p[3]),backId=decodeURIComponent(p.slice(4).join(':')||''); const r=await saved.get(rid); if(!r||r.scope!=='global'||!canEditSaved(i,{...r,scope:'global'}))return i.update({content:'You do not manage that Global house.',embeds:[],components:[]}); await saved.delete(rid,i.user.id); const ctx=removeFromSearchState(backId,'global',rid); if(ctx?.total>0)return housePickerDetail(i,ctx.stateId,ctx.index); return i.update({...homePayload({isAdmin:isAdmin(i)}),content:'Global house deleted.'}); }

    if(id.startsWith('hu:guild:removeconfirm:')){ const p=id.split(':'),rid=Number(p[3]),backId=decodeURIComponent(p.slice(4).join(':')||''); const r=await regs.get(rid); if(!r||r.guild_id!==i.guildId||!canManageReg(i,r))return i.update({content:'You do not manage that Server house.',embeds:[],components:[]}); await regs.archive(rid,i.user.id); const ctx=removeFromSearchState(backId,'server',rid); if(ctx){ if(ctx.total>0)return housePickerDetail(i,ctx.stateId,ctx.index); const m=/^hu:advanced:open:([^:]+)$/.exec(ctx.state.backId||''); if(m&&advancedState(i,m[1]))return i.update({...renderAdvanced(i,m[1]),content:'Server house deleted. No houses remain in that result list.'}); return i.update({...homePayload({isAdmin:isAdmin(i)}),content:'Server house deleted. No houses remain in that result list.'}); } return i.update(homePayload({isAdmin:isAdmin(i)})); }
    if(id.startsWith('hu:pending:approve:')||id.startsWith('hu:pending:deny:')){
      if(!guilds.canReviewPending(i))return i.reply({content:'You do not have Housing administration access to review pending houses.',flags:MessageFlags.Ephemeral});
      const parts=id.split(':'),action=parts[2],rid=Number(parts[3]),record=await regs.get(rid);
      const belongsHere=record?.status==='pending'&&((record.scope==='server'&&record.guild_id===i.guildId)||(record.scope==='global'&&record.origin_guild_id===i.guildId));
      if(!belongsHere)return i.reply({content:'That pending house does not belong to this server’s review queue.',flags:MessageFlags.Ephemeral});
      try{action==='approve'?await regs.approve(rid,i.user.id):await regs.deny(rid,i.user.id); return i.update(adminPayload(guilds.getSettings(i.guildId)));}catch(e){return i.update({content:e.message,embeds:[],components:[]});}
    }

    if(id==='hu:tours:browse'||id==='hu:tours:start'||id==='hu:tours:manage'){
      let rows=await visibleTours(i); if(id==='hu:tours:manage')rows=rows.filter(t=>canManageTour(i,t)); if(!rows.length)return i.update({content:id==='hu:tours:manage'?'There are no tours you can manage.':'No tours are available yet.',embeds:[],components:toursPayload((await visibleTours(i)).length).components});
      const kind=id==='hu:tours:start'?'tour-start':id==='hu:tours:manage'?'tour-manage':'tour-view';
      return i.update(createPicker(i,{kind,rows,extra:{title:id==='hu:tours:start'?'Start a Tour':id==='hu:tours:manage'?'Edit Tour':'Browse Tours',description:'Choose a tour.'},backId:'hu:tours'}));
    }
    if(id==='hu:tours:create')return i.showModal(tourCreateModal());
    if(id.startsWith('hu:tour:view:'))return tourDetail(i,Number(id.split(':')[3]));
    if(id.startsWith('hu:tour:start:')){ const t=await tourById(i,Number(id.split(':')[3])); if(!t)return i.update({content:'Tour not found.',embeds:[],components:[]}); return i.update(tourStartChoicePayload(t,canRunSharedTour(i,t))); }
    if(id.startsWith('hu:tour:startprivate:')||id.startsWith('hu:tour:startpublic:')){ const p=id.split(':'),t=await tourById(i,Number(p[3])); if(!t)return i.update({content:'Tour not found.',embeds:[],components:[]}); return startTourSession(i,t,p[2]==='startpublic'?'public':'private'); }
    if(id.startsWith('hu:tour:manage:'))return tourManage(i,Number(id.split(':')[3]));
    if(id.startsWith('hu:tour:add:')){ const tid=Number(id.split(':')[3]),t=await tourById(i,tid); if(!t||!canManageTour(i,t))return i.update({content:'You cannot manage that tour.',embeds:[],components:[]}); return i.update(await tourAddHousePayload(i,t)); }
    if(id.startsWith('hu:tour:editstop:')||id.startsWith('hu:tour:reorder:')||id.startsWith('hu:tour:removestop:')){
      const p=id.split(':'),action=p[2],tid=Number(p[3]),t=await tourById(i,tid); if(!t||!canManageTour(i,t))return i.update({content:'You cannot manage that tour.',embeds:[],components:[]}); const rows=await tours.getStops(tid); if(!rows.length)return i.update({content:'This tour has no stops yet.',embeds:[],components:tourManagePayload(t,rows).components}); const kind=action==='editstop'?'tour-stop-edit':action==='reorder'?'tour-stop-reorder':'tour-stop-remove'; return i.update(createPicker(i,{kind,rows,extra:{title:`${action==='editstop'?'Edit a Stop':action==='reorder'?'Reorder Stops':'Remove a Stop'} — ${t.name}`,description:'Choose a tour stop.',tourId:tid},backId:`hu:tour:manage:${tid}`}));
    }
    if(id.startsWith('hu:tour:edit:')){ const t=await tourById(i,Number(id.split(':')[3])); if(!t||!canManageTour(i,t))return i.update({content:'You cannot manage that tour.',embeds:[],components:[]}); return i.update(tourEditDetailsPayload(t)); }
    if(id.startsWith('hu:tour:edittext:')){ const t=await tourById(i,Number(id.split(':')[3])); if(!t||!canManageTour(i,t))return i.reply({content:'You cannot manage that tour.',flags:MessageFlags.Ephemeral}); return i.showModal(tourEditModal(t)); }
    if(id.startsWith('hu:tour:editvisibility:')){ const t=await tourById(i,Number(id.split(':')[3])); if(!t||!canManageTour(i,t))return i.update({content:'You cannot manage that tour.',embeds:[],components:[]}); return i.update(tourEditVisibilityPayload(t)); }
    if(id.startsWith('hu:tour:setvisibility:')){ const p=id.split(':'),scope=p[3],tid=Number(p[4]),t=await tourById(i,tid); if(!t||!canManageTour(i,t))return i.update({content:'You cannot manage that tour.',embeds:[],components:[]}); if(scope==='server'&&!i.guildId)return i.update({content:'Server Tours require a Discord server.',embeds:[],components:[]}); if(scope==='global'&&t.creator_id!==i.user.id&&!globalMods.isGlobalModeratorCached(i.user.id))return i.update({content:'Only the tour creator or a Global Housing Moderator can make a tour Global.',embeds:[],components:[]}); const visibility=scope==='server'?'public':scope==='personal'?'private':'global',impact=await tours.visibilityChangeImpact(tid,visibility); if(impact.total){return i.update(confirmPayload({title:'Change Tour Visibility?',description:`This visibility change will remove **${impact.total} incompatible stop${impact.total===1?'':'s'}**.`,confirmId:`hu:tour:setvisibilityconfirm:${scope}:${tid}`,cancelId:`hu:tour:edit:${tid}`}));} const updated=await tours.update(tid,{scope,guildId:i.guildId,sourceGuildId:i.guildId}); return i.update(tourEditDetailsPayload(updated)); }
    if(id.startsWith('hu:tour:setvisibilityconfirm:')){ const p=id.split(':'),scope=p[3],tid=Number(p[4]),t=await tourById(i,tid); if(!t||!canManageTour(i,t))return i.update({content:'You cannot manage that tour.',embeds:[],components:[]}); if(scope==='global'&&t.creator_id!==i.user.id&&!globalMods.isGlobalModeratorCached(i.user.id))return i.update({content:'Only the tour creator or a Global Housing Moderator can make a tour Global.',embeds:[],components:[]}); const updated=await tours.update(tid,{scope,guildId:i.guildId,sourceGuildId:i.guildId}); return i.update(tourEditDetailsPayload(updated)); }
    if(id.startsWith('hu:tour:delete:')){ const tid=Number(id.split(':')[3]),t=await tourById(i,tid); if(!t||!canManageTour(i,t))return i.update({content:'You cannot manage that tour.',embeds:[],components:[]}); return i.update(confirmPayload({title:'Delete Housing Tour?',description:`Permanently delete **${t.name}** and all of its tour stops? Saved/public houses are not deleted.`,confirmId:`hu:tour:deleteconfirm:${tid}`,cancelId:`hu:tour:manage:${tid}`})); }
    if(id.startsWith('hu:tour:deleteconfirm:')){ const tid=Number(id.split(':')[3]),t=await tourById(i,tid); if(!t||!canManageTour(i,t))return i.update({content:'You cannot manage that tour.',embeds:[],components:[]}); await tours.remove(tid); return i.update(toursPayload((await visibleTours(i)).length)); }
    if(id.startsWith('hu:tour:createvis:')){ const p=id.split(':'),scope=p[3],draftId=p[4],d=drafts.get(draftId); if(!d||d.userId!==i.user.id)return i.update({content:'That tour draft expired. Choose Create Tour again.',embeds:[],components:[]}); if(scope==='server'&&!i.guildId)return i.update({content:'Server Tours require a Discord server.',embeds:[],components:[]}); const t=await tours.create({creatorId:i.user.id,guildId:i.guildId,scope,sourceGuildId:i.guildId,name:d.name,description:d.description}); drafts.delete(draftId); return i.update(await tourAddHousePayload(i,t)); }
    if(id.startsWith('hu:reorder:')){ const p=id.split(':'),action=p[2],tid=Number(p[3]),stopId=Number(p[4]),t=await tourById(i,tid); if(!t||!canManageTour(i,t))return i.update({content:'You cannot manage that tour.',embeds:[],components:[]}); let rows=await tours.getStops(tid),stop=rows.find(s=>s.id===stopId); if(!stop)return i.update({content:'That stop no longer exists.',embeds:[],components:[]}); let to=stop.position; if(action==='up')to--; if(action==='down')to++; if(action==='first')to=1;if(action==='last')to=rows.length; if(to!==stop.position)await tours.moveStop(tid,stop.position,to); rows=await tours.getStops(tid); stop=rows.find(s=>s.id===stopId); return i.update(reorderPayload(t,stop,rows.length)); }
    if(id.startsWith('hu:stop:removeconfirm:')){ const p=id.split(':'),tid=Number(p[3]),stopId=Number(p[4]),t=await tourById(i,tid); if(!t||!canManageTour(i,t))return i.update({content:'You cannot manage that tour.',embeds:[],components:[]}); const stop=(await tours.getStops(tid)).find(s=>s.id===stopId); if(stop)await tours.removeStop(tid,stop.position); return i.update(tourManagePayload(t,await tours.getStops(tid))); }

    if(id.startsWith('hu:context:view:')){ const p=id.split(':'),scope=p[3],rid=Number(p[4]),backId=decodeURIComponent(p.slice(5).join(':')||''); const savedScope=scope==='personal'?'personal':scope==='global'?'global':'server',r=await getSaved(savedScope,rid,i); if(!r)return i.update({content:'That saved house is no longer available.',embeds:[],components:[]}); return i.update(destinationMenuPayload(await withHouseCardContext(i,r),{canEdit:canEditSaved(i,r),backId:backId||'hu:find',navigation:navigationFromBackId(backId)})); }

    if(id.startsWith('hu:details:')){
      const p=id.split(':'),scope=p[2],rid=Number(p[3]),showDetails=p[4]==='show',backId=decodeURIComponent(p.slice(5).join(':')||'hu:home'),navigation=navigationFromBackId(backId);
      if(scope==='official'){
        const house=await houses.get(rid); if(!house)return i.update({content:'That Non-Player Home is no longer available.',embeds:[],components:[]});
        return i.update(officialHousePayload(house,backId,showDetails,navigation));
      }
      const savedScope=scope==='personal'?'personal':scope==='global'?'global':'server',r=await getSaved(savedScope,rid,i); if(!r)return i.update({content:'That saved house is no longer available.',embeds:[],components:[]});
      return i.update(destinationMenuPayload(await withHouseCardContext(i,r),{canEdit:canEditSaved(i,r),backId,showDetails,navigation}));
    }
    if(id.startsWith('hu:comments:')){ const p=id.split(':'),scope=p[2],rid=Number(p[3]),backId=decodeURIComponent(p.slice(4).join(':')||'hu:find'); return commentsScreen(i,scope,rid,'update',backId); }
    if(id.startsWith('hu:comment:add:')){ const p=id.split(':'),scope=p[3],rid=Number(p[4]),backId=decodeURIComponent(p.slice(5).join(':')); const r=await getSaved(scope,rid,i); if(!r)return i.reply({content:'That saved house is no longer available.',flags:MessageFlags.Ephemeral}); return i.showModal(commentModal(scope,rid,backId,destinationLabel(r))); }

    if(id.startsWith('hu:house-nav:')){ const p=id.split(':'),sid=p[2],index=Number(p[3]); return housePickerDetail(i,sid,index); }
    if(id.startsWith('hu:results:create:'))return beginBulkTour(i,id.split(':')[3],'create');
    if(id.startsWith('hu:results:add:'))return beginBulkTour(i,id.split(':')[3],'add');
    if(id.startsWith('hu:results:back:')){ const sid=id.split(':')[3],s=states.get(sid); if(!s||s.userId!==i.user.id)return i.reply({content:'That house list expired. Run the browse or search again.',flags:MessageFlags.Ephemeral}); return i.update(renderPicker(sid)); }
    if(id.startsWith('hu:bulk:cancel:')){ const bid=id.split(':')[3],b=bulkState(i,bid); if(!b)return i.reply({content:'That bulk-tour selection expired.',flags:MessageFlags.Ephemeral}); bulkTourStates.delete(bid); const s=states.get(b.searchStateId); return s?i.update(renderPicker(b.searchStateId)):i.update(homePayload({isAdmin:isAdmin(i)})); }
    if(id.startsWith('hu:bulk:return:')){ const bid=id.split(':')[3],b=bulkState(i,bid); if(!b)return i.reply({content:'That bulk-tour selection expired.',flags:MessageFlags.Ephemeral}); if(b.mode==='select')return i.update(renderBulkSelection(i,bid)); b.mode='choice'; return i.update(bulkTourChoicePayload({token:bid,action:b.action,count:b.rows.length,backId:`hu:results:back:${b.searchStateId}`})); }
    if(id.startsWith('hu:bulk:all:')){ const bid=id.split(':')[3],b=bulkState(i,bid); if(!b)return i.reply({content:'That bulk-tour selection expired.',flags:MessageFlags.Ephemeral}); b.mode='all'; return b.action==='create'?i.showModal(bulkTourCreateModal(bid)):openBulkExistingTourPicker(i,bid); }
    if(id.startsWith('hu:bulk:select:')){ const bid=id.split(':')[3],b=bulkState(i,bid); if(!b)return i.reply({content:'That bulk-tour selection expired.',flags:MessageFlags.Ephemeral}); b.mode='select'; b.page=0; b.selected=new Set(); return i.update(renderBulkSelection(i,bid)); }
    if(id.startsWith('hu:bulkselect:prev:')||id.startsWith('hu:bulkselect:next:')){ const p=id.split(':'),dir=p[2],bid=p[3],b=bulkState(i,bid); if(!b)return i.reply({content:'That bulk-tour selection expired.',flags:MessageFlags.Ephemeral}); b.page+=dir==='next'?1:-1; return i.update(renderBulkSelection(i,bid)); }
    if(id.startsWith('hu:bulkselect:done:')){ const bid=id.split(':')[3],b=bulkState(i,bid); if(!b)return i.reply({content:'That bulk-tour selection expired.',flags:MessageFlags.Ephemeral}); if(!b.selected.size)return i.update({...renderBulkSelection(i,bid),content:'Select at least one house first.'}); return b.action==='create'?i.showModal(bulkTourCreateModal(bid)):openBulkExistingTourPicker(i,bid); }
    if(id.startsWith('hu:bulk:visibility:')){ const p=id.split(':'),scope=p[3],bid=p[4]; return createBulkTour(i,bid,scope); }

    if(id.startsWith('hu:picker:prev:')||id.startsWith('hu:picker:next:')){ const p=id.split(':'),dir=p[2],sid=p[3],s=states.get(sid); if(!s)return i.reply({content:'That menu expired. Run /housing again.',flags:MessageFlags.Ephemeral}); if(s.userId!==i.user.id)return i.reply({content:'That menu belongs to another user.',flags:MessageFlags.Ephemeral}); s.page+=dir==='next'?1:-1; return i.update(renderPicker(sid)); }
  }

  async function select(i){
    if(!await prepareInteraction(i))return;
    const id=i.customId;
    if(id.startsWith('hu:report:type:')){
      const parts=id.split(':'),kind=parts[3],targetToken=parts.slice(4).join(':'),problemType=String(i.values?.[0]||'');
      return i.showModal(reportExplanationModal({kind,token:targetToken,problemType}));
    }
    if(id==='hu:register:type'){ const type=i.values?.[0],scope=registrationScopeFromType(type); if(!scope)return i.reply({content:'Choose Global, Server, or Private before continuing.',flags:MessageFlags.Ephemeral}); return i.showModal(destinationInputModal(type)); }
    if(id.startsWith('hu:pass:house:channel:')){
      const savedHouseId=Number(id.split(':')[4]),channelId=String(i.values?.[0]||'');
      try{
        const channel=await i.guild?.channels.fetch(channelId);
        if(!channel?.isTextBased?.())throw new Error('Choose a Discord text channel.');
        const permissions=channel.permissionsFor?.(i.client.user);
        const required=[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.EmbedLinks,PermissionFlagsBits.ReadMessageHistory];
        if(permissions&&required.some(permission=>!permissions.has(permission)))throw new Error('AddressBook needs View Channel, Send Messages, Embed Links, and Read Message History in that channel.');
        const created=await sharePasses.createHousePass({savedHouseId,createdBy:i.user.id,originGuildId:i.guildId,channelId,names:{createdByGlobalName:i.user.globalName||i.user.username,createdByDisplayName:i.member?.displayName,originGuildName:i.guild?.name,channelName:channel.name}});
        const house=await saved.get(savedHouseId),message=await channel.send(houseShareCardPayload(house,{token:created.token,sharerName:i.member?.displayName||i.user.globalName||i.user.username}));
        await sharePasses.markHousePassPosted(created.pass.id,{guildId:i.guildId,channelId,messageId:message.id,channelName:channel.name});
        return i.update({content:`House Share Pass posted in <#${channelId}>. It remains active until you revoke it.`,embeds:[],components:buttonRows([{customId:'hu:home',label:'Back to AddressBook',style:'secondary'}])});
      }catch(error){return i.reply({content:`Could not post that Share Pass: ${error.message}`,flags:MessageFlags.Ephemeral});}
    }
    if(id.startsWith('hu:pass:tour:channel:')){
      const tourId=Number(id.split(':')[4]),channelId=String(i.values?.[0]||'');
      try{
        const channel=await i.guild?.channels.fetch(channelId);
        if(!channel?.isTextBased?.())throw new Error('Choose a Discord text channel.');
        const permissions=channel.permissionsFor?.(i.client.user),required=[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.EmbedLinks,PermissionFlagsBits.ReadMessageHistory];
        if(permissions&&required.some(permission=>!permissions.has(permission)))throw new Error('AddressBook needs View Channel, Send Messages, Embed Links, and Read Message History in that channel.');
        const created=await sharePasses.createTourPass({tourId,createdBy:i.user.id,originGuildId:i.guildId,channelId,names:{createdByGlobalName:i.user.globalName||i.user.username,createdByDisplayName:i.member?.displayName,originGuildName:i.guild?.name,channelName:channel.name}});
        const tour=await tours.get(tourId),stops=await tours.getStops(tourId);
        const message=await channel.send(tourShareCardPayload(tour,{token:created.token,sharerName:i.member?.displayName||i.user.globalName||i.user.username,stopCount:stops.length}));
        await sharePasses.markTourPassPosted(created.pass.id,{guildId:i.guildId,channelId,messageId:message.id,channelName:channel.name});
        return i.update({content:`Tour Pass posted in <#${channelId}>. Each visitor starts an independent private self-paced tour.`,embeds:[],components:buttonRows([{customId:'hu:tours',label:'Back to Tours',style:'secondary'}])});
      }catch(error){return i.reply({content:`Could not post that Tour Pass: ${error.message}`,flags:MessageFlags.Ephemeral});}
    }
    if(id==='hu:globalmod:requestpick'){
      if(!globalMods.isApprover(i.user.id))return i.reply({content:'Only a configured Global Moderator approver can review requests.',flags:MessageFlags.Ephemeral});
      const requestId=Number(i.values?.[0]),req=(await globalMods.listPending()).find(r=>Number(r.id)===requestId);
      if(!req)return i.update(globalModeratorRequestsPayload(await globalMods.listPending()));
      return i.update(globalModeratorRequestReviewPayload(req));
    }
    if(id==='hu:globalmod:revokepick'){
      if(!globalMods.isApprover(i.user.id))return i.reply({content:'Only a configured Global Moderator approver can revoke access.',flags:MessageFlags.Ephemeral});
      const userId=String(i.values?.[0]||''),row=(await globalMods.listModerators()).find(r=>String(r.discord_user_id)===userId);
      if(!row)return i.update(globalModeratorListPayload(await globalMods.listModerators()));
      return i.update(globalModeratorRevokePayload(row));
    }
    if(id.startsWith('hu:advanced-remove:')){
      const p=id.split(':'),field=p[2],aid=p[3],page=Number(p[4]||0),s=advancedState(i,aid);
      if(!s)return i.reply({content:'That Search Houses session expired. Open Search Houses again.',flags:MessageFlags.Ephemeral});
      const remove=new Set((i.values||[]).map(text));
      s.filters[field]=(Array.isArray(s.filters[field])?s.filters[field]:[]).filter(v=>!remove.has(text(v)));
      const values=s.filters[field]||[],pages=Math.max(1,Math.ceil(values.length/25)),safePage=Math.min(page,pages-1);
      return i.update(advancedRemovePayload({token:aid,field,values,page:safePage}));
    }
    if(id.startsWith('hu:advanced:')){
      const p=id.split(':'),field=p[2],aid=p[3],s=advancedState(i,aid);
      if(!s)return i.reply({content:'That Search Houses session expired. Open Search Houses again.',flags:MessageFlags.Ephemeral});
      const vals=i.values||[],prev=vals.includes('__prev__'),next=vals.includes('__next__');
      const key={tags:'tags',zone:'zones',style:'styles',classification:'classifications',houseType:'houseTypes'}[field],pageKey={tags:'tag',zone:'zone',style:'style',classification:'classification',houseType:'houseType'}[field];
      if(key){
        if(!prev&&!next){
          const available=await advancedValues(i,s,field),pageSize=23,start=(s.pages[pageKey]||0)*pageSize,current=new Set(available.slice(start,start+pageSize));
          s.filters[key]=(s.filters[key]||[]).filter(v=>!current.has(v));
          for(const v of vals)if(!v.startsWith('__')&&v!=='__none__')s.filters[key].push(v);
          s.filters[key]=[...new Set(s.filters[key])].sort((a,b)=>a.localeCompare(b));
        }
        if(prev)s.pages[pageKey]=Math.max(0,(s.pages[pageKey]||0)-1);
        if(next)s.pages[pageKey]=(s.pages[pageKey]||0)+1;
      }
      if(prev||next)return i.update(await renderAdvancedAttribute(i,aid,field));
      return searchResults(i,s.filters,{searchType:'Search Houses',mode:'update',scope:s.scope||'all',includeNonPlayerHomes:s.includeNonPlayer,backId:'hu:home',alwaysPicker:true,advancedToken:aid});
    }
    if(id.startsWith('hu:bulkselect:')){
      const bid=id.split(':')[2],b=bulkState(i,bid); if(!b)return i.reply({content:'That bulk-tour selection expired.',flags:MessageFlags.Ephemeral});
      const pageSize=25,start=b.page*pageSize,end=Math.min(start+pageSize,b.rows.length);
      for(let n=start;n<end;n++)b.selected.delete(n);
      for(const v of i.values||[]){ const n=Number(v); if(Number.isInteger(n)&&n>=start&&n<end)b.selected.add(n); }
      return i.update(renderBulkSelection(i,bid));
    }
    if(id==='hu:admin:policy'||id==='hu:admin:moderator'||id==='hu:admin:trusted'||id==='hu:admin:tours'||id==='hu:admin:channel'){
      if(!isAdmin(i))return i.reply({content:'You do not have Housing administration access.',flags:MessageFlags.Ephemeral});
      if(id==='hu:admin:policy')await guilds.setPolicy(i.guildId,i.values[0]);
      if(id==='hu:admin:moderator')await guilds.setRoles(i.guildId,'moderator',i.values||[]);
      if(id==='hu:admin:trusted')await guilds.setRoles(i.guildId,'trusted',i.values||[]);
      if(id==='hu:admin:tours'){ await guilds.setRoles(i.guildId,'tours',i.values||[]); return i.update(adminOtherRolesPayload(guilds.getSettings(i.guildId))); }
      if(id==='hu:admin:channel')await guilds.setChannel(i.guildId,i.values[0]??null);
      return i.update(adminPayload(guilds.getSettings(i.guildId)));
    }
    if(!id.startsWith('hu:picker:'))return;
    const sid=id.split(':')[2],s=states.get(sid); if(!s)return i.reply({content:'That menu expired. Run /housing again.',flags:MessageFlags.Ephemeral}); if(s.userId!==i.user.id)return i.reply({content:'That menu belongs to another user.',flags:MessageFlags.Ephemeral});
    const selectedIndex=Number(i.values[0]),r=s.rows[selectedIndex]; if(r===undefined)return i.reply({content:'That selection is no longer available.',flags:MessageFlags.Ephemeral});
    if(!navigableHousePicker(s))states.delete(sid);
    if(s.kind==='visit')return housePickerDetail(i,sid,selectedIndex);
    if(s.kind==='house-form')return finishHouseForm(i,s.extra.scope,s.extra.action,s.extra.id,s.extra.data,r,'update',s.extra.backId||'');
    if(s.kind==='registration-house-match'){
      const draft=registrationDrafts.get(s.extra.draftId,i.user.id);
      if(!draft)return i.reply({content:'That registration draft expired. Start Register New House again.',flags:MessageFlags.Ephemeral});
      registrationDrafts.update(draft.id,i.user.id,{house:r});
      return reviewRegistrationDraft(i,draft,'update');
    }
    if(s.kind==='pending')return i.update(pendingReviewPayload(r));
    if(s.kind==='tour-view')return tourDetail(i,r.id);
    if(s.kind==='tour-start')return i.update(tourStartChoicePayload(r,canRunSharedTour(i,r)));
    if(s.kind==='tour-manage')return tourManage(i,r.id);
    if(s.kind==='tour-bulk-add'){
      const bid=s.extra.bulkToken,b=bulkState(i,bid); if(!b)return i.update({content:'That bulk-tour selection expired.',embeds:[],components:[]});
      const rows=bulkSelectedRows(b),t=await tourById(i,r.id); if(!t||!bulkCompatibleTour(i,t,rows))return i.update({content:'That tour is no longer available for these results.',embeds:[],components:[]});
      const result=await tours.addStops(t.id,rows); bulkTourStates.delete(bid);
      const duplicateText=result.skipped?` **${result.skipped}** house${result.skipped===1?' was':'s were'} already on the tour and skipped.`:'';
      return i.update({...tourManagePayload(t,await tours.getStops(t.id)),content:`Added **${result.added}** house${result.added===1?'':'s'} to **${t.name}**.${duplicateText}`});
    }
    if(s.kind==='tour-add-house'){ const t=await tourById(i,s.extra.tourId); if(!t||!canManageTour(i,t))return i.update({content:'You cannot manage that tour.',embeds:[],components:[]}); await tours.addStop(t.id,r.source_id??r.id,null,r.source||'server'); return i.update(tourManagePayload(t,await tours.getStops(t.id))); }
    if(s.kind==='tour-stop-edit')return i.showModal(stopEditModal(s.extra.tourId,r));
    if(s.kind==='tour-stop-reorder'){ const t=await tourById(i,s.extra.tourId); const rows=await tours.getStops(t.id); return i.update(reorderPayload(t,r,rows.length)); }
    if(s.kind==='tour-stop-remove'){ const t=await tourById(i,s.extra.tourId); return i.update(confirmPayload({title:'Remove Tour Stop?',description:`Remove stop ${r.position}, **${destinationLabel(r)}**, from **${t.name}**? The underlying public house is not removed.`,confirmId:`hu:stop:removeconfirm:${t.id}:${r.id}`,cancelId:`hu:tour:manage:${t.id}`})); }
  }

  async function modal(i){
    if(!await prepareInteraction(i))return;
    const id=i.customId;
    if(id.startsWith('hu:modal:report:')){
      const parts=id.split(':'),kind=parts[3],problemType=parts[4],targetToken=parts.slice(5).join(':');
      try{
        const target=await reportTarget(i,kind,targetToken);
        await reports.submit({...target,reporterId:i.user.id,guildId:i.guildId,problemType,explanation:text(i.fields.getTextInputValue('explanation')),names:reportNames(i)});
        return i.reply({content:'Thank you. Your housing problem report was submitted for review.',flags:MessageFlags.Ephemeral});
      }catch(error){return i.reply({content:error.message,flags:MessageFlags.Ephemeral});}
    }
    if(id.startsWith('hu:modal:pass:house:copy:')){
      const parts=id.split(':'),visibility=parts[5],passToken=parts.slice(6).join(':');
      try{
        const resolved=await sharePasses.resolveHousePass(passToken,{userId:i.user.id,guildId:i.guildId});
        const result=await houseCopies(i).copy({
          sourceSavedHouseId:resolved.house.id,userId:i.user.id,guildId:i.guildId,passId:resolved.pass.id,visibility,
          nickname:text(i.fields.getTextInputValue('nickname'))||null,
          description:text(i.fields.getTextInputValue('description'))||null,
          tags:parseTagInput(i.fields.getTextInputValue('tags'))
        });
        const row=legacySavedRow(result.house),pending=result.house.status==='pending'?' It is awaiting Housing Moderator approval and will not appear in normal searches until approved.':'';
        const message=result.existing?'You already have this ESO destination saved at that visibility.':`House copied to your **${visibility==='private'?'Private':visibility==='public'?'Server':'Global'}** AddressBook.${pending}`;
        return modalResponse(i,{...destinationMenuPayload(await withHouseCardContext(i,row),{canEdit:true,backId:'hu:home'}),content:message});
      }catch(error){return i.reply({content:error.message,flags:MessageFlags.Ephemeral});}
    }
    if(id==='hu:modal:globalmod:request'){
      try{await globalMods.requestAccess({userId:i.user.id,guildId:i.guildId,reason:i.fields.getTextInputValue('reason')});return modalResponse(i,{content:'Your Global Housing Moderator request was submitted for centralized approval.',embeds:[],components:buttonRows([{customId:'hu:globalmod',label:'Back',style:'secondary',emoji:'↩️'}])});}
      catch(e){return i.reply({content:e.message,flags:MessageFlags.Ephemeral});}
    }
    if(id.startsWith('hu:modal:advanced:')){
      const p=id.split(':'),kind=p[3],aid=p[4],s=advancedState(i,aid);
      if(!s)return i.reply({content:'That Search Houses session expired. Open Search Houses again.',flags:MessageFlags.Ephemeral});
      if(kind==='filters'){
        s.filters.name=text(i.fields.getTextInputValue('name'));
        s.filters.owner=text(i.fields.getTextInputValue('owner')).replace(/^@/,'');
        s.filters.visibilities=[...i.fields.getStringSelectValues('visibilities')];
        s.includeNonPlayer=i.fields.getStringSelectValues('nonplayer').includes('include');
        const additional=i.fields.getStringSelectValues('attribute');
        s.filters.notOnPublicTours=additional.includes('notOnPublicTours');
        if(s.filters.notOnPublicTours)s.includeNonPlayer=false;
        const attribute=additional.find(value=>value!=='notOnPublicTours');
        if(attribute)return successfulSearchResponse(i,await renderAdvancedAttribute(i,aid,attribute));
        const scope=s.scope||'all',searchType=scope==='personal'?'Private House Search':scope==='server'?'Server House Search':'Search Houses';
        return searchResults(i,s.filters,{searchType,mode:'modal',scope,includeNonPlayerHomes:s.includeNonPlayer,backId:'hu:home',alwaysPicker:true,advancedToken:aid});
      }
      const q=text(i.fields.getTextInputValue('query'));
      if(kind==='owner')s.filters.owner=q.replace(/^@/,'');
      else s.filters.name=q;
      return successfulSearchResponse(i,renderAdvanced(i,aid));
    }
    if(id.startsWith('hu:modal:register-destination:')){
      const visibility=id.split(':')[3],scope=registrationScopeFromType(visibility);
      if(!scope)return i.reply({content:'House visibility is required.',flags:MessageFlags.Ephemeral});
      try{
        const input=text(i.fields.getTextInputValue('destination')),owner=text(i.fields.getTextInputValue('owner'));
        const resolved=await resolveDestinationInput({input,owner},houses);
        if(!resolved.house&&resolved.matches?.length&&!resolved.esoOwner)throw new Error('Enter the ESO owner when registering by house name or numeric ID.');
        const draft=registrationDrafts.create({userId:i.user.id,visibility,expectedStatus:registrationExpectedStatus(i,visibility),house:resolved.house,esoOwner:resolved.esoOwner,ownerConflict:resolved.ownerConflict||null,nickname:null,description:null,tags:[]});
        if(!resolved.house){
          return modalResponse(i,createPicker(i,{kind:'registration-house-match',rows:resolved.matches,extra:{title:'Which ESO house did you mean?',description:'Several official houses matched your entry.',draftId:draft.id},backId:'hu:register'}));
        }
        return reviewRegistrationDraft(i,draft,'modal');
      }catch(error){return i.reply({content:error.message,flags:MessageFlags.Ephemeral});}
    }
    if(id.startsWith('hu:modal:register-metadata:')){
      const draft=registrationDrafts.get(id.split(':')[3],i.user.id);
      if(!draft)return i.reply({content:'That registration draft expired. Start Register New House again.',flags:MessageFlags.Ephemeral});
      registrationDrafts.update(draft.id,i.user.id,{nickname:text(i.fields.getTextInputValue('nickname'))||null,description:text(i.fields.getTextInputValue('description'))||null,tags:parseTagInput(i.fields.getTextInputValue('tags'))});
      return modalResponse(i,registrationFinalReviewPayload(draft));
    }
    if(id.startsWith('hu:modal:register:')){ const scope=registrationScopeFromType(id.split(':')[3]); if(!scope)return i.reply({content:'Registration Type is required.',flags:MessageFlags.Ephemeral}); return submitHouseForm(i,scope,'add',null,'hu:home'); }
    if(id.startsWith('hu:modal:personal:edit:')){ const p=id.split(':'); return submitHouseForm(i,'personal','edit',Number(p[4]),decodeURIComponent(p.slice(5).join(':')||'')); }
    if(id.startsWith('hu:modal:guild:edit:')){ const p=id.split(':'); return submitHouseForm(i,'guild','edit',Number(p[4]),decodeURIComponent(p.slice(5).join(':')||'')); }
    if(id.startsWith('hu:modal:global:edit:')){ const p=id.split(':'); return submitHouseForm(i,'global','edit',Number(p[4]),decodeURIComponent(p.slice(5).join(':')||'')); }
    if(id.startsWith('hu:modal:comment:')){
      const p=id.split(':'),scope=p[3],rid=Number(p[4]),backId=decodeURIComponent(p.slice(5).join(':')),r=await getSaved(scope,rid,i); if(!r)return i.reply({content:'That saved house is no longer available.',flags:MessageFlags.Ephemeral}); const value=i.fields.getTextInputValue('comment');
      if(scope==='personal')await comments.addPersonal({bookmarkId:rid,ownerUserId:i.user.id,commenterUserId:i.user.id,text:value}); else if(scope==='global')await comments.addGlobal({savedHouseId:rid,commenterUserId:i.user.id,text:value}); else await comments.addServer({registrationId:rid,guildId:i.guildId,commenterUserId:i.user.id,text:value});
      return commentsScreen(i,scope,rid,'modal',backId);
    }
    if(id.startsWith('hu:modal:bulk:create:')){
      const bid=id.split(':')[4],b=bulkState(i,bid); if(!b)return i.reply({content:'That bulk-tour selection expired.',flags:MessageFlags.Ephemeral});
      b.name=text(i.fields.getTextInputValue('name')); b.description=text(i.fields.getTextInputValue('description'))||null;
      if(!b.name)return i.reply({content:'Tour name is required.',flags:MessageFlags.Ephemeral});
      return modalResponse(i,bulkTourVisibilityPayload(bid,{allowPublic:!!i.guildId}));
    }
    if(id==='hu:modal:tour:create'){
      const did=token(); drafts.set(did,{userId:i.user.id,name:text(i.fields.getTextInputValue('name')),description:text(i.fields.getTextInputValue('description'))||null,created:Date.now()}); return modalResponse(i,tourVisibilityPayload(did));
    }
    if(id.startsWith('hu:modal:tour:edit:')){ const tid=Number(id.split(':')[4]),t=await tourById(i,tid); if(!t||!canManageTour(i,t))return i.reply({content:'You cannot manage that tour.',flags:MessageFlags.Ephemeral}); const updated=await tours.update(tid,{name:text(i.fields.getTextInputValue('name')),description:text(i.fields.getTextInputValue('description'))||null}); return modalResponse(i,tourEditDetailsPayload(updated)); }
    if(id.startsWith('hu:modal:stop:edit:')){ const p=id.split(':'),tid=Number(p[4]),stopId=Number(p[5]),t=await tourById(i,tid); if(!t||!canManageTour(i,t))return modalResponse(i,{content:'You cannot manage that tour.',embeds:[],components:[]}); const current=(await tours.getStops(tid)).find(s=>s.id===stopId); if(!current)return modalResponse(i,{content:'That tour stop no longer exists.',embeds:[],components:[]}); const enteredTitle=text(i.fields.getTextInputValue('title')),defaultTitle=text(current.registration_nickname||current.house_name||current.title); const customTitle=enteredTitle&&enteredTitle!==defaultTitle?enteredTitle:null; await tours.updateStop(stopId,{title:customTitle,notes:text(i.fields.getTextInputValue('description'))||null}); return modalResponse(i,tourManagePayload(t,await tours.getStops(tid))); }
  }
  return {chat,button,select,modal};
}
