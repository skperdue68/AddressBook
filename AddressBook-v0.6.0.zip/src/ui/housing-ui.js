import {
  ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelSelectMenuBuilder, ChannelType,
  EmbedBuilder, LabelBuilder, ModalBuilder, RoleSelectMenuBuilder, StringSelectMenuBuilder,
  TextInputBuilder, TextInputStyle
} from 'discord.js';
import { addHouseMetadata, addCleanHouseMetadata, titleWithPlayerCap } from '../utils/render.js';
import { buildJumpScript, buildHousingLink, buildHousePreviewScript } from '../utils/eso.js';
import { destinationLabel } from '../utils/labels.js';
import {
  homeButtonSpecs, toursButtonSpecs, tourDetailButtonSpecs, tourManageButtonSpecs
} from '../utils/menu-specs.js';

const styles={primary:ButtonStyle.Primary,secondary:ButtonStyle.Secondary,success:ButtonStyle.Success,danger:ButtonStyle.Danger};
const color=0x2b7ddd;
const safe=(v,max=100)=>String(v??'').slice(0,max);
const parseTags=v=>{try{return Array.isArray(v)?v:JSON.parse(v||'[]')}catch{return []}};
const unixTime=v=>{const d=v instanceof Date?v:new Date(/(?:Z|[+-]\d\d:?\d\d)$/.test(String(v))?String(v):`${v}Z`);const ms=d.getTime();return Number.isFinite(ms)?Math.floor(ms/1000):Math.floor(Date.now()/1000);};

function button(spec){ const b=new ButtonBuilder().setCustomId(spec.customId).setLabel(spec.label).setStyle(styles[spec.style]??ButtonStyle.Secondary); if(spec.emoji)b.setEmoji(spec.emoji); if(spec.disabled)b.setDisabled(true); return b; }
export function buttonRows(specs,size=5){ const width=Math.max(1,Math.min(5,Number(size)||5)); const rows=[]; for(let n=0;n<specs.length;n+=width)rows.push(new ActionRowBuilder().addComponents(...specs.slice(n,n+width).map(button))); return rows; }
function embed(title,description){ return new EmbedBuilder().setColor(color).setTitle(title).setDescription(description); }

function homeButtonRows(isAdmin){
  const specs=homeButtonSpecs(isAdmin);
  const by=id=>specs.find(x=>x.customId===id);
  const groups=[
    [by('hu:find'),by('hu:register')],
    [by('hu:tours'),by('hu:my')],
    [by('hu:help'),by('hu:globalmod')],
    ...(isAdmin?[[by('hu:admin')]]:[])
  ];
  return groups.map(group=>new ActionRowBuilder().addComponents(...group.filter(Boolean).map(button)));
}
export function homePayload({isAdmin=false,version='0.6.0'}={}){ return {embeds:[embed('🏠 AddressBook','Your ESO housing directory and tour guide.\n\nFind saved homes, keep a Private address book, share Server or Global destinations, and lead or follow housing tours—all without memorizing commands.').setFooter({text:`AddressBook • Version ${version} • Start anytime with /housing`})],components:homeButtonRows(isAdmin)}; }
export function onboardingPayload({page=0}={}){
  if(page===0)return {embeds:[embed('🏠 Welcome to AddressBook','Find and share ESO player housing destinations, save your own Private list, and follow housing tours. Choose a starting point or take the three-screen introduction.')],components:buttonRows([
    {customId:'hu:find',label:'Find a House',style:'primary'},
    {customId:'hu:register',label:'Register a House',style:'success'},
    {customId:'hu:tours:start',label:'Start a Tour',style:'primary'},
    {customId:'hu:onboarding:1',label:'Show Me Around',style:'secondary'},
    {customId:'hu:onboarding:skip',label:'Skip',style:'secondary'}
  ])};
  const screens={
    1:['Introduction 1 of 3 — Discover','Search Global homes, this server’s Server homes, your Private homes, and optional Non-Player Homes. Filters help narrow large lists.'],
    2:['Introduction 2 of 3 — Visit in ESO','Every player-house card keeps Jump in ESO, Unfurnished Preview, and Housing Link in separate code blocks so Discord provides easy copy controls.'],
    3:['Introduction 3 of 3 — Tour Your Way','Self-Paced tours are private to each visitor. Shared tours appear in a channel, but only the tour leader controls navigation. Share Pass tours let every visitor start an independent session.']
  };
  const [title,description]=screens[page]||screens[1],actions=[];
  if(page>1)actions.push({customId:`hu:onboarding:${page-1}`,label:'Back',style:'secondary'});
  actions.push(page<3?{customId:`hu:onboarding:${page+1}`,label:'Next',style:'primary'}:{customId:'hu:onboarding:finish',label:'Finish',style:'success'});
  actions.push({customId:'hu:onboarding:skip',label:'Skip',style:'secondary'});
  return {embeds:[embed(title,description)],components:buttonRows(actions)};
}
export function myAddressBookPayload({houses=0,tours=0,pending=0,recent=0,continueItems=null}={}){
  const e=embed('📖 My AddressBook','Your personal home base for the houses and tours you have created. Only you can see this dashboard.')
    .addFields(
      {name:'🏠 My Houses',value:`**${Number(houses)}**`,inline:true},
      {name:'🗺️ My Tours',value:`**${Number(tours)}**`,inline:true},
      {name:'⏳ Pending',value:`**${Number(pending)}**`,inline:true},
      {name:'🕘 Recently Viewed',value:`**${Number(recent)}**`,inline:true}
    );
  const continueActions=[];
  if(continueItems?.activeTour)continueActions.push({customId:`hu:my:resume:${continueItems.activeTour.id}`,label:'Resume Tour',style:'success'},{customId:`hu:my:restart:${continueItems.activeTour.id}`,label:'Start Over',style:'secondary'},{customId:`hu:my:end:${continueItems.activeTour.id}`,label:'End Tour',style:'secondary'});
  if(continueItems?.recentHouse)continueActions.push({customId:`hu:context:view:${continueItems.recentHouse.scope==='private'?'personal':continueItems.recentHouse.scope==='global'?'global':'guild'}:${continueItems.recentHouse.id}:hu%3Amy`,label:'Open Recent House',style:'primary'});
  if(continueItems?.editedTour)continueActions.push({customId:`hu:tour:view:${continueItems.editedTour.id}`,label:'Open Recent Tour',style:'secondary'});
  if(continueActions.length)e.addFields({name:'▶️ Continue',value:'Resume where you left off or reopen recent work.'});
  return {embeds:[e],components:[...buttonRows(continueActions),...buttonRows([
    {customId:'hu:my:houses',label:'My Houses',style:'primary',emoji:'🏠'},
    {customId:'hu:my:tours',label:'My Tours',style:'secondary',emoji:'🗺️'},
    {customId:'hu:my:pending',label:'Pending',style:'secondary',emoji:'⏳'},
    {customId:'hu:my:recent',label:'Recently Viewed',style:'secondary',emoji:'🕘'},
    {customId:'hu:home',label:'Back',style:'secondary',emoji:'↩️'}
  ],4)]};
}
export function myPendingPayload({houses=[],requests=[]}={}){
  const lines=[];
  for(const house of houses.slice(0,15))lines.push(`• **${destinationLabel(house)}** — ${house.scope==='global'?'Global':'Server'} house`);
  for(const request of requests.slice(0,5))lines.push(`• **Global Moderator Access** — requested <t:${unixTime(request.requested_at)}:R>`);
  const total=houses.length+requests.length;
  const description=total?`${lines.join('\n')}${total>lines.length?`\n…and ${total-lines.length} more`:''}\n\nThese requests remain here until an authorized moderator approves or denies them.`:'You have no pending house submissions or Global Moderator access requests.';
  const actions=[];if(!total)actions.push({customId:'hu:register',label:'Register a House',style:'success'});actions.push({customId:'hu:my',label:'Back to My AddressBook',style:'secondary',emoji:'↩️'});
  return {embeds:[embed('⏳ My Pending Requests',description)],components:buttonRows(actions)};
}
export function toursPayload(count=0){ return {embeds:[embed('🗺️ Housing Tours',`There ${count===1?'is':'are'} **${count}** tour${count===1?'':'s'} available to you.\n\nStart one, browse the route, or build and manage tours without remembering tour commands.`)],components:buttonRows(toursButtonSpecs())}; }
export function helpPayload(){
  const e=embed('❓ AddressBook Help','**Start with `/housing`.** The menus will walk you through almost everything the bot can do.')
    .addFields(
      {name:'🔎 Search Houses',value:'Search bot-wide Global houses, this server’s Server houses, your Private houses, and optionally Non-Player Homes.'},
      {name:'➕ Register New House',value:'Register a house with Global, Server, or Private visibility. Global and Server submissions use this server’s registration policy; Private houses remain visible only to you.'},
      {name:'🗺️ Housing Tours',value:'Follow Global, Server, or Private tours in Self Paced or Shared mode. Eligible stops are selected automatically by visibility.'},
      {name:'📖 My AddressBook',value:'Open your personal dashboard for your houses, tours, pending requests, and recently viewed destinations.'},
      {name:'⚙️ Administration',value:'Authorized Housing Moderators can manage policy, roles, and the AddressBook channel from the Administration button.'}
    );
  return {embeds:[e],components:buttonRows([{customId:'hu:onboarding:1',label:'Show Introduction Again',style:'primary'},{customId:'hu:home',label:'Back',style:'secondary',emoji:'↩️'}])};
}

export function pickerPayload({title,description,customId,options,page=0,pages=1,backId='hu:home',multiple=false,actions=[],paginationArrows=false}){
  const select=new StringSelectMenuBuilder().setCustomId(customId).setPlaceholder(multiple?'Choose one or more options…':'Choose an option…').addOptions(options.map(o=>({label:safe(o.label),value:safe(o.value,100),description:o.description?safe(o.description,100):undefined,default:!!o.default}))).setMinValues(1).setMaxValues(multiple?Math.min(25,Math.max(1,options.length)):1);
  const nav=[];
  if(pages>1){ nav.push({customId:`hu:picker:prev:${customId.split(':').pop()}`,label:'Previous',style:'secondary',emoji:paginationArrows?'⬅️':undefined,disabled:page<=0},{customId:`hu:picker:next:${customId.split(':').pop()}`,label:'Next',style:'secondary',emoji:paginationArrows?'➡️':undefined,disabled:page>=pages-1}); }
  nav.push({customId:backId,label:'Back',style:'secondary',emoji:'↩️'});
  return {embeds:[embed(title,description)],components:[new ActionRowBuilder().addComponents(select),...buttonRows(actions,2),...buttonRows(nav)]};
}


export function bulkTourChoicePayload({token,action,count,backId}){
  const creating=action==='create';
  const title=creating?'Create New Tour From Results':'Add Results to Existing Tour';
  const verb=creating?'create a new tour from':'add to an existing tour from';
  return {embeds:[embed(`🗺️ ${title}`,`There are **${count} saved house${count===1?'':'s'}** in these search results that can be used as tour stops. Non-Player Homes are ignored because they do not have a saved player destination.

Choose whether to ${verb} all saved results or select only the houses you want.`)],components:buttonRows([
    {customId:`hu:bulk:all:${token}`,label:'Use All Saved Results',style:'success'},
    {customId:`hu:bulk:select:${token}`,label:'Select Houses',style:'primary'},
    {customId:`hu:bulk:cancel:${token}`,label:'Back',style:'secondary',emoji:'↩️'}
  ])};
}

export function bulkTourSelectionPayload({token,action,options,page=0,pages=1,selectedCount=0,backId}){
  const select=new StringSelectMenuBuilder().setCustomId(`hu:bulkselect:${token}`).setPlaceholder('Select houses from this page…').addOptions(options.map(o=>({label:safe(o.label),value:safe(o.value,100),description:o.description?safe(o.description,100):undefined,default:!!o.default}))).setMinValues(0).setMaxValues(Math.min(25,Math.max(1,options.length)));
  const nav=[];
  if(pages>1){
    nav.push({customId:`hu:bulkselect:prev:${token}`,label:'Previous',style:'secondary',disabled:page<=0});
    nav.push({customId:`hu:bulkselect:next:${token}`,label:'Next',style:'secondary',disabled:page>=pages-1});
  }
  nav.push({customId:`hu:bulkselect:done:${token}`,label:action==='create'?'Create Tour':'Add to Tour',style:'success',disabled:selectedCount<1});
  nav.push({customId:backId,label:'Back',style:'secondary',emoji:'↩️'});
  return {embeds:[embed(action==='create'?'🗺️ Select Houses for New Tour':'🗺️ Select Houses to Add',`Select houses across as many pages as needed. Your selections are preserved while paging.

**${selectedCount} house${selectedCount===1?'':'s'} selected.**`)],components:[new ActionRowBuilder().addComponents(select),...buttonRows(nav)]};
}

export function bulkTourCreateModal(token){ return new ModalBuilder().setCustomId(`hu:modal:bulk:create:${token}`).setTitle('Create New Tour From Results').addComponents(textField('name','Tour name',{required:true}),textField('description','Description (optional)',{paragraph:true})); }
export function bulkTourVisibilityPayload(token,{allowPublic=true,allowGlobal=true}={}){ return {embeds:[embed('Create New Tour From Results — Visibility','Choose who should be able to find and reuse the saved tour. Eligible houses are determined automatically by visibility.')],components:buttonRows([
  {customId:`hu:bulk:visibility:global:${token}`,label:'Global Tour',style:'secondary',disabled:!allowGlobal},
  {customId:`hu:bulk:visibility:server:${token}`,label:'Server Tour',style:'success',disabled:!allowPublic},
  {customId:`hu:bulk:visibility:personal:${token}`,label:'Private Tour',style:'primary'},
  {customId:`hu:bulk:return:${token}`,label:'Back',style:'secondary',emoji:'↩️'}
])}; }

export function cleanDestinationEmbed(r,{showDetails=false}={}){
  const e=embed(titleWithPlayerCap(destinationLabel(r),r),r.description||'Saved ESO housing destination.')
    .addFields({name:'👤 Owner',value:`@${String(r.eso_owner||'').replace(/^@/,'')}`,inline:true});
  const submitterName=String(r.created_by_display_name||r.created_by_global_name||'').trim();
  const submitterId=String(r.created_by||'').trim();
  const submittedBy=submitterId?(submitterName?`${submitterName} • <@${submitterId}>`:`<@${submitterId}>`):(submitterName||'Unknown');
  const visibility=r.scope==='global'?'Global':['server','public','guild'].includes(r.scope)?'Server':'Private';
  const tourNames=(Array.isArray(r.associated_tours)?r.associated_tours:[]).map(t=>String(t?.name||'').replace(/\s+/g,' ').trim()).filter(Boolean);
  let associatedTours='None';
  if(tourNames.length){
    const lines=[];
    for(let index=0;index<tourNames.length;index++){
      const line=`• ${tourNames[index]}`,remaining=tourNames.length-index-1,suffix=remaining?`\n…and ${remaining} more`:'';
      if([...lines,line].join('\n').length+suffix.length>1024)break;
      lines.push(line);
    }
    const remaining=tourNames.length-lines.length;
    associatedTours=`${lines.join('\n')}${remaining?`\n…and ${remaining} more`:''}`.slice(0,1024);
  }
  e.addFields(
    {name:'📝 Submitted By',value:submittedBy,inline:true},
    {name:'👁️ Visibility',value:visibility,inline:true},
    {name:'🗺️ Associated Tours',value:associatedTours}
  );
  addCleanHouseMetadata(e,r,{showDetails});
  const tags=parseTags(r.tags); if(tags.length)e.addFields({name:'🏷️ Tags',value:tags.map(t=>`\`${t}\``).join(' ').slice(0,1024)});
  e.addFields(
    {name:'💬 Comments',value:`${Number(r.comment_count||0)} comment${Number(r.comment_count||0)===1?'':'s'}`,inline:true},
    {name:'🔗 Jump in ESO',value:`\`\`\`text\n${buildJumpScript(r.eso_owner,r.house_id)}\n\`\`\``},
    {name:'🏚️ Unfurnished Preview',value:`\`\`\`text\n${buildHousePreviewScript(r.house_id)}\n\`\`\``},
    {name:'🔗 Housing Link',value:`\`\`\`text\n${buildHousingLink(r.eso_owner,r.house_id)}\n\`\`\``}
  );
  return e;
}
function houseNavigationSpecs(navigation){
  if(!navigation||!Number.isInteger(navigation.index)||!Number.isInteger(navigation.total)||navigation.total<2)return [];
  const {stateId,index,total}=navigation;
  return [
    {customId:`hu:house-nav:${stateId}:${Math.max(0,index-1)}`,label:'Previous House',style:'secondary',emoji:'⬅️',disabled:index<=0},
    {customId:`hu:house-nav:${stateId}:${Math.min(total-1,index+1)}`,label:'Next House',style:'secondary',emoji:'➡️',disabled:index>=total-1}
  ];
}
export function destinationMenuPayload(r,{canEdit=false,backId='hu:home',showDetails=false,navigation=null}={}){
  const scope=r.scope==='personal'?'personal':r.scope==='global'?'global':'guild';
  const detailBack=encodeURIComponent(backId);
  const actionBack=encodeURIComponent(backId);
  const commentsBackId=navigation&&navigation.stateId&&Number.isInteger(navigation.index)
    ?`hu:house-nav:${navigation.stateId}:${navigation.index}`
    :`hu:context:view:${scope}:${Number(r.id)}:${encodeURIComponent(backId)}`;
  const primarySpecs=[
    {customId:`hu:details:${scope}:${Number(r.id)}:${showDetails?'hide':'show'}:${detailBack}`,label:showDetails?'Hide Details':'More Details',style:'primary',emoji:showDetails?'🔼':'🔽'},
    {customId:`hu:comments:${r.scope}:${Number(r.id)}:${encodeURIComponent(commentsBackId)}`,label:'Comments',style:'primary',emoji:'💬'},
    {customId:`hu:pass:house:share:${Number(r.id)}`,label:'Share House',style:'success'},
    {customId:`hu:report:houseid:${Number(r.id)}`,label:'Report a Problem',style:'secondary'}
  ];
  const editSpecs=canEdit?[
    {customId:`hu:${scope}:edit:${Number(r.id)}:${actionBack}`,label:'Edit House',style:'secondary',emoji:'✏️'},
    {customId:`hu:scope:change:${Number(r.id)}:${actionBack}`,label:'Change Visibility',style:'secondary',emoji:'🔄'},
    {customId:`hu:${scope}:remove:${Number(r.id)}:${actionBack}`,label:'Delete House',style:'danger',emoji:'🗑️'}
  ]:[];
  const navSpecs=houseNavigationSpecs(navigation);
  const backSpecs=[{customId:backId,label:'Back',style:'secondary',emoji:'↩️'}];
  return {embeds:[cleanDestinationEmbed(r,{showDetails})],components:[...buttonRows(primarySpecs),...buttonRows(editSpecs),...buttonRows(navSpecs,2),...buttonRows(backSpecs)]};
}

export function officialHousePayload(house,backId='hu:find',showDetails=false,navigation=null){
  const e=embed(titleWithPlayerCap(`🏠 ${house.name}`,house),'Non-Player Home — official ESO housing information.')
    .addFields(
      {name:'🆔 House ID',value:String(house.house_id),inline:true},
      {name:'📝 Submitted By',value:'ESO Housing Catalog',inline:true},
      {name:'👁️ Visibility',value:'Non-Player Home',inline:true},
      {name:'🗺️ Associated Tours',value:'None'}
    );
  addCleanHouseMetadata(e,house,{showDetails});
  const specs=[{customId:`hu:details:official:${Number(house.house_id)}:${showDetails?'hide':'show'}:${encodeURIComponent(backId)}`,label:showDetails?'Hide Details':'More Details',style:'primary',emoji:showDetails?'🔼':'🔽'}];
  const navSpecs=houseNavigationSpecs(navigation);
  const backSpecs=[{customId:backId,label:'Back',style:'secondary',emoji:'↩️'}];
  return {embeds:[e],components:[...buttonRows(specs),...buttonRows(navSpecs,2),...buttonRows(backSpecs)]};
}

function textField(id,label,{value='',required=false,paragraph=false,placeholder=null,maxLength=null}={}){
  const input=new TextInputBuilder().setCustomId(id).setLabel(label).setStyle(paragraph?TextInputStyle.Paragraph:TextInputStyle.Short).setRequired(required);
  if(value!==null&&value!==undefined&&String(value)!=='')input.setValue(safe(value,4000));
  if(placeholder)input.setPlaceholder(safe(placeholder,100));
  if(maxLength)input.setMaxLength(maxLength);
  return new ActionRowBuilder().addComponents(input);
}
function advancedOptions(values,page=0,{selected=[],multiple=false,prefix=''}={}){
  const pageSize=23,totalPages=Math.max(1,Math.ceil(values.length/pageSize)),safePage=Math.max(0,Math.min(page,totalPages-1));
  const slice=values.slice(safePage*pageSize,safePage*pageSize+pageSize);
  const options=slice.map(v=>({label:safe(`${prefix} ${v}`.trim()),value:safe(v,100),default:selected.includes(v)}));
  if(safePage>0)options.unshift({label:'← Previous options',value:'__prev__'});
  if(safePage<totalPages-1)options.push({label:'More options →',value:'__next__'});
  if(!options.length)options.push({label:'No values available',value:'__none__'});
  return {options,page:safePage,pages:totalPages,maxValues:multiple?Math.min(25,Math.max(1,options.filter(o=>!o.value.startsWith('__')).length)):1};
}
function advancedDirectRemovalSpecs(token,filters={}){
  const groups=[
    ['tags','Tag'],['zones','Zone'],['styles','Style'],['classifications','Classification'],['houseTypes','Type']
  ];
  const all=[];
  for(const [field,label] of groups){
    const values=Array.isArray(filters[field])?filters[field]:[];
    values.forEach((value,index)=>all.push({customId:`hu:advanced:x:${token}:${field}:${index}`,label:safe(`× ${label}: ${value}`,80),style:'secondary'}));
  }
  if(all.length<=5)return all;
  return [...all.slice(0,4),{customId:`hu:advanced:manage:${token}`,label:'Manage Selected…',style:'secondary'}];
}
export function advancedSearchPayload({token,filters={},title='Search Houses',backId='hu:home',includeNonPlayer=false}){
  const name=String(filters.name||'').trim();
  const owner=String(filters.owner||'').trim().replace(/^@/,'');
  const tags=Array.isArray(filters.tags)?filters.tags:[];
  const zones=Array.isArray(filters.zones)?filters.zones:[];
  const stylesSelected=Array.isArray(filters.styles)?filters.styles:[];
  const classifications=Array.isArray(filters.classifications)?filters.classifications:[];
  const houseTypes=Array.isArray(filters.houseTypes)?filters.houseTypes:[];
  const list=v=>v.length?v.map(x=>`\`${x}\``).join(', '):'Any';
  const summary=[
    `**House / Nickname:** ${name?`\`${name}\``:'Any'}`,
    `**Owner:** ${owner?`@${owner}`:'Any'}`,
    `**Tags / Themes:** ${list(tags)}`,
    `**Zone:** ${list(zones)}`,
    `**Architectural Style:** ${list(stylesSelected)}`,
    `**ESO Classification:** ${list(classifications)}`,
    `**Size / Type:** ${list(houseTypes)}`,
    `**Tour Membership:** ${filters.notOnPublicTours?'Not on a Server or Global Tour':'Any'}`,
    `**Non-Player Homes:** ${includeNonPlayer?'Included':'Excluded'}`
  ].join('\n');
  const e=embed(`🔎 ${title}`,`Build one cumulative search below. House / Nickname and Owner each use one partial-match value. Every populated filter category is combined with **AND**. Multiple selections inside the same attribute category are **OR** matches. Nothing is searched until you press **Search**.\n\n${summary}\n\nPress **Search** with no filters to return all eligible houses.`);
  const removals=advancedDirectRemovalSpecs(token,filters);
  const components=[];
  if(removals.length)components.push(new ActionRowBuilder().addComponents(...removals.map(button)));
  components.push(
    new ActionRowBuilder().addComponents(
      button({customId:`hu:advanced:name:${token}`,label:'House / Nickname',style:'primary',emoji:'🔤'}),
      button({customId:`hu:advanced:owner:${token}`,label:'Owner',style:'secondary',emoji:'👤'})
    ),
    new ActionRowBuilder().addComponents(
      button({customId:`hu:advanced:tagsopen:${token}`,label:'Tags / Themes',style:'secondary',emoji:'🏷️'}),
      button({customId:`hu:advanced:zoneopen:${token}`,label:'Zone',style:'secondary',emoji:'📍'}),
      button({customId:`hu:advanced:styleopen:${token}`,label:'Architectural Style',style:'secondary',emoji:'🏛️'}),
      button({customId:`hu:advanced:classificationopen:${token}`,label:'ESO Classification',style:'secondary',emoji:'👑'}),
      button({customId:`hu:advanced:houseTypeopen:${token}`,label:'Size / Type',style:'secondary',emoji:'🏠'})
    ),
    new ActionRowBuilder().addComponents(
      button({customId:`hu:advanced:search:${token}`,label:'Search',style:'success',emoji:'🔎'}),
      button({customId:`hu:advanced:clear:${token}`,label:'Clear Filters',style:'secondary'}),
      button({customId:`hu:advanced:nonplayer:${token}`,label:`Non-Player Homes: ${includeNonPlayer?'Included':'Excluded'}`,style:includeNonPlayer?'success':'secondary',emoji:includeNonPlayer?'✅':'🚫',disabled:!!filters.notOnPublicTours}),
      button({customId:backId,label:'Back',style:'secondary',emoji:'↩️'})
    )
  );
  return {embeds:[e],components};
}

export function advancedAttributePayload({token,field,values=[],selected=[],page=0}){
  const config={
    tags:{title:'Tags / Themes',prefix:'Tag:'},
    zone:{title:'Zone',prefix:'Zone:'},
    style:{title:'Architectural Style',prefix:'Style:'},
    classification:{title:'ESO Classification',prefix:'Classification:'},
    houseType:{title:'Size / Type',prefix:'Type:'}
  }[field];
  if(!config)return advancedSearchPayload({token});
  const pageData=advancedOptions(values,page,{selected,multiple:true,prefix:config.prefix});
  const select=new StringSelectMenuBuilder().setCustomId(`hu:advanced:${field}:${token}`).setPlaceholder(`${config.title} — Select one or more`).addOptions(pageData.options).setMinValues(0).setMaxValues(pageData.maxValues);
  return {embeds:[embed(`🎛️ ${config.title}`,`Choose one or more ${config.title.toLowerCase()} values. Multiple values in this category are OR matches. Your selections are applied to the populated house list.`)],components:[new ActionRowBuilder().addComponents(select),...buttonRows([{customId:`hu:advanced:results:${token}`,label:'Back to Results',style:'secondary',emoji:'↩️'}])]};
}

export function advancedManagePayload(token,filters={}){
  const groups=[['tags','Tag / Theme'],['zones','Zone'],['styles','Architectural Style'],['classifications','ESO Classification'],['houseTypes','Size / Type']];
  const active=groups.filter(([k])=>Array.isArray(filters[k])&&filters[k].length);
  const e=embed('🧹 Manage Search Selections',active.length?'Choose a category to remove one or more selected values.':'There are no selected attribute values to remove.');
  const buttons=active.map(([k,label])=>({customId:`hu:advanced:remove:${token}:${k}:0`,label:`Remove ${label}`,style:'secondary'}));
  buttons.push({customId:`hu:advanced:open:${token}`,label:'Back',style:'secondary',emoji:'↩️'});
  return {embeds:[e],components:buttonRows(buttons,3)};
}

export function advancedRemovePayload({token,field,values=[],page=0}){
  const labels={tags:'Tag / Theme',zones:'Zone',styles:'Architectural Style',classifications:'ESO Classification',houseTypes:'Size / Type'};
  const pageSize=25,pages=Math.max(1,Math.ceil(values.length/pageSize)),safePage=Math.max(0,Math.min(page,pages-1));
  const slice=values.slice(safePage*pageSize,safePage*pageSize+pageSize);
  const e=embed(`🗑️ Remove ${labels[field]||'Selections'}`,slice.length?'Select one or more values to remove.':'There are no selected values in this category.');
  const components=[];
  if(slice.length){
    const select=new StringSelectMenuBuilder().setCustomId(`hu:advanced-remove:${field}:${token}:${safePage}`).setPlaceholder('Select values to remove…').addOptions(slice.map(v=>({label:safe(field==='owners'?`@${String(v).replace(/^@/,'')}`:v),value:safe(v,100)}))).setMinValues(1).setMaxValues(Math.min(25,slice.length));
    components.push(new ActionRowBuilder().addComponents(select));
  }
  const nav=[];
  if(pages>1){
    nav.push({customId:`hu:advanced:remove:${token}:${field}:${Math.max(0,safePage-1)}`,label:'Previous',style:'secondary',disabled:safePage<=0});
    nav.push({customId:`hu:advanced:remove:${token}:${field}:${Math.min(pages-1,safePage+1)}`,label:'Next',style:'secondary',disabled:safePage>=pages-1});
  }
  nav.push({customId:`hu:advanced:manage:${token}`,label:'Back',style:'secondary',emoji:'↩️'});
  components.push(...buttonRows(nav));
  return {embeds:[e],components};
}

export function advancedTextModal(token,kind,value=''){
  const isName=kind==='name';
  return new ModalBuilder().setCustomId(`hu:modal:advanced:${kind}:${token}`).setTitle(isName?'House / Nickname Filter':'Owner Filter').addComponents(
    textField('query',isName?'House name or nickname':'ESO owner',{value,required:false,placeholder:isName?'Type part of a house name or nickname':'e.g. malderyn'})
  );
}
export function searchFiltersModal(token,filters={},includeNonPlayer=false){
  const selectedVisibilities=Array.isArray(filters.visibilities)&&filters.visibilities.length
    ?filters.visibilities:['global','public','private'];
  const labeledText=(id,label,value,placeholder)=>{
    const input=new TextInputBuilder().setCustomId(id).setStyle(TextInputStyle.Short).setRequired(false).setPlaceholder(placeholder);
    if(String(value||''))input.setValue(safe(value,4000));
    return new LabelBuilder().setLabel(label).setDescription('Optional partial match').setTextInputComponent(input);
  };
  const visibility=new StringSelectMenuBuilder().setCustomId('visibilities').setRequired(false).setMinValues(0).setMaxValues(3).addOptions(
    {label:'Global',value:'global',description:'Bot-wide Global houses.',default:selectedVisibilities.includes('global')},
    {label:'Server',value:'public',description:'Houses saved by this Discord server.',default:selectedVisibilities.includes('public')},
    {label:'Private',value:'private',description:'Your own Private houses.',default:selectedVisibilities.includes('private')}
  );
  const nonPlayer=new StringSelectMenuBuilder().setCustomId('nonplayer').setRequired(true).setMinValues(1).setMaxValues(1).addOptions(
    {label:'Exclude Non-Player Homes',value:'exclude',default:!includeNonPlayer},
    {label:'Include Non-Player Homes',value:'include',default:includeNonPlayer}
  );
  const attribute=new StringSelectMenuBuilder().setCustomId('attribute').setRequired(false).setMinValues(0).setMaxValues(2).setPlaceholder('Optional — choose tour status and/or a category').addOptions(
    {label:'Not on a Server or Global Tour',value:'notOnPublicTours',description:'Exclude houses already on an applicable shared tour.',default:!!filters.notOnPublicTours},
    {label:'Tags / Themes',value:'tags',description:'Choose one or more tags or themes.'},
    {label:'Zone',value:'zone',description:'Choose one or more ESO zones.'},
    {label:'Architectural Style',value:'style',description:'Choose one or more architectural styles.'},
    {label:'ESO Classification',value:'classification',description:'Choose one or more ESO classifications.'},
    {label:'Size / Type',value:'houseType',description:'Choose one or more house sizes or types.'}
  );
  return new ModalBuilder().setCustomId(`hu:modal:advanced:filters:${token}`).setTitle('Filter Homes').addLabelComponents(
    labeledText('name','House name or nickname',filters.name,'Type part of a house name or nickname'),
    labeledText('owner','ESO owner',String(filters.owner||'').replace(/^@/,''),'e.g. malderyn'),
    new LabelBuilder().setLabel('House Visibility').setDescription('Select any combination, in Global, Server, Private order.').setStringSelectMenuComponent(visibility),
    new LabelBuilder().setLabel('Non-Player Homes').setStringSelectMenuComponent(nonPlayer),
    new LabelBuilder().setLabel('Additional Filters').setDescription('Choose tour status and optionally one attribute category.').setStringSelectMenuComponent(attribute)
  );
}
export function registrationTypePayload(){
  const select=new StringSelectMenuBuilder().setCustomId('hu:register:type').setPlaceholder('Choose Global, Server, or Private').setMinValues(1).setMaxValues(1).addOptions(
    {label:'Global',value:'global',description:'Register this house bot-wide so every server can find it.'},
    {label:'Server',value:'public',description:"Register this house in this Discord server's directory."},
    {label:'Private',value:'private',description:'Save this house privately for your Discord account.'}
  );
  return {embeds:[embed('➕ Register New House','Choose a **Visibility** before continuing.\n\nNo visibility is selected by default; choose **Global**, **Server**, or **Private**.')],components:[new ActionRowBuilder().addComponents(select),...buttonRows([{customId:'hu:home',label:'Back',style:'secondary',emoji:'↩️'}])]};
}
const visibilityName=value=>value==='global'?'Global':value==='public'||value==='server'?'Server':'Private';
const registrationStatusName=value=>value==='pending'?'Awaiting Housing Moderator approval':'Active';

export function destinationInputModal(scope){
  return new ModalBuilder().setCustomId(`hu:modal:register-destination:${scope}`).setTitle('Register New House').addComponents(
    textField('destination','House Name, ID, Housing Link, or Jump Command',{required:true,placeholder:'Grand Psijic Villa, 62, @owner, 62, or an ESO link'}),
    textField('owner','ESO owner (optional with link or command)',{required:false,placeholder:'e.g. HouseOwner'})
  );
}

export function registrationDestinationReviewPayload(draft){
  const house=draft.house||{},conflict=draft.ownerConflict;
  const entries=[...(draft.existingEntries||[])].sort((a,b)=>({global:0,public:1,server:1,private:2,personal:2}[a.scope]-({global:0,public:1,server:1,private:2,personal:2}[b.scope])));
  const ownerLine=conflict?`**Owner in pasted destination:** @${conflict.parsed}\n**Owner entered separately:** @${conflict.entered}`:`**ESO owner:** @${draft.esoOwner}`;
  const matches=entries.length?entries.map(row=>`• **${visibilityName(row.scope)}:** ${row.display_name||row.nickname||house.name||house.house_name}`).join('\n'):'• None';
  const description=[
    `**Official house:** ${house.name||house.house_name||'Unknown'}`,
    `**House ID:** **${house.house_id}**`,ownerLine,
    `**Requested visibility:** ${visibilityName(draft.visibility)}`,
    `**Expected status:** ${registrationStatusName(draft.expectedStatus)}`,
    `**Existing entries — Global, Server, Private**\n${matches}`
  ].join('\n');
  const actions=conflict?[
    {customId:`hu:register-owner:parsed:${draft.id}`,label:`Use @${conflict.parsed}`,style:'primary'},
    {customId:`hu:register-owner:entered:${draft.id}`,label:`Use @${conflict.entered}`,style:'secondary'},
    {customId:`hu:register-cancel:${draft.id}`,label:'Cancel',style:'danger'}
  ]:entries.length?(()=>{
    const first=entries[0],scope=first.scope==='private'||first.scope==='personal'?'personal':first.scope==='global'?'global':'guild';
    const normalized=value=>value==='server'?'public':value==='personal'?'private':value;
    const exact=entries.some(row=>normalized(row.scope)===normalized(draft.visibility));
    const ownPrivate=entries.some(row=>normalized(row.scope)==='private');
    return [
      {customId:`hu:context:view:${scope}:${first.id}:hu%3Aregister`,label:'View Existing',style:'primary'},
      ...(!ownPrivate&&draft.visibility!=='private'?[{customId:`hu:register-privatecopy:${draft.id}`,label:'Save Separate Private Copy',style:'success'}]:[]),
      {customId:`hu:register-report:${draft.id}:${first.id}`,label:'Request an Update',style:'secondary'},
      ...(!exact?[{customId:`hu:register-metadata:${draft.id}`,label:'Continue with New Visibility',style:'primary'}]:[]),
      {customId:`hu:register-cancel:${draft.id}`,label:'Cancel',style:'secondary'}
    ];
  })():[
    {customId:`hu:register-metadata:${draft.id}`,label:'Continue',style:'primary'},
    {customId:`hu:register-cancel:${draft.id}`,label:'Cancel',style:'secondary'}
  ];
  return {embeds:[embed('Review House Destination',description)],components:buttonRows(actions)};
}

export function registrationMetadataModal(draftId,metadata={}){
  return new ModalBuilder().setCustomId(`hu:modal:register-metadata:${draftId}`).setTitle('House Details').addComponents(
    textField('nickname','Nickname (optional)',{value:metadata.nickname||''}),
    textField('description','Description or notes (optional)',{value:metadata.description||'',paragraph:true}),
    textField('tags','Tags / themes, comma separated',{value:Array.isArray(metadata.tags)?metadata.tags.join(', '):(metadata.tags||'')})
  );
}

export function registrationFinalReviewPayload(draft){
  const house=draft.house||{},tags=parseTags(draft.tags);
  const description=[
    `**ESO owner:** @${draft.esoOwner}`,
    `**Official house:** ${house.name||house.house_name||'Unknown'} (#${house.house_id})`,
    `**Visibility:** ${visibilityName(draft.visibility)}`,
    `**Nickname:** ${draft.nickname||'None'}`,
    `**Description:** ${draft.description||'None'}`,
    `**Tags:** ${tags.length?tags.join(', '):'None'}`,
    `**Registration status:** ${registrationStatusName(draft.expectedStatus)}`
  ].join('\n');
  return {embeds:[embed('Confirm House Registration',description)],components:buttonRows([
    {customId:`hu:register-save:${draft.id}`,label:'Save House',style:'success'},
    {customId:`hu:register-metadata:${draft.id}`,label:'Edit Details',style:'primary'},
    {customId:`hu:register-cancel:${draft.id}`,label:'Cancel',style:'secondary'}
  ])};
}
function houseFormFields(scope,r=null){
  const personal=scope==='personal'||scope==='private';
  return [
    textField('house','Official house name, partial name, or ID',{value:r?.house_name||r?.house_id||'',required:true,placeholder:'e.g. Still, Stillwaters Retreat, or 80'}),
    textField('owner','ESO owner',{value:r?.eso_owner||'',required:true,placeholder:'e.g. malderyn'}),
    textField('nickname','Nickname (optional)',{value:personal?r?.nickname:r?.display_name}),
    textField('description',personal?'Private notes (optional)':'Description (optional)',{value:personal?r?.notes:r?.description,paragraph:true}),
    textField('tags','Tags / themes, comma separated',{value:(()=>{try{return JSON.parse(r?.tags||'[]').join(', ')}catch{return ''}})()})
  ];
}
export function registerHouseFormModal(scope){
  return new ModalBuilder().setCustomId(`hu:modal:register:${scope}`).setTitle('Register New House').addComponents(...houseFormFields(scope));
}
export function houseEditModal(scope,r,backId=''){
  const personal=scope==='personal';
  const context=backId?`:${encodeURIComponent(backId)}`:'';
  return new ModalBuilder().setCustomId(`hu:modal:${scope}:edit:${r.id}${context}`).setTitle(`Edit ${personal?'Private':scope==='global'?'Global':'Server'} House`).addComponents(...houseFormFields(scope,r));
}


export function pendingReviewPayload(r){
  const e=embed('📝 Review Pending House',`**${destinationLabel(r)}**\nOwner: @${String(r.eso_owner||'').replace(/^@/,'')}\nOfficial house: ${r.house_name||'Unknown'}${r.description?`\n\n${r.description}`:''}`);
  const tags=parseTags(r.tags); if(tags.length)e.addFields({name:'Tags',value:tags.map(t=>`\`${t}\``).join(' ').slice(0,1024)});
  return {embeds:[e],components:buttonRows([{customId:`hu:pending:approve:${r.id}`,label:'Approve',style:'success'},{customId:`hu:pending:deny:${r.id}`,label:'Deny',style:'danger'},{customId:'hu:guild:pending',label:'Back',style:'secondary',emoji:'↩️'}])};
}

export function confirmPayload({title,description,confirmId,cancelId}){ return {embeds:[embed(title,description)],components:buttonRows([{customId:confirmId,label:'Confirm',style:'danger'},{customId:cancelId,label:'Cancel',style:'secondary'}])}; }

export function commentsPayload({label,owner,rows,scope,id,backId}){
  const body=rows.length?rows.map(c=>`**${c.author_name}** — <t:${unixTime(c.created_at)}:f>\n${c.comment_text}`).join('\n\n'):'No comments have been added yet.';
  const disclosure='Comments apply to this ESO destination and may also appear through other saved entries for the same house.';
  const e=embed(`💬 Comments — ${label}`,`Owner: @${String(owner||'').replace(/^@/,'')}\n\n${disclosure}\n\n${body}`.slice(0,4096));
  return {embeds:[e],components:buttonRows([{customId:`hu:comment:add:${scope}:${id}:${encodeURIComponent(backId)}`,label:'Add Comment',style:'primary'},{customId:backId,label:'Back',style:'secondary',emoji:'↩️'}])};
}
export function commentModal(scope,id,backId,label){ return new ModalBuilder().setCustomId(`hu:modal:comment:${scope}:${id}:${encodeURIComponent(backId)}`).setTitle(`Comment — ${safe(label,30)}`).addComponents(textField('comment','Comment',{required:true,paragraph:true,maxLength:1000})); }

export function tourDetailPayload(tour,stops,canEdit=false){
  const visibility=tour.scope==='global'?'Global Tour':tour.scope==='server'?'Server Tour':'Private Tour';
  const e=embed(`🗺️ ${tour.name}`,tour.description||'Housing tour').addFields(
    {name:'Stops',value:String(stops.length),inline:true},
    {name:'Tour Visibility',value:visibility,inline:true}
  );
  if(stops.length)e.addFields({name:'Route',value:stops.map(s=>`${s.position}. **${destinationLabel(s)}** — @${String(s.eso_owner).replace(/^@/,'')}`).join('\n').slice(0,1024)});
  const specs=tourDetailButtonSpecs(canEdit).map(spec=>({...spec,customId:spec.customId==='hu:tour:start'?`hu:tour:start:${tour.id}`:spec.customId==='hu:tour:manage'?`hu:tour:manage:${tour.id}`:spec.customId}));
  specs.splice(1,0,{customId:`hu:pass:tour:share:${tour.id}`,label:'Share Tour Pass',style:'success'});
  specs.splice(2,0,{customId:`hu:report:tourid:${tour.id}`,label:'Report a Problem',style:'secondary'});
  return {embeds:[e],components:buttonRows(specs)};
}
export function tourManagePayload(tour,stops){
  const lines=stops.map(s=>`${s.position}. **${destinationLabel(s)}** — @${String(s.eso_owner||'').replace(/^@/,'')}`);
  const kept=[]; let used=0;
  for(const line of lines){
    const next=used+line.length+(kept.length?1:0);
    if(next>980)break;
    kept.push(line); used=next;
  }
  const omitted=Math.max(0,lines.length-kept.length);
  const route=kept.length?`${kept.join('\n')}${omitted?`\n… plus ${omitted} more stop${omitted===1?'':'s'}`:''}`:'No stops yet.';
  const e=embed(`✏️ Edit Tour — ${tour.name}`,`${stops.length} stop${stops.length===1?'':'s'}\n\nChoose what you want to change. No command syntax required.`)
    .addFields({name:'Current Tour Route',value:route});
  return {embeds:[e],components:buttonRows(tourManageButtonSpecs().map(spec=>({...spec,customId:spec.customId==='hu:tours'?`hu:tour:view:${tour.id}`:`${spec.customId}:${tour.id}`})),3)};
}
export function tourStartChoicePayload(tour,canRunSharedPublicTour){
  const canShared=tour.scope==='personal'||canRunSharedPublicTour;
  return {embeds:[embed(`▶️ Start Tour — ${tour.name}`,'Choose how you want to follow this tour.\n\n**Self Paced** is visible only to you and never changes the shared tour.\n**Shared** posts the tour in this channel for the group.')],components:buttonRows([
    {customId:`hu:tour:startprivate:${tour.id}`,label:'Self Paced',style:'primary'},
    {customId:`hu:tour:startpublic:${tour.id}`,label:'Shared',style:'success',disabled:!canShared},
    {customId:`hu:tour:view:${tour.id}`,label:'Back',style:'secondary',emoji:'↩️'}
  ])};
}
export function tourCreateModal(){ return new ModalBuilder().setCustomId('hu:modal:tour:create').setTitle('Create Housing Tour').addComponents(textField('name','Tour name',{required:true}),textField('description','Description (optional)',{paragraph:true})); }
export function tourVisibilityPayload(token){ return {embeds:[embed('Create Tour — Tour Visibility','Who should be able to find and start this saved tour?\n\n**Global Tour:** every server using AddressBook; Global Tours can contain Global Houses only.\n**Server Tour:** this Discord server; it can contain Global and Server Houses.\n**Private Tour:** only you; it can contain any house visible to you.')],components:buttonRows([
  {customId:`hu:tour:createvis:global:${token}`,label:'Global Tour',style:'secondary'},
  {customId:`hu:tour:createvis:server:${token}`,label:'Server Tour',style:'success'},
  {customId:`hu:tour:createvis:personal:${token}`,label:'Private Tour',style:'primary'},
  {customId:'hu:tours',label:'Cancel',style:'secondary'}
])}; }
export function tourEditDetailsPayload(tour){
  const visibility=tour.scope==='global'?'Global Tour':tour.scope==='server'?'Server Tour':'Private Tour';
  const e=embed(`✏️ Edit Tour Details — ${tour.name}`,`**Tour Visibility:** ${visibility}\n\nChange the name, description, or visibility below. Eligible houses are selected automatically from the tour visibility.`);
  return {embeds:[e],components:buttonRows([
    {customId:`hu:tour:edittext:${tour.id}`,label:'Edit Name / Description',style:'primary'},
    {customId:`hu:tour:editvisibility:${tour.id}`,label:'Change Tour Visibility',style:'secondary'},
    {customId:`hu:tour:manage:${tour.id}`,label:'Back',style:'secondary',emoji:'↩️'}
  ],2)};
}
export function tourEditVisibilityPayload(tour){ return {embeds:[embed(`Tour Visibility — ${tour.name}`,'Choose who can find/start/edit the saved tour. Private tours remain creator-only even if launched in Shared mode.')],components:buttonRows([
  {customId:`hu:tour:setvisibility:global:${tour.id}`,label:'Global Tour',style:'secondary'},
  {customId:`hu:tour:setvisibility:server:${tour.id}`,label:'Server Tour',style:'success'},
  {customId:`hu:tour:setvisibility:personal:${tour.id}`,label:'Private Tour',style:'primary'},
  {customId:`hu:tour:edit:${tour.id}`,label:'Back',style:'secondary',emoji:'↩️'}
])}; }
export function tourEditModal(tour){ return new ModalBuilder().setCustomId(`hu:modal:tour:edit:${tour.id}`).setTitle('Edit Tour Details').addComponents(textField('name','Tour name',{value:tour.name,required:true}),textField('description','Description',{value:tour.description||'',paragraph:true})); }
export function stopEditModal(tourId,stop){ const defaultTitle=stop.custom_title||stop.registration_nickname||stop.house_name||stop.title||''; return new ModalBuilder().setCustomId(`hu:modal:stop:edit:${tourId}:${stop.id}`).setTitle(`Edit Stop ${stop.position}`).addComponents(textField('title','Tour-specific stop title',{value:defaultTitle}),textField('description','Tour notes / description',{value:stop.notes||'',paragraph:true})); }
export function reorderPayload(tour,stop,total){ return {embeds:[embed(`↕️ Reorder — ${tour.name}`,`Selected stop **${stop.position} of ${total}**: ${destinationLabel(stop)}\n\nMove it with the buttons below.`)],components:buttonRows([{customId:`hu:reorder:up:${tour.id}:${stop.id}`,label:'Move Up',style:'secondary',disabled:stop.position<=1},{customId:`hu:reorder:down:${tour.id}:${stop.id}`,label:'Move Down',style:'secondary',disabled:stop.position>=total},{customId:`hu:reorder:first:${tour.id}:${stop.id}`,label:'Move to Beginning',style:'primary',disabled:stop.position<=1},{customId:`hu:reorder:last:${tour.id}:${stop.id}`,label:'Move to End',style:'primary',disabled:stop.position>=total},{customId:`hu:tour:manage:${tour.id}`,label:'Done',style:'success'}])}; }

export function adminPayload(settings){
  const roles=ids=>ids.length?ids.map(id=>`<@&${id}>`).join(', '):'Not configured';
  const policyLabels={open:'Open',approval:'Approval',roles:'Roles'};
  const policyHelp={
    open:'Anyone may submit a Server Directory house and it becomes active immediately.',
    approval:'Anyone may submit. Housing Trusted Submitter members and Housing Moderators are trusted submitters; other submissions wait for Housing Moderator review.',
    roles:'Only Housing Trusted Submitters and Housing Moderators may submit Server Directory houses.'
  };
  const e=embed('⚙️ Housing Administration','These settings apply only to this Discord server. Each selector explains what it controls.').addFields(
    {name:'📋 Registration Policy',value:`**${policyLabels[settings.registration_policy]||settings.registration_policy}**
${policyHelp[settings.registration_policy]||''}`},
    {name:'🛡️ Housing Moderator Role',value:`${roles(settings.staff_role_ids)}
Controls Administration access and Housing Moderator-only actions. If configured, only members with this role can see or use Administration.`},
    {name:'👥 Other Roles',value:`**Housing Tours Role:** ${roles(settings.tour_role_ids||[])}
May start and control Shared Server Tours. This role does not grant Housing Moderator privileges.`}
  );
  if(settings.registration_policy!=='open')e.addFields(
    {name:'🔑 Housing Trusted Submitter Role',value:`${roles(settings.registration_role_ids)}
Trusted submitter role used by the selected registration policy. It does not grant Housing Moderator Administration access.`}
  );
  e.addFields({name:'💬 AddressBook Channel',value:`${settings.bot_channel_id?`<#${settings.bot_channel_id}>`:'Not configured'}
Optionally limits normal AddressBook commands and menu interactions to one channel. Clear the selection to allow use in any channel.`});

  const policy=new StringSelectMenuBuilder().setCustomId('hu:admin:policy').setPlaceholder('Choose registration policy…').addOptions(
    {label:'Open — everyone is auto-approved',value:'open',description:'Anyone may submit and entries become active immediately.',default:settings.registration_policy==='open'},
    {label:'Approval — ordinary submissions wait for review',value:'approval',description:'Housing Trusted Submitters and Housing Moderators are trusted submitters.',default:settings.registration_policy==='approval'},
    {label:'Roles — Trusted Submitter / Housing Moderator only',value:'roles',description:'Only the configured roles may submit houses.',default:settings.registration_policy==='roles'}
  );
  const moderator=new RoleSelectMenuBuilder().setCustomId('hu:admin:moderator').setPlaceholder('Choose Housing Moderator roles, or clear for bootstrap access…').setMinValues(0).setMaxValues(25);
  if(settings.staff_role_ids?.length)moderator.setDefaultRoles(...settings.staff_role_ids.slice(0,25));
  const channel=new ChannelSelectMenuBuilder().setCustomId('hu:admin:channel').setPlaceholder('Choose a channel, or clear to allow any channel…').setChannelTypes(ChannelType.GuildText).setMinValues(0).setMaxValues(1);
  if(settings.bot_channel_id)channel.setDefaultChannels(settings.bot_channel_id);
  const components=[new ActionRowBuilder().addComponents(policy),new ActionRowBuilder().addComponents(moderator)];
  if(settings.registration_policy!=='open'){
    const trusted=new RoleSelectMenuBuilder().setCustomId('hu:admin:trusted').setPlaceholder('Choose Housing Trusted Submitter roles, or clear for none…').setMinValues(0).setMaxValues(25);
    if(settings.registration_role_ids?.length)trusted.setDefaultRoles(...settings.registration_role_ids.slice(0,25));
    components.push(new ActionRowBuilder().addComponents(trusted));
  }
  components.push(new ActionRowBuilder().addComponents(channel),...buttonRows([{customId:'hu:admin:health',label:'Health',style:'primary'},{customId:'hu:admin:reports',label:'Problem Reports',style:'secondary'},{customId:'hu:admin:passes',label:'Share Passes',style:'secondary'},{customId:'hu:admin:otherroles',label:'Other Roles',style:'primary'},{customId:'hu:guild:pending',label:'Pending Review',style:'secondary'},{customId:'hu:globalmod',label:'Global Moderation',style:'secondary',emoji:'🌐'},{customId:'hu:home',label:'Back',style:'secondary',emoji:'↩️'}]));
  return {embeds:[e],components};
}


export function adminOtherRolesPayload(settings){
  const roles=ids=>ids?.length?ids.map(id=>`<@&${id}>`).join(', '):'Not configured';
  const e=embed('👥 Housing Administration — Other Roles',`Configure optional roles with narrowly scoped AddressBook permissions.

**Housing Tours Role:** ${roles(settings.tour_role_ids||[])}
Members with this role, or the Housing Moderator role, may start and control Shared Server Tours. It grants no Administration, Server Directory moderation, pending-review, trusted-submitter, or channel-recovery privileges.`);
  const tours=new RoleSelectMenuBuilder().setCustomId('hu:admin:tours').setPlaceholder('Choose Housing Tours roles, or clear for none…').setMinValues(0).setMaxValues(25);
  if(settings.tour_role_ids?.length)tours.setDefaultRoles(...settings.tour_role_ids.slice(0,25));
  return {embeds:[e],components:[new ActionRowBuilder().addComponents(tours),...buttonRows([{customId:'hu:admin',label:'Back',style:'secondary',emoji:'↩️'}])]};
}

export function adminHealthPayload(snapshot){
  const channel=snapshot.channel?.id?(snapshot.channel.missing?`Missing or unavailable (${snapshot.channel.id})`:`${snapshot.channel.name||snapshot.channel.id}`):'Any channel';
  const e=embed('🩺 AddressBook Health', 'Operational checks and counts for this Discord server. Secrets and connection credentials are never displayed.').addFields(
    {name:'Backend',value:`${snapshot.backend} — ${snapshot.connection}`,inline:true},{name:'Version',value:String(snapshot.version),inline:true},{name:'AddressBook Channel',value:channel,inline:true},{name:'Registration Policy',value:String(snapshot.registrationPolicy),inline:true},
    {name:'Configured Roles',value:`Moderator: ${snapshot.roleCounts.moderator}\nTrusted Submitter: ${snapshot.roleCounts.trusted}\nHousing Tours: ${snapshot.roleCounts.tours}`,inline:true},
    {name:'Queues',value:`Pending submissions: ${snapshot.pendingSubmissions}\nGlobal Moderator requests: ${snapshot.globalModeratorRequests}\nOpen reports: ${snapshot.openReports}`,inline:true},
    {name:'Share Passes',value:`House active/revoked: ${snapshot.passes.house.active}/${snapshot.passes.house.revoked}\nTour active/revoked: ${snapshot.passes.tour.active}/${snapshot.passes.tour.revoked}`},
    {name:'Last Migration',value:snapshot.lastMigration.version?`Schema ${snapshot.lastMigration.version}${snapshot.lastMigration.appliedAt?` — ${snapshot.lastMigration.appliedAt}`:''}`:'No migration record'},{name:'Backup Reminder',value:snapshot.backupReminder}
  );
  return {embeds:[e],components:buttonRows([{customId:'hu:admin:reports',label:'Problem Reports',style:'primary'},{customId:'hu:admin:passes',label:'Share Passes',style:'secondary'},{customId:'hu:admin',label:'Back',style:'secondary'}])};
}
export function adminSharePassesPayload(passes={house:{active:0,revoked:0},tour:{active:0,revoked:0}}){
  const e=embed('🔗 Share Pass Activity','Aggregate revocable-pass counts for this server’s Administration view. Individual private destinations are not exposed here.').addFields({name:'House Share Passes',value:`Active: ${passes.house?.active||0}\nRevoked: ${passes.house?.revoked||0}`,inline:true},{name:'Tour Share Passes',value:`Active: ${passes.tour?.active||0}\nRevoked: ${passes.tour?.revoked||0}`,inline:true});
  return {embeds:[e],components:buttonRows([{customId:'hu:admin:health',label:'Health',style:'primary'},{customId:'hu:admin',label:'Back',style:'secondary'}])};
}

export function houseScopePayload(r,backId='hu:find'){ const current=r.scope==='personal'?'Private':r.scope==='server'?'Server':'Global'; return {embeds:[embed(`🔄 Change House Visibility — ${destinationLabel(r)}`,`Current visibility: **${current}**\n\nChanging visibility keeps the same house record, comments, and metadata. If the house is no longer eligible for a tour, AddressBook will show the affected tours before making the change.`)],components:buttonRows([{customId:`hu:scope:set:global:${r.id}:${encodeURIComponent(backId)}`,label:'Global',style:'secondary'},{customId:`hu:scope:set:public:${r.id}:${encodeURIComponent(backId)}`,label:'Server',style:'success'},{customId:`hu:scope:set:private:${r.id}:${encodeURIComponent(backId)}`,label:'Private',style:'primary'},{customId:backId,label:'Back',style:'secondary',emoji:'↩️'}])}; }
export function globalModeratorRequestModal(){ return new ModalBuilder().setCustomId('hu:modal:globalmod:request').setTitle('Request Global Moderator Access').addComponents(textField('reason','Why do you need bot-wide moderation?',{required:true,paragraph:true,maxLength:1000})); }
export function globalModeratorPayload({isApprover=false,isModerator=false,pendingCount=0}={}){ const details=[`**Your Global Moderator status:** ${isModerator?'Active':'Not active'}`,`**Pending requests:** ${pendingCount}`]; return {embeds:[embed('🌐 Global Housing Moderation',details.join('\n'))],components:buttonRows([{customId:'hu:globalmod:request',label:'Request Global Moderator Access',style:'primary',disabled:isModerator},...(isApprover?[{customId:'hu:globalmod:requests',label:'Review Requests',style:'success'},{customId:'hu:globalmod:list',label:'Manage Global Moderators',style:'secondary'}]:[]),{customId:'hu:home',label:'Back',style:'secondary',emoji:'↩️'}])}; }


export function globalModeratorRequestsPayload(rows=[]){
  if(!rows.length)return {embeds:[embed('🌐 Global Moderator Requests','There are no pending Global Moderator requests.')],components:buttonRows([{customId:'hu:globalmod',label:'Back',style:'secondary',emoji:'↩️'}])};
  const select=new StringSelectMenuBuilder().setCustomId('hu:globalmod:requestpick').setPlaceholder('Choose a request to review…').addOptions(rows.slice(0,25).map(r=>({label:`User ${r.discord_user_id}`.slice(0,100),description:safe(r.reason,100),value:String(r.id)})));
  return {embeds:[embed('🌐 Global Moderator Requests',`**${rows.length}** pending request${rows.length===1?'':'s'}. Choose one to review.`)],components:[new ActionRowBuilder().addComponents(select),...buttonRows([{customId:'hu:globalmod',label:'Back',style:'secondary',emoji:'↩️'}])]};
}
export function globalModeratorRequestReviewPayload(r){return {embeds:[embed('🌐 Review Global Moderator Request',`**User:** <@${r.discord_user_id}>\n**Originating server:** ${r.origin_guild_id?`\`${r.origin_guild_id}\``:'Unknown'}\n\n**Reason**\n${r.reason}`)],components:buttonRows([{customId:`hu:globalmod:approve:${r.id}`,label:'Approve',style:'success'},{customId:`hu:globalmod:deny:${r.id}`,label:'Deny',style:'danger'},{customId:'hu:globalmod:requests',label:'Back',style:'secondary',emoji:'↩️'}])};}
export function globalModeratorListPayload(rows=[]){
  if(!rows.length)return {embeds:[embed('🌐 Global Housing Moderators','No Global Housing Moderators are currently configured.')],components:buttonRows([{customId:'hu:globalmod',label:'Back',style:'secondary',emoji:'↩️'}])};
  const select=new StringSelectMenuBuilder().setCustomId('hu:globalmod:revokepick').setPlaceholder('Choose a moderator to revoke…').addOptions(rows.slice(0,25).map(r=>({label:`User ${r.discord_user_id}`.slice(0,100),value:String(r.discord_user_id),description:r.approved_by?`Approved by ${r.approved_by}`:undefined})));
  return {embeds:[embed('🌐 Global Housing Moderators',`**${rows.length}** active Global Moderator${rows.length===1?'':'s'}. Choose one only if you intend to revoke bot-wide access.`)],components:[new ActionRowBuilder().addComponents(select),...buttonRows([{customId:'hu:globalmod',label:'Back',style:'secondary',emoji:'↩️'}])]};
}
export function globalModeratorRevokePayload(r){return confirmPayload({title:'Revoke Global Moderator?',description:`Remove bot-wide Global Housing Moderator access from <@${r.discord_user_id}>?`,confirmId:`hu:globalmod:revoke:${r.discord_user_id}`,cancelId:'hu:globalmod:list'});}
