import 'dotenv/config';
import { Client, Events, GatewayIntentBits, MessageFlags } from 'discord.js';
import { closeDatabase, ensureMariaDatabase, migrate, openDatabase } from './db/database.js';
import { runConfiguredMigration } from './db/database-migration.js';
import { seedHouses } from './db/seed-houses.js';
import { createHandlers } from './handlers.js';

if(!process.env.DISCORD_TOKEN) throw new Error('DISCORD_TOKEN is required. Copy .env.example to .env and fill it in.');

const migration=await runConfiguredMigration();
if(migration){
  console.log(`Database migration completed: ${migration.direction}`);
  console.table(migration.summary);
  console.log('Set MIGRATE=false, then start AddressBook again.');
  process.exit(0);
}

if(String(process.env.DB_TYPE||'sqlite').toLowerCase()==='mariadb')await ensureMariaDatabase();
const db=openDatabase();
await migrate(db);
await seedHouses(db);
const handlers=createHandlers(db);
const client=new Client({intents:[GatewayIntentBits.Guilds]});

client.once(Events.ClientReady,async c=>{
  try{await handlers.ready(c);}catch(err){console.error('AddressBook could not refresh Discord names at startup:',err);}
  console.log(`AddressBook ready as ${c.user.tag}`);
});
client.on(Events.InteractionCreate,async i=>{
  try{
    if(i.isAutocomplete()) return await handlers.autocomplete(i);
    if(i.isChatInputCommand()) return await handlers.chat(i);
    if(i.isButton()) return await handlers.button(i);
    if(i.isStringSelectMenu() || i.isRoleSelectMenu() || i.isChannelSelectMenu()) return await handlers.select(i);
    if(i.isModalSubmit()) return await handlers.modal(i);
  }catch(err){
    console.error(err);
    const message=/database|connect|pool|socket|ECONN/i.test(String(err?.message||''))
      ?'AddressBook cannot reach its database right now. Please try again shortly.'
      :`Error: ${err.message}`;
    const payload={content:message,flags:MessageFlags.Ephemeral};
    if(i.replied||i.deferred) await i.followUp(payload).catch(()=>{});
    else await i.reply(payload).catch(()=>{});
  }
});

let shuttingDown=false;
async function shutdown(){
  if(shuttingDown)return;
  shuttingDown=true;
  client.destroy();
  await closeDatabase(db).catch(()=>{});
  process.exit(0);
}
process.on('SIGINT',shutdown);
process.on('SIGTERM',shutdown);

await client.login(process.env.DISCORD_TOKEN);
