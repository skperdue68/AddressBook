export function destinationJumpButtonSpec(r){
  return {customId:`jumpcopy:${Number(r.house_id)}:${encodeURIComponent(r.eso_owner)}`,label:'Show Command / Link',style:'primary'};
}
export function destinationActionButtonSpecs(r){
  const scope=r.scope==='personal'?'personal':'server';
  const id=Number(r.id);
  const specs=[destinationJumpButtonSpec(r)];
  if(Number(r.comment_count||0)>0) specs.push({customId:`comments:view:${scope}:${id}`,label:'View Comments',style:'secondary'});
  specs.push({customId:`comments:add:${scope}:${id}`,label:'Add Comment',style:'secondary'});
  return specs;
}
export function tourButtonSpecs(tourId,commentCount=0,showDetails=false){
  return [
    {customId:`tour:prev:${tourId}`,label:'Previous Stop',style:'secondary'},
    {customId:`tour:next:${tourId}`,label:'Next Stop',style:'primary'},
    {customId:`tour:${showDetails?'hide':'details'}:${tourId}`,label:showDetails?'Hide Details':'More Details',style:'primary'},
    {customId:`tour:comments:${tourId}`,label:'Comments',style:'primary'},
    {customId:`tour:list:${tourId}`,label:'Show Tour List',style:'secondary'},
    {customId:`tour:end:${tourId}`,label:'End Tour',style:'danger'}
  ];
}
